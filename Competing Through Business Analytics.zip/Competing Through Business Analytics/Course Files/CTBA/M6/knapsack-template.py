# -*- coding: utf-8 -*-
"""
@author: jhwilck
"""
# Determine start time
import time
start = time.time()

# Need itertools and combinations to form all combinations of items.
from itertools import combinations
 
def anycomb(items):
    # Creates all possible combinations of items.
    return ( comb
             for r in range(1, len(items)+1)
             for comb in combinations(items, r)
             )
 
def totalvalue(comb):
    # Calculate the total value and check feasibility of a combination of items.
    totwt = totval = 0
    for item, wt, val in comb:
        totwt  += wt
        totval += val
    return (totval, -totwt) if totwt <= cap else (0, 0)

# Items a collection of = ((Item Name, Volume, Value), ...)

# Data Set Trial (From Prof. Bradley's Video):
items = (
    ("Item 1", 9, 20), ("Item 2", 1, 1), ("Item 3", 5, 11), ("Item 4", 4, 10)
    )
cap = 10

bagged = max( anycomb(items), key=totalvalue)

print("Knapsack contains the following items\n  " +
      '\n  '.join(sorted(item for item,_,_ in bagged)))
val, wt = totalvalue(bagged)
print("For a total value of %i and a total volume of %i" % (val, -wt))

# Determine ending time
end = time.time()

# Print total time.
print("For a total time in seconds of ")
print(end - start)