#####
#Designated proper working environment on my computer. You will want to make sure it is in proper place for your computer.
#####
setwd("D:/Class/Online MSBA/ML1 Online/Mod2")
moneyball=read.csv("moneyball_training_2.csv",header=T)

############## Part 1: Data Exploration ##########################################################################
str(moneyball)
summary(moneyball)

# Wins - Use lower bound for lower outliers, upper bound for higher outliers.
par(mfrow=c(1,2))
hist(moneyball$TARGET_WINS, col = "#A71930", xlab = "TARGET_WINS", main = "Histogram of Wins")
boxplot(moneyball$TARGET_WINS, col = "#A71930", main = "Boxplot of Wins")
par(mfrow = c(1,1))

################# Batting ####################
# Hits and Doubles
par(mfrow=c(2,2))
hist(moneyball$TEAM_BATTING_H, col = "#A71930", xlab = "Team_Batting_H", main = "Histogram of Hits")
hist(moneyball$TEAM_BATTING_2B, col = "#09ADAD", xlab = "Doubles", main = "Histogram of Doubles")
boxplot(moneyball$TEAM_BATTING_H, col = "#A71930", main = "Boxplot of Hits")
boxplot(moneyball$TEAM_BATTING_2B, col = "#09ADAD", main = "Boxplot of Doubles")
par(mfrow=c(1,1))

# Triples and Home Runs
par(mfrow=c(2,2))
hist(moneyball$TEAM_BATTING_3B, col = "#A71930", xlab = "Triples", main = "Histogram of Triples")
hist(moneyball$TEAM_BATTING_HR, col = "#DBCEAC", xlab = "Home Runs", main = "Histogram of Home Runs")
boxplot(moneyball$TEAM_BATTING_3B, col = "#A71930", main = "Boxplot of Triples")
boxplot(moneyball$TEAM_BATTING_HR, col = "#DBCEAC", main = "Boxplot of Home Runs")
par(mfrow=c(1,1))

# Walks, Strikeouts, HBP
par(mfrow=c(2,3))
hist(moneyball$TEAM_BATTING_BB, col = "#A71930", xlab = "Walks", main = "Histogram of Walks")
hist(moneyball$TEAM_BATTING_SO, col = "#09ADAD", xlab = "Strikeouts", main = "Histogram of Strikeouts")
hist(moneyball$TEAM_BATTING_HBP, col = "#DBCEAC", xlab = "Hit By Pitches", main = "Histogram of HBP")
boxplot(moneyball$TEAM_BATTING_BB, col = "#A71930", main = "Boxplot of Walks")
boxplot(moneyball$TEAM_BATTING_SO, col = "#09ADAD", main = "Boxplot of Strikeouts")
boxplot(moneyball$TEAM_BATTING_HBP, col = "#DBCEAC", main = "Boxplot of HBP")
par(mfrow=c(1,1))

# Stolen Bases and Caught Stealing
par(mfrow=c(2,2))
hist(moneyball$TEAM_BASERUN_SB, col = "#A71930", xlab = "Stolen Bases", main = "Histogram of Steals")
hist(moneyball$TEAM_BASERUN_CS, col = "#DBCEAC", xlab = "Caught Stealing", main = "Histogram of CS")
boxplot(moneyball$TEAM_BASERUN_SB, col = "#A71930", main = "Boxplot of Steals")
boxplot(moneyball$TEAM_BASERUN_CS, col = "#DBCEAC", main = "Boxplot of CS")
par(mfrow=c(1,1))

################ Pitching ############
# Hits and Home Runs
par(mfrow=c(2,2))
hist(moneyball$TEAM_PITCHING_H, col = "#A71930", xlab = "Hits Against", main = "Histogram of Hits Against")
hist(moneyball$TEAM_PITCHING_HR, col = "#09ADAD", xlab = "Home Runs Against", main = "Histograms of HR Against")
boxplot(moneyball$TEAM_PITCHING_H, col = "#A71930", main = "Boxplot of Hits Against")
boxplot(moneyball$TEAM_PITCHING_HR, col = "#09ADAD", main = "Boxplot of HR Against")
par(mfrow=c(1,1))

# Walks and Strikeouts
par(mfrow=c(2,2))
hist(moneyball$TEAM_PITCHING_BB, col = "#A71930", xlab = "Walks Allowed", main = "Histogram of Walks Allowed")
hist(moneyball$TEAM_PITCHING_SO, col = "#DBCEAC", xlab = "Strikeouts", main = "Histograms of Strikeouts")
boxplot(moneyball$TEAM_PITCHING_BB, col = "#A71930", main = "Boxplot of Walks Allowed")
boxplot(moneyball$TEAM_PITCHING_SO, col = "#DBCEAC", main = "Boxplot of Strikeouts")
par(mfrow=c(1,1))

############## Fielding ###########
# Double Plays and Errors 
par(mfrow=c(2,2))
hist(moneyball$TEAM_FIELDING_DP, col = "#A71930", xlab = "Double Plays", main = "Histogram of Double Plays")
hist(moneyball$TEAM_FIELDING_E, col = "#09ADAD", xlab = "Errors Committed", main = "Histogram of Errors Committed")
boxplot(moneyball$TEAM_FIELDING_DP, col = "#A71930", main = "Boxplot of Double Plays")
boxplot(moneyball$TEAM_FIELDING_E, col = "#09ADAD", main = "Boxplot of Errors Committed")
par(mfrow=c(1,1))

######## Scatterplot Matrix ##########
panel.cor <- function(x, y, digits=2, prefix="", cex.cor, ...)
{
  usr <- par("usr"); on.exit(par(usr))
  par(usr = c(0, 1, 0, 1))
  r <- abs(cor(x, y))
  txt <- format(c(r, 0.123456789), digits=digits)[1]
  txt <- paste(prefix, txt, sep="")
  if(missing(cex.cor)) cex.cor <- 0.8/strwidth(txt)
  text(0.5, 0.5, txt, cex = cex.cor * r)
}

# Batting Stats and Wins
pairs(moneyball[2:8], lower.panel=panel.smooth, upper.panel = panel.cor)

#Baserunning  Stats and Wins
pairs(~ moneyball$TARGET_WINS + moneyball$TEAM_BASERUN_CS + moneyball$TEAM_BASERUN_SB, lower.panel = panel.smooth)

#Pitcher Stats and Wins
pairs(~ moneyball$TARGET_WINS + moneyball$TEAM_PITCHING_BB + moneyball$TEAM_PITCHING_H + 
        moneyball$TEAM_PITCHING_HR + moneyball$TEAM_PITCHING_SO, lower.panel = panel.smooth)

pairs(moneyball[2,9,10,11,12,13])

######################### Part 2: Data Preparation #####################

#Add variables
#Number of First Base Hits
moneyball$TEAM_BATTING_1B = moneyball$TEAM_BATTING_H-moneyball$TEAM_BATTING_2B-moneyball$TEAM_BATTING_3B-moneyball$TEAM_BATTING_HR
#Success Ratio of Stolen Bases
moneyball$TEAM_BASERUN_SR = moneyball$TEAM_BASERUN_SB/(moneyball$TEAM_BASERUN_SB+moneyball$TEAM_BASERUN_CS)
#Strikeout Rate for Pitchers
moneyball$TEAM_PITCHING_SR = moneyball$TEAM_PITCHING_SO/(moneyball$TEAM_PITCHING_SO+moneyball$TEAM_PITCHING_H+moneyball$TEAM_PITCHING_HR+moneyball$TEAM_PITCHING_BB)


#Evaluation/Edit of Team Base Hits by Batters (TEAM_BATTING_H)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BATTING_H,c(.75))+1.5*(quantile(moneyball$TEAM_BATTING_H,c(.75))-quantile(moneyball$TEAM_BATTING_H,c(.25)))
lowerWhisker = quantile(moneyball$TEAM_BATTING_H,c(.25))-1.5*(quantile(moneyball$TEAM_BATTING_H,c(.75))-quantile(moneyball$TEAM_BATTING_H,c(.25)))
moneyball$FlagTEAM_BATTING_H = ifelse(is.na(moneyball$TEAM_BATTING_H),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BATTING_H[is.na(moneyball$TEAM_BATTING_H)] = median(moneyball$TEAM_BATTING_H,na.rm = TRUE)
moneyball$FlagTEAM_BATTING_H = ifelse(moneyball$TEAM_BATTING_H<=lowerWhisker,2,moneyball$FlagTEAM_BATTING_H)
moneyball$FlagTEAM_BATTING_H = ifelse(moneyball$TEAM_BATTING_H>=upperWhisker,3,moneyball$FlagTEAM_BATTING_H)
moneyball$TEAM_BATTING_H = ifelse(moneyball$FlagTEAM_BATTING_H==2,lowerWhisker,moneyball$TEAM_BATTING_H)
moneyball$TEAM_BATTING_H = ifelse(moneyball$FlagTEAM_BATTING_H==3,upperWhisker,moneyball$TEAM_BATTING_H)

#Evaluation/Edit of Team Single Hits (TEAM_BATTING_1B)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BATTING_1B,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_BATTING_1B,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BATTING_1B,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_BATTING_1B,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_BATTING_1B,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BATTING_1B,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_BATTING_1B = ifelse(is.na(moneyball$TEAM_BATTING_1B),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BATTING_1B[is.na(moneyball$TEAM_BATTING_1B)] = median(moneyball$TEAM_BATTING_1B,na.rm = TRUE)
moneyball$FlagTEAM_BATTING_1B = ifelse(moneyball$TEAM_BATTING_1B<=lowerWhisker,2,moneyball$FlagTEAM_BATTING_1B)
moneyball$FlagTEAM_BATTING_1B = ifelse(moneyball$TEAM_BATTING_1B>=upperWhisker,3,moneyball$FlagTEAM_BATTING_1B)
moneyball$TEAM_BATTING_1B = ifelse(moneyball$FlagTEAM_BATTING_1B==2,lowerWhisker,moneyball$TEAM_BATTING_1B)
moneyball$TEAM_BATTING_1B = ifelse(moneyball$FlagTEAM_BATTING_1B==3,upperWhisker,moneyball$TEAM_BATTING_1B)

#Evaluation/Edit of Team Doubles by Batters (TEAM_BATTING_2B)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BATTING_2B,c(.75))+1.5*(quantile(moneyball$TEAM_BATTING_2B,c(.75))-quantile(moneyball$TEAM_BATTING_2B,c(.25)))
lowerWhisker = quantile(moneyball$TEAM_BATTING_2B,c(.25))-1.5*(quantile(moneyball$TEAM_BATTING_2B,c(.75))-quantile(moneyball$TEAM_BATTING_2B,c(.25)))
moneyball$FlagTEAM_BATTING_2B = ifelse(is.na(moneyball$TEAM_BATTING_2B),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BATTING_2B[is.na(moneyball$TEAM_BATTING_2B)] = median(moneyball$TEAM_BATTING_2B,na.rm = TRUE)
moneyball$FlagTEAM_BATTING_2B = ifelse(moneyball$TEAM_BATTING_2B<=lowerWhisker,2,moneyball$FlagTEAM_BATTING_2B)
moneyball$FlagTEAM_BATTING_2B = ifelse(moneyball$TEAM_BATTING_2B>=upperWhisker,3,moneyball$FlagTEAM_BATTING_2B)
moneyball$TEAM_BATTING_2B = ifelse(moneyball$FlagTEAM_BATTING_2B==2,lowerWhisker,moneyball$TEAM_BATTING_2B)
moneyball$TEAM_BATTING_2B = ifelse(moneyball$FlagTEAM_BATTING_2B==3,upperWhisker,moneyball$TEAM_BATTING_2B)

#Evaluation/Edit of Team Triples by Batters (TEAM_BATTING_3B)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BATTING_3B,c(.75))+1.5*(quantile(moneyball$TEAM_BATTING_3B,c(.75))-quantile(moneyball$TEAM_BATTING_3B,c(.25)))
lowerWhisker = quantile(moneyball$TEAM_BATTING_3B,c(.25))-1.5*(quantile(moneyball$TEAM_BATTING_3B,c(.75))-quantile(moneyball$TEAM_BATTING_3B,c(.25)))
moneyball$FlagTEAM_BATTING_3B = ifelse(is.na(moneyball$TEAM_BATTING_3B),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BATTING_3B[is.na(moneyball$TEAM_BATTING_3B)] = median(moneyball$TEAM_BATTING_3B,na.rm = TRUE)
moneyball$FlagTEAM_BATTING_3B = ifelse(moneyball$TEAM_BATTING_3B<=lowerWhisker,2,moneyball$FlagTEAM_BATTING_3B)
moneyball$FlagTEAM_BATTING_3B = ifelse(moneyball$TEAM_BATTING_3B>=upperWhisker,3,moneyball$FlagTEAM_BATTING_3B)
moneyball$TEAM_BATTING_3B = ifelse(moneyball$FlagTEAM_BATTING_3B==2,lowerWhisker,moneyball$TEAM_BATTING_3B)
moneyball$TEAM_BATTING_3B = ifelse(moneyball$FlagTEAM_BATTING_3B==3,upperWhisker,moneyball$TEAM_BATTING_3B)

#Evaluation/Edit of Team Home Runs by Batters (TEAM_BATTING_HR)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BATTING_HR,c(.75))+1.5*(quantile(moneyball$TEAM_BATTING_HR,c(.75))-quantile(moneyball$TEAM_BATTING_HR,c(.25)))
lowerWhisker = quantile(moneyball$TEAM_BATTING_HR,c(.25))-1.5*(quantile(moneyball$TEAM_BATTING_HR,c(.75))-quantile(moneyball$TEAM_BATTING_HR,c(.25)))
moneyball$FlagTEAM_BATTING_HR = ifelse(is.na(moneyball$TEAM_BATTING_HR),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BATTING_HR[is.na(moneyball$TEAM_BATTING_HR)] = median(moneyball$TEAM_BATTING_HR,na.rm = TRUE)
moneyball$FlagTEAM_BATTING_HR = ifelse(moneyball$TEAM_BATTING_HR<=lowerWhisker,2,moneyball$FlagTEAM_BATTING_HR)
moneyball$FlagTEAM_BATTING_HR = ifelse(moneyball$TEAM_BATTING_HR>=upperWhisker,3,moneyball$FlagTEAM_BATTING_HR)
moneyball$TEAM_BATTING_HR = ifelse(moneyball$FlagTEAM_BATTING_HR==2,lowerWhisker,moneyball$TEAM_BATTING_HR)
moneyball$TEAM_BATTING_HR = ifelse(moneyball$FlagTEAM_BATTING_HR==3,upperWhisker,moneyball$TEAM_BATTING_HR)

#Evaluation/Edit of Team Walks by Batters (TEAM_BATTING_BB)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BATTING_BB,c(.75))+1.5*(quantile(moneyball$TEAM_BATTING_BB,c(.75))-quantile(moneyball$TEAM_BATTING_BB,c(.25)))
lowerWhisker = quantile(moneyball$TEAM_BATTING_BB,c(.25))-1.5*(quantile(moneyball$TEAM_BATTING_BB,c(.75))-quantile(moneyball$TEAM_BATTING_BB,c(.25)))
moneyball$FlagTEAM_BATTING_BB = ifelse(is.na(moneyball$TEAM_BATTING_BB),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BATTING_BB[is.na(moneyball$TEAM_BATTING_BB)] = median(moneyball$TEAM_BATTING_BB,na.rm = TRUE)
moneyball$FlagTEAM_BATTING_BB = ifelse(moneyball$TEAM_BATTING_BB<=lowerWhisker,2,moneyball$FlagTEAM_BATTING_BB)
moneyball$FlagTEAM_BATTING_BB = ifelse(moneyball$TEAM_BATTING_BB>=upperWhisker,3,moneyball$FlagTEAM_BATTING_BB)
moneyball$TEAM_BATTING_BB = ifelse(moneyball$FlagTEAM_BATTING_BB==2,lowerWhisker,moneyball$TEAM_BATTING_BB)
moneyball$TEAM_BATTING_BB = ifelse(moneyball$FlagTEAM_BATTING_BB==3,upperWhisker,moneyball$TEAM_BATTING_BB)

#Evaluation/Edit of Team Batters Hit by Pitches (TEAM_BATTING_HBP)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BATTING_HBP,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_BATTING_HBP,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BATTING_HBP,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_BATTING_HBP,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_BATTING_HBP,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BATTING_HBP,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_BATTING_HBP = ifelse(is.na(moneyball$TEAM_BATTING_HBP),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BATTING_HBP[is.na(moneyball$TEAM_BATTING_HBP)] = quantile(moneyball$TEAM_BATTING_HBP,c(.10),na.rm=TRUE)
moneyball$FlagTEAM_BATTING_HBP = ifelse(moneyball$TEAM_BATTING_HBP<=lowerWhisker,2,moneyball$FlagTEAM_BATTING_HBP)
moneyball$FlagTEAM_BATTING_HBP = ifelse(moneyball$TEAM_BATTING_HBP>=upperWhisker,3,moneyball$FlagTEAM_BATTING_HBP)
moneyball$TEAM_BATTING_HBP = ifelse(moneyball$FlagTEAM_BATTING_HBP==2,lowerWhisker,moneyball$TEAM_BATTING_HBP)
moneyball$TEAM_BATTING_HBP = ifelse(moneyball$FlagTEAM_BATTING_HBP==3,upperWhisker,moneyball$TEAM_BATTING_HBP)

#Evaluation/Edit of Team Strikeouts by Batters (TEAM_BATTING_SO)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BATTING_SO,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_BATTING_SO,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BATTING_SO,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_BATTING_SO,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_BATTING_SO,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BATTING_SO,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_BATTING_SO = ifelse(is.na(moneyball$TEAM_BATTING_SO),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BATTING_SO[is.na(moneyball$TEAM_BATTING_SO)] = median(moneyball$TEAM_BATTING_SO,na.rm = TRUE)
moneyball$FlagTEAM_BATTING_SO = ifelse(moneyball$TEAM_BATTING_SO<=lowerWhisker,2,moneyball$FlagTEAM_BATTING_SO)
moneyball$FlagTEAM_BATTING_SO = ifelse(moneyball$TEAM_BATTING_SO>=upperWhisker,3,moneyball$FlagTEAM_BATTING_SO)
moneyball$TEAM_BATTING_SO = ifelse(moneyball$FlagTEAM_BATTING_SO==2,lowerWhisker,moneyball$TEAM_BATTING_SO)
moneyball$TEAM_BATTING_SO = ifelse(moneyball$FlagTEAM_BATTING_SO==3,upperWhisker,moneyball$TEAM_BATTING_SO)

#Evaluation/Edit of Bases Stolen by Batters (TEAM_BASERUN_SB)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BASERUN_SB,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_BASERUN_SB,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BASERUN_SB,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_BASERUN_SB,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_BASERUN_SB,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BASERUN_SB,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_BASERUN_SB = ifelse(is.na(moneyball$TEAM_BASERUN_SB),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BASERUN_SB[is.na(moneyball$TEAM_BASERUN_SB)] = median(moneyball$TEAM_BASERUN_SB,na.rm = TRUE)
moneyball$FlagTEAM_BASERUN_SB = ifelse(moneyball$TEAM_BASERUN_SB<=lowerWhisker,2,moneyball$FlagTEAM_BASERUN_SB)
moneyball$FlagTEAM_BASERUN_SB = ifelse(moneyball$TEAM_BASERUN_SB>=upperWhisker,3,moneyball$FlagTEAM_BASERUN_SB)
moneyball$TEAM_BASERUN_SB = ifelse(moneyball$FlagTEAM_BASERUN_SB==2,lowerWhisker,moneyball$TEAM_BASERUN_SB)
moneyball$TEAM_BASERUN_SB = ifelse(moneyball$FlagTEAM_BASERUN_SB==3,upperWhisker,moneyball$TEAM_BASERUN_SB)

#Evaluation/Edit of Batters Caught Stealing (TEAM_BASERUN_CS)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BASERUN_CS,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_BASERUN_CS,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BASERUN_CS,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_BASERUN_CS,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_BASERUN_CS,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BASERUN_CS,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_BASERUN_CS = ifelse(is.na(moneyball$TEAM_BASERUN_CS),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BASERUN_CS[is.na(moneyball$TEAM_BASERUN_CS)] = median(moneyball$TEAM_BASERUN_CS,na.rm = TRUE)
moneyball$FlagTEAM_BASERUN_CS = ifelse(moneyball$TEAM_BASERUN_CS<=lowerWhisker,2,moneyball$FlagTEAM_BASERUN_CS)
moneyball$FlagTEAM_BASERUN_CS = ifelse(moneyball$TEAM_BASERUN_CS>=upperWhisker,3,moneyball$FlagTEAM_BASERUN_CS)
moneyball$TEAM_BASERUN_CS = ifelse(moneyball$FlagTEAM_BASERUN_CS==2,lowerWhisker,moneyball$TEAM_BASERUN_CS)
moneyball$TEAM_BASERUN_CS = ifelse(moneyball$FlagTEAM_BASERUN_CS==3,upperWhisker,moneyball$TEAM_BASERUN_CS)

#Evaluation/Edit of Stolen Base Success Rate (TEAM_BASERUN_SR)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_BASERUN_SR,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_BASERUN_SR,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BASERUN_SR,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_BASERUN_SR,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_BASERUN_SR,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_BASERUN_SR,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_BASERUN_SR = ifelse(is.na(moneyball$TEAM_BASERUN_SR),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_BASERUN_SR[is.na(moneyball$TEAM_BASERUN_SR)] = median(moneyball$TEAM_BASERUN_SR,na.rm = TRUE)
moneyball$FlagTEAM_BASERUN_SR = ifelse(moneyball$TEAM_BASERUN_SR<=lowerWhisker,2,moneyball$FlagTEAM_BASERUN_SR)
moneyball$FlagTEAM_BASERUN_SR = ifelse(moneyball$TEAM_BASERUN_SR>=upperWhisker,3,moneyball$FlagTEAM_BASERUN_SR)
moneyball$TEAM_BASERUN_SR = ifelse(moneyball$FlagTEAM_BASERUN_SR==2,lowerWhisker,moneyball$TEAM_BASERUN_SR)
moneyball$TEAM_BASERUN_SR = ifelse(moneyball$FlagTEAM_BASERUN_SR==3,upperWhisker,moneyball$TEAM_BASERUN_SR)

#Evaluation/Edit of Team Fielding Errors (TEAM_FIELDING_E)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_FIELDING_E,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_FIELDING_E,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_FIELDING_E,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_FIELDING_E,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_FIELDING_E,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_FIELDING_E,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_FIELDING_E = ifelse(is.na(moneyball$TEAM_FIELDING_E),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_FIELDING_E[is.na(moneyball$TEAM_FIELDING_E)] = median(moneyball$TEAM_FIELDING_E,na.rm = TRUE)
moneyball$FlagTEAM_FIELDING_E = ifelse(moneyball$TEAM_FIELDING_E<=lowerWhisker,2,moneyball$FlagTEAM_FIELDING_E)
moneyball$FlagTEAM_FIELDING_E = ifelse(moneyball$TEAM_FIELDING_E>=upperWhisker,3,moneyball$FlagTEAM_FIELDING_E)
moneyball$TEAM_FIELDING_E = ifelse(moneyball$FlagTEAM_FIELDING_E==2,lowerWhisker,moneyball$TEAM_FIELDING_E)
moneyball$TEAM_FIELDING_E = ifelse(moneyball$FlagTEAM_FIELDING_E==3,upperWhisker,moneyball$TEAM_FIELDING_E)

#Evaluation/Edit of Team Fielding Double Plays (TEAM_FIELDING_DP)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_FIELDING_DP,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_FIELDING_DP,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_FIELDING_DP,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_FIELDING_DP,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_FIELDING_DP,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_FIELDING_DP,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_FIELDING_DP = ifelse(is.na(moneyball$TEAM_FIELDING_DP),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_FIELDING_DP[is.na(moneyball$TEAM_FIELDING_DP)] = median(moneyball$TEAM_FIELDING_DP,na.rm = TRUE)
moneyball$FlagTEAM_FIELDING_DP = ifelse(moneyball$TEAM_FIELDING_DP<=lowerWhisker,2,moneyball$FlagTEAM_FIELDING_DP)
moneyball$FlagTEAM_FIELDING_DP = ifelse(moneyball$TEAM_FIELDING_DP>=upperWhisker,3,moneyball$FlagTEAM_FIELDING_DP)
moneyball$TEAM_FIELDING_DP = ifelse(moneyball$FlagTEAM_FIELDING_DP==2,lowerWhisker,moneyball$TEAM_FIELDING_DP)
moneyball$TEAM_FIELDING_DP = ifelse(moneyball$FlagTEAM_FIELDING_DP==3,upperWhisker,moneyball$TEAM_FIELDING_DP)

#Evaluation/Edit of Walks Allowed by Pitchers (TEAM_PITCHING_BB)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_PITCHING_BB,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_PITCHING_BB,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_PITCHING_BB,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_PITCHING_BB,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_PITCHING_BB,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_PITCHING_BB,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_PITCHING_BB = ifelse(is.na(moneyball$TEAM_PITCHING_BB),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_PITCHING_BB[is.na(moneyball$TEAM_PITCHING_BB)] = median(moneyball$TEAM_PITCHING_BB,na.rm = TRUE)
moneyball$FlagTEAM_PITCHING_BB = ifelse(moneyball$TEAM_PITCHING_BB<=lowerWhisker,2,moneyball$FlagTEAM_PITCHING_BB)
moneyball$FlagTEAM_PITCHING_BB = ifelse(moneyball$TEAM_PITCHING_BB>=upperWhisker,3,moneyball$FlagTEAM_PITCHING_BB)
moneyball$TEAM_PITCHING_BB = ifelse(moneyball$FlagTEAM_PITCHING_BB==2,lowerWhisker,moneyball$TEAM_PITCHING_BB)
moneyball$TEAM_PITCHING_BB = ifelse(moneyball$FlagTEAM_PITCHING_BB==3,upperWhisker,moneyball$TEAM_PITCHING_BB)

#Evaluation/Edit of Hits Allowed by Pitchers (TEAM_PITCHING_H)
#Whisker calculation inputs derived from summary results
upperWhisker = log(quantile(moneyball$TEAM_PITCHING_H,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_PITCHING_H,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_PITCHING_H,c(.25),na.rm=TRUE)))
lowerWhisker = log(quantile(moneyball$TEAM_PITCHING_H,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_PITCHING_H,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_PITCHING_H,c(.25),na.rm=TRUE)))
moneyball$FlagTEAM_PITCHING_H = ifelse(is.na(moneyball$TEAM_PITCHING_H),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_PITCHING_H = log(moneyball$TEAM_PITCHING_H)
moneyball$TEAM_PITCHING_H[is.na(moneyball$TEAM_PITCHING_H)] = median(moneyball$TEAM_PITCHING_H,na.rm = TRUE)
moneyball$FlagTEAM_PITCHING_H = ifelse(moneyball$TEAM_PITCHING_H<=lowerWhisker,2,moneyball$FlagTEAM_PITCHING_H)
moneyball$FlagTEAM_PITCHING_H = ifelse(moneyball$TEAM_PITCHING_H>=upperWhisker,3,moneyball$FlagTEAM_PITCHING_H)
moneyball$TEAM_PITCHING_H = ifelse(moneyball$FlagTEAM_PITCHING_H==2,lowerWhisker,moneyball$TEAM_PITCHING_H)
moneyball$TEAM_PITCHING_H = ifelse(moneyball$FlagTEAM_PITCHING_H==3,upperWhisker,moneyball$TEAM_PITCHING_H)

#Evaluation/Edit of Homeruns Allowed by Pitchers (TEAM_PITCHING_HR)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_PITCHING_HR,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_PITCHING_HR,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_PITCHING_HR,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_PITCHING_HR,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_PITCHING_HR,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_PITCHING_HR,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_PITCHING_HR = ifelse(is.na(moneyball$TEAM_PITCHING_HR),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_PITCHING_HR[is.na(moneyball$TEAM_PITCHING_HR)] = median(moneyball$TEAM_PITCHING_HR,na.rm = TRUE)
moneyball$FlagTEAM_PITCHING_HR = ifelse(moneyball$TEAM_PITCHING_HR<=lowerWhisker,2,moneyball$FlagTEAM_PITCHING_HR)
moneyball$FlagTEAM_PITCHING_HR = ifelse(moneyball$TEAM_PITCHING_HR>=upperWhisker,3,moneyball$FlagTEAM_PITCHING_HR)
moneyball$TEAM_PITCHING_HR = ifelse(moneyball$FlagTEAM_PITCHING_HR==2,lowerWhisker,moneyball$TEAM_PITCHING_HR)
moneyball$TEAM_PITCHING_HR = ifelse(moneyball$FlagTEAM_PITCHING_HR==3,upperWhisker,moneyball$TEAM_PITCHING_HR)

#Evaluation/Edit of Strikeouts by Pitchers (TEAM_PITCHING_SO)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_PITCHING_SO,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_PITCHING_SO,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_PITCHING_SO,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_PITCHING_SO,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_PITCHING_SO,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_PITCHING_SO,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_PITCHING_SO = ifelse(is.na(moneyball$TEAM_PITCHING_SO),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_PITCHING_SO[is.na(moneyball$TEAM_PITCHING_SO)] = median(moneyball$TEAM_PITCHING_SO,na.rm = TRUE)
moneyball$FlagTEAM_PITCHING_SO = ifelse(moneyball$TEAM_PITCHING_SO<=lowerWhisker,2,moneyball$FlagTEAM_PITCHING_SO)
moneyball$FlagTEAM_PITCHING_SO = ifelse(moneyball$TEAM_PITCHING_SO>=upperWhisker,3,moneyball$FlagTEAM_PITCHING_SO)
moneyball$TEAM_PITCHING_SO = ifelse(moneyball$FlagTEAM_PITCHING_SO==2,lowerWhisker,moneyball$TEAM_PITCHING_SO)
moneyball$TEAM_PITCHING_SO = ifelse(moneyball$FlagTEAM_PITCHING_SO==3,upperWhisker,moneyball$TEAM_PITCHING_SO)

#Evaluation/Edit of Pitcher Strikeout Rate (TEAM_PITCHING_SR)
#Whisker calculation inputs derived from summary results
upperWhisker = quantile(moneyball$TEAM_PITCHING_SR,c(.75),na.rm=TRUE)+1.5*(quantile(moneyball$TEAM_PITCHING_SR,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_PITCHING_SR,c(.25),na.rm=TRUE))
lowerWhisker = quantile(moneyball$TEAM_PITCHING_SR,c(.25),na.rm=TRUE)-1.5*(quantile(moneyball$TEAM_PITCHING_SR,c(.75),na.rm=TRUE)-quantile(moneyball$TEAM_PITCHING_SR,c(.25),na.rm=TRUE))
moneyball$FlagTEAM_PITCHING_SR = ifelse(is.na(moneyball$TEAM_PITCHING_SR),1,0)
#Input replacements for NA's and outliers
moneyball$TEAM_PITCHING_SR[is.na(moneyball$TEAM_PITCHING_SR)] = median(moneyball$TEAM_PITCHING_SR,na.rm = TRUE)
moneyball$FlagTEAM_PITCHING_SR = ifelse(moneyball$TEAM_PITCHING_SR<=lowerWhisker,2,moneyball$FlagTEAM_PITCHING_SR)
moneyball$FlagTEAM_PITCHING_SR = ifelse(moneyball$TEAM_PITCHING_SR>=upperWhisker,3,moneyball$FlagTEAM_PITCHING_SR)
moneyball$TEAM_PITCHING_SR = ifelse(moneyball$FlagTEAM_PITCHING_SR==2,lowerWhisker,moneyball$TEAM_PITCHING_SR)
moneyball$TEAM_PITCHING_SR = ifelse(moneyball$FlagTEAM_PITCHING_SR==3,upperWhisker,moneyball$TEAM_PITCHING_SR)

#Check that na's are gone. 
summary(moneyball)

#M4 Code starts here
####### Ridge Regression#######
library(tidyverse)
library(broom)
library(glmnet)

y = moneyball$TARGET_WINS
x <- model.matrix(TARGET_WINS~TEAM_BATTING_3B+TEAM_BATTING_H+TEAM_BATTING_BB+TEAM_BATTING_BB+
                  TEAM_BASERUN_SB+TEAM_BASERUN_CS+TEAM_FIELDING_E+TEAM_FIELDING_DP+
                  TEAM_PITCHING_HR,data=moneyball)

library(glmnet)
grid=10^seq(10,-2,length=100)
ridge.mod=glmnet(x,y,alpha=0,lambda=grid)
dim(coef(ridge.mod))
#ridge.mod$lambda[50]
#coef(ridge.mod)[,50]
#sqrt(sum(coef(ridge.mod)[-1,50]^2))
#ridge.mod$lambda[60]
#coef(ridge.mod)[,60]
#sqrt(sum(coef(ridge.mod)[-1,60]^2))
predict(ridge.mod,s=50,type="coefficients")[1:10,]
set.seed(1)
train=sample(1:nrow(x), nrow(x)/2)
test=(-train)
y.test=y[test]

ridge.mod=glmnet(x[train,],y[train],alpha=0,lambda=grid, thresh=1e-12)
ridge.pred=predict(ridge.mod,s=4,newx=x[test,])
mean((ridge.pred-y.test)^2)
mean((mean(y[train])-y.test)^2)

ridge.pred=predict(ridge.mod,s=1e10,newx=x[test,])
mean((ridge.pred-y.test)^2)

ridge.pred=predict(ridge.mod,s=0,newx=x[test,],exact=T,x=x[train,],y=y[train])
mean((ridge.pred-y.test)^2)
lm(y~x, subset=train)
predict(ridge.mod,s=0,exact=T,type="coefficients",x=x[train,],y=y[train])[1:10,]

#find optimal lambda
set.seed(1)
cv.out=cv.glmnet(x[train,],y[train],alpha=0)
plot(cv.out)
bestlam=cv.out$lambda.min
bestlam
#Rerun Ridge Regression with optimal lambda
ridge.pred=predict(ridge.mod,s=bestlam,newx=x[test,])
mean((ridge.pred-y.test)^2)
out=glmnet(x,y,alpha=0)
predict(out,type="coefficients",s=bestlam)[1:10,]

####### Lasso ######
#x and y are the same as in ridge regression

lasso.mod=glmnet(x[train,],y[train],alpha=1,lambda=grid)
plot(lasso.mod)

set.seed(1)
cv.out=cv.glmnet(x[train,],y[train],alpha=1)
plot(cv.out)
bestlam=cv.out$lambda.min
lasso.pred=predict(lasso.mod,s=bestlam,newx=x[test,])
mean((lasso.pred-y.test)^2)

out=glmnet(x,y,alpha=1,lambda=grid)
lasso.coef=predict(out,type="coefficients",s=bestlam)[1:37,]
lasso.coef
lasso.coef[lasso.coef!=0]
#Flagged Team pitching strikeouts and flagged batting homeruns have coefficients of 0

####### Bootstrap #########
library(boot)
#Statistic of interest - estimate alpha for TEAM_BATTING_H on TARGET_WINS
alpha.fn=function(data,index){
  X=data$TEAM_BATTING_H[index]
  Y=data$TARGET_WINS[index]
  return((var(Y)-cov(X,Y))/(var(X)+var(Y)-2*cov(X,Y)))
}
alpha.fn(moneyball,1:100)
set.seed(1)
alpha.fn(moneyball,sample(100,100,replace=T))
boot(moneyball,alpha.fn,R=1000)

#Estimating the Accuracy of a Linear Regression MOdel
boot.fn=function(data,index)
  return(coef(lm(TARGET_WINS~FlagTEAM_BASERUN_CS+FlagTEAM_BASERUN_SB+FlagTEAM_BASERUN_SR+FlagTEAM_BATTING_1B+FlagTEAM_BATTING_2B+FlagTEAM_BATTING_3B+
                   FlagTEAM_BATTING_BB+FlagTEAM_BATTING_H+FlagTEAM_BATTING_HBP+FlagTEAM_BATTING_HR+FlagTEAM_BATTING_SO+FlagTEAM_FIELDING_DP+
                   FlagTEAM_FIELDING_E+FlagTEAM_PITCHING_BB+FlagTEAM_PITCHING_H+FlagTEAM_PITCHING_HR+FlagTEAM_PITCHING_SO+FlagTEAM_PITCHING_SR+
                   TEAM_BASERUN_CS+TEAM_BASERUN_SB+TEAM_BASERUN_SR+TEAM_BATTING_1B+TEAM_BATTING_2B+TEAM_BATTING_3B+TEAM_BATTING_BB+
                   TEAM_BATTING_H+TEAM_BATTING_HBP+TEAM_BATTING_HR+TEAM_BATTING_SO+TEAM_FIELDING_DP+TEAM_FIELDING_E+TEAM_PITCHING_BB+
                   TEAM_PITCHING_H+TEAM_PITCHING_HR+TEAM_PITCHING_SO+TEAM_PITCHING_SR,data=data,subset=index)))
boot.fn(moneyball,1:500)

#Create bootstrap esitmates for the intercept and slope terms by random sampling from the observations with replacement. 
set.seed(1)
boot.fn(moneyball,sample(500,500,replace=T))
boot.fn(moneyball,sample(500,500,replace=T))

boot(moneyball,boot.fn,1000)
summary(lm(TARGET_WINS~FlagTEAM_BASERUN_CS+FlagTEAM_BASERUN_SB+FlagTEAM_BASERUN_SR+FlagTEAM_BATTING_1B+FlagTEAM_BATTING_2B+FlagTEAM_BATTING_3B+
             FlagTEAM_BATTING_BB+FlagTEAM_BATTING_H+FlagTEAM_BATTING_HBP+FlagTEAM_BATTING_HR+FlagTEAM_BATTING_SO+FlagTEAM_FIELDING_DP+
             FlagTEAM_FIELDING_E+FlagTEAM_PITCHING_BB+FlagTEAM_PITCHING_H+FlagTEAM_PITCHING_HR+FlagTEAM_PITCHING_SO+FlagTEAM_PITCHING_SR+
             TEAM_BASERUN_CS+TEAM_BASERUN_SB+TEAM_BASERUN_SR+TEAM_BATTING_1B+TEAM_BATTING_2B+TEAM_BATTING_3B+TEAM_BATTING_BB+
             TEAM_BATTING_H+TEAM_BATTING_HBP+TEAM_BATTING_HR+TEAM_BATTING_SO+TEAM_FIELDING_DP+TEAM_FIELDING_E+TEAM_PITCHING_BB+
             TEAM_PITCHING_H+TEAM_PITCHING_HR+TEAM_PITCHING_SO+TEAM_PITCHING_SR,data=moneyball))$coef
boot.fn=function(data,index)
  coefficients(lm(TARGET_WINS~FlagTEAM_BASERUN_CS+FlagTEAM_BASERUN_SB+FlagTEAM_BASERUN_SR+FlagTEAM_BATTING_1B+FlagTEAM_BATTING_2B+FlagTEAM_BATTING_3B+
                    FlagTEAM_BATTING_BB+FlagTEAM_BATTING_H+FlagTEAM_BATTING_HBP+FlagTEAM_BATTING_HR+FlagTEAM_BATTING_SO+FlagTEAM_FIELDING_DP+
                    FlagTEAM_FIELDING_E+FlagTEAM_PITCHING_BB+FlagTEAM_PITCHING_H+FlagTEAM_PITCHING_HR+FlagTEAM_PITCHING_SO+FlagTEAM_PITCHING_SR+
                    TEAM_BASERUN_CS+TEAM_BASERUN_SB+TEAM_BASERUN_SR+TEAM_BATTING_1B+TEAM_BATTING_2B+TEAM_BATTING_3B+TEAM_BATTING_BB+
                    TEAM_BATTING_H+TEAM_BATTING_HBP+TEAM_BATTING_HR+TEAM_BATTING_SO+TEAM_FIELDING_DP+TEAM_FIELDING_E+TEAM_PITCHING_BB+
                    TEAM_PITCHING_H+TEAM_PITCHING_HR+TEAM_PITCHING_SO+TEAM_PITCHING_SR,data=data,subset=index))
set.seed(1)
boot(moneyball,boot.fn,1000)
summary(lm(TARGET_WINS~FlagTEAM_BASERUN_CS+FlagTEAM_BASERUN_SB+FlagTEAM_BASERUN_SR+FlagTEAM_BATTING_1B+FlagTEAM_BATTING_2B+FlagTEAM_BATTING_3B+
             FlagTEAM_BATTING_BB+FlagTEAM_BATTING_H+FlagTEAM_BATTING_HBP+FlagTEAM_BATTING_HR+FlagTEAM_BATTING_SO+FlagTEAM_FIELDING_DP+
             FlagTEAM_FIELDING_E+FlagTEAM_PITCHING_BB+FlagTEAM_PITCHING_H+FlagTEAM_PITCHING_HR+FlagTEAM_PITCHING_SO+FlagTEAM_PITCHING_SR+
             TEAM_BASERUN_CS+TEAM_BASERUN_SB+TEAM_BASERUN_SR+TEAM_BATTING_1B+TEAM_BATTING_2B+TEAM_BATTING_3B+TEAM_BATTING_BB+
             TEAM_BATTING_H+TEAM_BATTING_HBP+TEAM_BATTING_HR+TEAM_BATTING_SO+TEAM_FIELDING_DP+TEAM_FIELDING_E+TEAM_PITCHING_BB+
             TEAM_PITCHING_H+TEAM_PITCHING_HR+TEAM_PITCHING_SO+TEAM_PITCHING_SR,data=moneyball))$coef

#################### Part 3: OLS Model Creation ############################################

library(MASS)
library(ISLR)
library(fmsb)
library(leaps)

#Function for Mean Square Error Calculation
mse <- function(sm) 
  mean(sm$residuals^2)

# Stepwise Approach by Akaike Information Criterion
stepwisemodel <- lm(formula = TARGET_WINS ~ TEAM_BATTING_1B + TEAM_BATTING_2B + TEAM_BATTING_3B + TEAM_BATTING_HR + 
                      TEAM_BATTING_H + TEAM_BATTING_BB + TEAM_BATTING_SO + TEAM_BASERUN_SB + TEAM_BASERUN_CS + TEAM_BATTING_HBP + 
                      TEAM_PITCHING_BB + TEAM_PITCHING_SO + TEAM_FIELDING_E + TEAM_FIELDING_DP + 
                      TEAM_PITCHING_H + TEAM_PITCHING_HR + TEAM_PITCHING_BB + TEAM_PITCHING_SO + TEAM_FIELDING_E +
                      TEAM_FIELDING_DP + TEAM_BASERUN_SR + TEAM_PITCHING_SR, data = moneyball)
stepwise <- stepAIC(stepwisemodel, direction = "both")
summary(stepwise)
VIF(stepwise)
sqrt(VIF(stepwise)) > 2

# All subsetsmixed regression by Adjusted R squared
subsets <- regsubsets(x = TARGET_WINS ~ TEAM_BATTING_1B + TEAM_BATTING_2B + TEAM_BATTING_3B + TEAM_BATTING_HR + 
                        TEAM_BATTING_H + TEAM_BATTING_BB + TEAM_BATTING_SO + TEAM_BASERUN_SB + TEAM_BASERUN_CS + TEAM_BATTING_HBP + 
                        TEAM_PITCHING_BB + TEAM_PITCHING_SO + TEAM_FIELDING_E + TEAM_FIELDING_DP + 
                        TEAM_PITCHING_H + TEAM_PITCHING_HR + TEAM_PITCHING_BB + TEAM_PITCHING_SO + TEAM_FIELDING_E +
                        TEAM_FIELDING_DP + TEAM_BASERUN_SR + TEAM_PITCHING_SR,  data = moneyball, nbest = 2, nvmax=8)
summary(subsets)
plot(subsets, scale="adjr2")

subset <- lm(TARGET_WINS ~ 
               TEAM_BATTING_3B + TEAM_BATTING_H + TEAM_BATTING_BB + TEAM_BASERUN_SB +
               TEAM_BASERUN_CS + TEAM_FIELDING_E + TEAM_FIELDING_DP + TEAM_PITCHING_HR, data = moneyball)
summary(subset)
VIF(subset)
sqrt(VIF(subset)) > 2

# Model 3 - regression on all varaibles by R squared. 
model3 <- lm(formula = TARGET_WINS ~ TEAM_BATTING_1B + TEAM_BATTING_2B + TEAM_BATTING_3B + TEAM_BATTING_HR + 
               TEAM_BATTING_H + TEAM_BATTING_BB + TEAM_BATTING_SO + TEAM_BASERUN_SB + TEAM_BASERUN_CS + 
               TEAM_PITCHING_BB + TEAM_PITCHING_SO + TEAM_FIELDING_E + TEAM_FIELDING_DP + 
               TEAM_PITCHING_H + TEAM_PITCHING_HR + TEAM_PITCHING_BB + TEAM_PITCHING_SO + TEAM_FIELDING_E +
               TEAM_FIELDING_DP + TEAM_BASERUN_SR + TEAM_PITCHING_SR, data = moneyball)
summary(model3)
VIF(model3)
sqrt(VIF(model3)) > 2

######## Performance #######
AIC(stepwise)
AIC(subset)
AIC(model3)
mse(stepwise)
mse(subset)
mse(model3)
VIF(stepwise)
VIF(subset)
VIF(model3)

#####
#Designated proper working environment on my computer. You will want to make sure it is in proper place for your computer.
#####

#################### Test Data ##########################
moneyball_test=read.csv("moneyball_test_2.csv",header=T)

# Calculating new varaibles and fixing NA's
moneyball_test$TEAM_BATTING_1B <- moneyball_test$TEAM_BATTING_H - moneyball_test$TEAM_BATTING_HR -
  moneyball_test$TEAM_BATTING_3B -moneyball_test$TEAM_BATTING_2B
moneyball_test$TEAM_PITCHING_SR = moneyball_test$TEAM_PITCHING_SO/(moneyball_test$TEAM_PITCHING_SO+moneyball_test$TEAM_PITCHING_H+moneyball_test$TEAM_PITCHING_HR+moneyball_test$TEAM_PITCHING_BB)
summary(moneyball_test)

moneyball_test$TEAM_BASERUN_SB[is.na(moneyball_test$TEAM_BASERUN_SB)] = median(moneyball$TEAM_BASERUN_SB, na.rm = TRUE)
moneyball_test$TEAM_BASERUN_CS[is.na(moneyball_test$TEAM_BASERUN_CS)] = median(moneyball$TEAM_BASERUN_CS, na.rm = TRUE)
moneyball_test$TEAM_FIELDING_DP[is.na(moneyball_test$TEAM_FIELDING_DP)] = median(moneyball$TEAM_FIELDING_DP, na.rm = TRUE)

# Stand Alone Scoring for model3
moneyball_test$P_TARGET_WINS <- 3.1511746154 + 0.1528732850*moneyball_test$TEAM_BATTING_3B + 
  0.043709*moneyball_test$TEAM_BATTING_H +
  0.017048*moneyball_test$TEAM_BATTING_BB +
  0.044477*moneyball_test$TEAM_BASERUN_SB -
  0.054562*moneyball_test$TEAM_BASERUN_CS -
  0.052617*moneyball_test$TEAM_FIELDING_E - 
  0.116462*moneyball_test$TEAM_FIELDING_DP +
  0.039035*moneyball_test$TEAM_PITCHING_HR

# Stand Alone Scoring with Ridge Regression Coefficients
moneyball_test$P_TARGET_WINS_Ridge <- 20.69902424 + 0.13776566*moneyball_test$TEAM_BATTING_3B + 
  0.04215311*moneyball_test$TEAM_BATTING_H +
  0.01860889*moneyball_test$TEAM_BATTING_BB +
  0.03951739*moneyball_test$TEAM_BASERUN_SB -
  0.04132976*moneyball_test$TEAM_BASERUN_CS -
  0.04472779*moneyball_test$TEAM_FIELDING_E - 
  0.10993729*moneyball_test$TEAM_FIELDING_DP +
  0.03909117*moneyball_test$TEAM_PITCHING_HR

#Evaluate results for Prediction add any necessary adjustments
summary(moneyball_test$P_TARGET_WINS)
hist(moneyball_test$P_TARGET_WINS)
boxplot(moneyball_test$P_TARGET_WINS, col = "#A71930", main = "Boxplot of Predicted Wins")
moneyball_test$P_TARGET_WINS = ifelse(moneyball_test$P_TARGET_WINS<0,0,moneyball_test$P_TARGET_WINS)
summary(moneyball_test$P_TARGET_WINS)
hist(moneyball_test$P_TARGET_WINS)
boxplot(moneyball_test$P_TARGET_WINS, col = "#A71930", main = "Adjusted Boxplot of Predicted Wins with Ridge Regression Coefficients")


#Evaluate results for Ridge M4 and add any necessary adjustments
summary(moneyball_test$P_TARGET_WINS_Ridge)
hist(moneyball_test$P_TARGET_WINS_Ridge)
boxplot(moneyball_test$P_TARGET_WINS_Ridge, col = "#A71930", main = "Boxplot of Predicted Wins")
moneyball_test$P_TARGET_WINS_Ridge = ifelse(moneyball_test$P_TARGET_WINS_Ridge<0,0,moneyball_test$P_TARGET_WINS_Ridge)
summary(moneyball_test$P_TARGET_WINS_Ridge)
hist(moneyball_test$P_TARGET_WINS_Ridge)
boxplot(moneyball_test$P_TARGET_WINS_Ridge, col = "#A71930", main = "Adjusted Boxplot of Predicted Wins with Ridge Regression Coefficients")

#subset of data set for the deliverable "Scored data file"
prediction <- moneyball_test[c("INDEX","P_TARGET_WINS_Ridge")]
#####
#Note, this next function will output a CSV file in your work environment called write.csv.
#####

#Prediction File 
write.csv(prediction, file = "HelpM4.csv")