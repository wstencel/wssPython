#####
#Designated proper working environment on my computer. You will want to make sure it is in proper place for your computer.
#####
setwd("D:/Class/Online MSBA/ML1 Online/Mod2")
moneyball=read.csv("moneyball_training_2.csv",header=T)
attach(moneyball)
					  
####Data Exploration####

str(moneyball) #17 variables: 1 index, 1 response, 15 predictors
summary(moneyball) #There are many NA values.  TEAM_BATTING_HBP has 2085 NAs
#sum(length(which(is.na(moneyball[,3])))) #Return the quantity of NA for a specified column

#Wins
par(mfrow=c(1,2))
hist(TARGET_WINS, col = "gold", xlab = "Target Wins", main = "Histogram of Wins")
boxplot(TARGET_WINS, col = "gold", main = "Boxplot of Wins")

#Batting
##Hits Doubles and Triples--Outliers primarily in high values. Right skewed
par(mfrow=c(2,3))
hist(TEAM_BATTING_H, col = "light blue", xlab = "Team_Batting_H", main = "Histogram of Hits")
hist(TEAM_BATTING_2B, col = "blue", xlab = "Doubles", main = "Histogram of Doubles")
hist(TEAM_BATTING_3B, col = "dark blue", xlab = "Triples", main = "Histogram of Triples")
boxplot(TEAM_BATTING_H, col = "light blue", main = "Boxplot of Hits")
boxplot(TEAM_BATTING_2B, col = "blue", main = "Boxplot of Doubles")
boxplot(TEAM_BATTING_3B, col = "dark blue", main = "Boxplot of Triples")

##Home Runs, Walks, Strikeouts, and HBP--Outliers in Walks primarily in low values
par(mfrow=c(2,4))
hist(TEAM_BATTING_HR, col = "light blue", xlab = "Home Runs", main = "Histogram of Home Runs")
hist(TEAM_BATTING_BB, col = "steel blue", xlab = "Walks", main = "Histogram of Walks")
hist(TEAM_BATTING_SO, col = "blue", xlab = "Strikeouts", main = "Histogram of Strikeouts")
hist(TEAM_BATTING_HBP, col = "dark blue", xlab = "Hit By Pitches", main = "Histogram of HBP")
boxplot(TEAM_BATTING_HR, col = "light blue", main = "Boxplot of Home Runs")
boxplot(TEAM_BATTING_BB, col = "steel blue", main = "Boxplot of Walks")
boxplot(TEAM_BATTING_SO, col = "blue", main = "Boxplot of Strikeouts")
boxplot(TEAM_BATTING_HBP, col = "dark blue", main = "Boxplot of HBP")

#Baserun
##Stolen Bases and Caught Stealing--Outliers primarily in upper values. Right skewed
par(mfrow=c(2,2))
hist(TEAM_BASERUN_SB, col = "light blue", xlab = "Stolen Bases", main = "Histogram of Steals")
hist(TEAM_BASERUN_CS, col = "steel blue", xlab = "Caught Stealing", main = "Histogram of CS")
boxplot(TEAM_BASERUN_SB, col = "light blue", main = "Boxplot of Steals")
boxplot(TEAM_BASERUN_CS, col = "steel blue", main = "Boxplot of CS")

#Fielding
##Double Plays (outliers in upper and lower values) and Errors (outliers in upper values. right skewed)
hist(TEAM_FIELDING_DP, col = "blue", xlab = "Double Plays", main = "Histogram of Double Plays")
hist(TEAM_FIELDING_E, col = "dark blue", xlab = "Errors Committed", main = "Histogram of Errors Committed")
boxplot(TEAM_FIELDING_DP, col = "blue", main = "Boxplot of Double Plays")
boxplot(TEAM_FIELDING_E, col = "dark blue", main = "Boxplot of Errors Committed")

#Pitching
##Hits, Home Runs, Walks, and Strikeouts: Outliers in upper values
par(mfrow=c(2,4))
hist(TEAM_PITCHING_H, col = "light blue", xlab = "Hits Allowed", main = "Histogram of Hits Against")
hist(TEAM_PITCHING_HR, col = "steel blue", xlab = "Home Runs Allowed", main = "Histograms of HR Against")
hist(TEAM_PITCHING_BB, col = "blue", xlab = "Walks Allowed", main = "Histogram of Walks Allowed")
hist(TEAM_PITCHING_SO, col = "dark blue", xlab = "Strikeouts", main = "Histograms of Strikeouts")
boxplot(TEAM_PITCHING_H, col = "light blue", main = "Boxplot of Hits Allowed")
boxplot(TEAM_PITCHING_HR, col = "steel blue", main = "Boxplot of HR Allowed")
boxplot(TEAM_PITCHING_BB, col = "blue", main = "Boxplot of Walks Allowed")
boxplot(TEAM_PITCHING_SO, col = "dark blue", main = "Boxplot of Strikeouts")

## Consider dropping TEAM_BATTING_HBP because it has 2085 NAs

#Corrletaion Matrix
library("PerformanceAnalytics")
chart.Correlation(moneyball[,2:17], histogram=TRUE, na.action=na.omit)
  #High correlation between predictors (>.6)
    #TEAM_BATTING_HR and TEAM_PITCHING_HR
    #TEAM_BATTING_HR and TEAM_BATTING_SO
    #TEAM_BATTING_HR and TEAM_BATTING_3B
    #TEAM_BATTING_3B and TEAM_BATTING_SO
    #TEAM_BATTING_BB and TEAM_FIELDING_E
    #TEAM_BATTING_SO and TEAM_PITCHING_HR
    #TEAM_BASERUN_SB and TEAM_BASERUN_CS
    #TEAM_PITCHING_H and TEAM_FIELDING_E
  #Low correlation with response
    #TEAM_BATTING_SO
    #TEAM_BASERUN_CS
    #TEAM_BATTING_HBP
    #TEAM_FIELDING_DP

####Data Preparation####

#Create function to correct for outliers
outlier_impute=function(df,dftest,column){
  min=boxplot.stats(df[,column])$stats[2]-1.5*IQR(df[,column],na.rm = TRUE)
  max=boxplot.stats(df[,column])$stats[4]+1.5*IQR(df[,column],na.rm = TRUE)
  flgO=as.factor(ifelse(dftest[,column] %in% boxplot.stats(dftest[,column])$out, 1, 0))
  impO=as.numeric(ifelse(dftest[,column] %in% boxplot.stats(dftest[,column])$out, ifelse(dftest[,column]>boxplot.stats(dftest[,column])$stats[3], max,min), dftest[,column]))
  eval.parent(substitute(dftest$flag<-flgO))
  eval.parent(substitute(dftest[,column]<-impO))
}

#Create function to correct for missing values
missingValue=function(df,dftest,column){
  flgM=as.factor(ifelse(is.na(dftest[,column]),1,0))
  impM=as.numeric(ifelse(is.na(dftest[,column]),median(df[,column],na.rm=TRUE),dftest[,column]))
  eval.parent(substitute(dftest$flag<-flgM))
  eval.parent(substitute(dftest[,column]<-impM))
}

#Correct for outliers and missing values using custom functions
for (i in 2:17){
  outlier_impute(moneyball,moneyball,i)
  colnames(moneyball)[2*(i-1)+16]=paste("flagOutlier",colnames(moneyball)[i],sep="_")
  missingValue(moneyball,moneyball,i)
  colnames(moneyball)[2*(i-1)+17]=paste("flagMissing",colnames(moneyball)[i],sep="_")
}
moneyball=moneyball[,colSums(moneyball!=0)>0] #Remove missing value or outlier flag for variables with no missing values or outliers

par(mfrow=c(4,4))
plot(TEAM_BATTING_H,TARGET_WINS)
plot(TEAM_BATTING_2B,TARGET_WINS)
plot(TEAM_BATTING_3B,TARGET_WINS)
plot(TEAM_BATTING_HR,TARGET_WINS)

plot(TEAM_BATTING_BB,TARGET_WINS)
plot(TEAM_BATTING_SO,TARGET_WINS)
plot(TEAM_BASERUN_SB,TARGET_WINS)
plot(TEAM_BASERUN_CS,TARGET_WINS)

plot(TEAM_BATTING_HBP,TARGET_WINS)
plot(TEAM_PITCHING_H,TARGET_WINS)
plot(TEAM_PITCHING_HR,TARGET_WINS)
plot(TEAM_PITCHING_BB,TARGET_WINS)

plot(TEAM_PITCHING_SO,TARGET_WINS)
plot(TEAM_FIELDING_E,TARGET_WINS)
plot(TEAM_FIELDING_DP,TARGET_WINS)
par(mfrow=c(1,1))
#Relationships are moderately linear at best

#Check that the outliers and missing values were properly imputed
summary(moneyball)

#Corrletaion Matrix
chart.Correlation(moneyball[,2:17], histogram=TRUE) 
#TEAM_BATTING_H, TEAM_BATTING_2B, and TEAM_BATTING_BB have the highest correlation with wins
#TEAM_BASERUN_CS, TEAM_BATTING_HBP, and TEAM_FIELDING_DP still do not have significant correlation with the response

####Transforming Data####
attach(moneyball)
moneyball$sqrt_TEAM_PITCHING_HR= sqrt(TEAM_PITCHING_HR)
moneyball$sqrt_TEAM_BATTING_3B= sqrt(TEAM_BATTING_3B)
moneyball$sqrt_TEAM_BASERUN_SB=sqrt(TEAM_BASERUN_SB)
moneyball$log_TEAM_PITCHING_SO <- log(TEAM_PITCHING_SO+1)
moneyball$TEAM_BATTING_1B <- TEAM_BATTING_H - TEAM_BATTING_HR -
  TEAM_BATTING_3B -TEAM_BATTING_2B

####GLM Model Creation ####
attach(moneyball)
#Forward-backward regression
#mlm2a.fit=step(mlm1b.fit,direction="both",trace=1)

library(dplyr)
glm2_data=select(moneyball,TARGET_WINS, TEAM_BATTING_1B,TEAM_BATTING_H,sqrt_TEAM_BATTING_3B , TEAM_BATTING_HR  , TEAM_BATTING_BB , TEAM_BATTING_SO ,
                   sqrt_TEAM_BASERUN_SB , TEAM_BASERUN_CS , TEAM_PITCHING_H , TEAM_PITCHING_BB , log_TEAM_PITCHING_SO ,
                   TEAM_FIELDING_E , TEAM_FIELDING_DP)

glm2=glm(TARGET_WINS ~.,data=glm2_data) #derived from best subset regression of all variables (transformed when necessary) without TEAM_BATTING_HBP

#Forward-backward regression

#Two-way interaction between groups (i.e. batting, pitching, etc.)
# mlm4a.fit =lm(TARGET_WINS ~(TEAM_BATTING_H + TEAM_BATTING_HR + TEAM_BATTING_2B+sqrt_TEAM_BATTING_3B + TEAM_BATTING_BB)^2 +
#                 (sqrt_TEAM_BASERUN_SB + TEAM_BASERUN_CS)^2 + (TEAM_PITCHING_H + sqrt_TEAM_PITCHING_HR + TEAM_PITCHING_BB + log_TEAM_PITCHING_SO)^2 +
#                 (TEAM_FIELDING_E + TEAM_FIELDING_DP)^2)
# mlm4.fit=step(mlm4a.fit, diretion='both',trace=1)
glm4_data=select(moneyball, TARGET_WINS, TEAM_BATTING_H,TEAM_BATTING_HR,TEAM_BATTING_2B,sqrt_TEAM_BATTING_3B,TEAM_BATTING_BB,sqrt_TEAM_BASERUN_SB,
  TEAM_BASERUN_CS,TEAM_PITCHING_H ,sqrt_TEAM_PITCHING_HR,TEAM_PITCHING_BB ,log_TEAM_PITCHING_SO,TEAM_FIELDING_E,TEAM_FIELDING_DP)

glm4=glm(TARGET_WINS~ .+ TEAM_BATTING_H:TEAM_BATTING_2B+TEAM_BATTING_H:sqrt_TEAM_BATTING_3B+
           TEAM_BATTING_HR:TEAM_BATTING_2B+TEAM_BATTING_HR:TEAM_BATTING_BB+
           TEAM_BATTING_2B:sqrt_TEAM_BATTING_3B +TEAM_BATTING_2B:TEAM_BATTING_BB+TEAM_PITCHING_H:sqrt_TEAM_PITCHING_HR +
           TEAM_PITCHING_H:TEAM_PITCHING_BB +sqrt_TEAM_PITCHING_HR:log_TEAM_PITCHING_SO, data=glm4_data) #Based on forward-backward regression of model mlm4a

####GLM Performance####
# #Function for Mean Square Error Calculation PR
# mse <- function(sm) 
#   mean(sm$residuals^2)

summary(glm2)
summary(glm4)

library(car)
crPlots(glm2)

vif(glm2) #Exhibits multicolinearity
vif(glm4) #Interactions cause high vifs

library(rsq)
rsq(glm2,adj=TRUE) #.289
rsq(glm4,adj=TRUE) #.361

#Estimate test error
#Separate into training and test data
set.seed(1)
train=sample(2276,1138)

mean((TARGET_WINS-predict(glm2,moneyball))[-train]^2) #163.5
mean((TARGET_WINS-predict(glm4,moneyball))[-train]^2) #146.2

#k-fold cross validation
library(boot)
glm2.cv.err=cv.glm(glm2_data,glm2,K=10)$delta #$168.3
glm4.cv.err=cv.glm(glm4_data,glm4,K=10)$delta #152.2

####Bootstrap for Measures of Fit####

##Bootstrap for AIC
#AIC bootstrap for glm2
boot.aic2=function(data,index) return (glm(TARGET_WINS ~., data=glm2_data, subset=index)$aic)
boot(glm2_data,boot.aic2,2000) #18105.99 error 86.98

#AIC bootstrap for glm4
boot.aic4=function(data,index) return (glm(TARGET_WINS~TEAM_BATTING_H+TEAM_BATTING_HR+TEAM_BATTING_2B+sqrt_TEAM_BATTING_3B+TEAM_BATTING_BB+sqrt_TEAM_BASERUN_SB+
                                             TEAM_BASERUN_CS+TEAM_PITCHING_H +sqrt_TEAM_PITCHING_HR+TEAM_PITCHING_BB +log_TEAM_PITCHING_SO+TEAM_FIELDING_E+TEAM_FIELDING_DP+
                                             TEAM_BATTING_H:TEAM_BATTING_2B+TEAM_BATTING_H:sqrt_TEAM_BATTING_3B+TEAM_BATTING_HR:TEAM_BATTING_2B+TEAM_BATTING_HR:TEAM_BATTING_BB+
                                             TEAM_BATTING_2B:sqrt_TEAM_BATTING_3B +TEAM_BATTING_2B:TEAM_BATTING_BB+TEAM_PITCHING_H:sqrt_TEAM_PITCHING_HR +
                                             TEAM_PITCHING_H:TEAM_PITCHING_BB +sqrt_TEAM_PITCHING_HR:log_TEAM_PITCHING_SO, data=glm4_data, subset=index)$aic)
boot(glm4_data,boot.aic4,2000) #17872.46 error 79.22

##Bootstrap for MSE
#MSE bootstrap for glm2
boot.mse2=function(data,index) {
  a=glm(TARGET_WINS ~., data=glm2_data, subset=index)
  return(mean(a$residuals^2)) 
}

boot(glm2_data,boot.mse2,2000) #164.7 error 6.09

#MSE bootstrap for glm4
boot.mse4=function(data,index) {
  a=glm(TARGET_WINS~TEAM_BATTING_H+TEAM_BATTING_HR+TEAM_BATTING_2B+sqrt_TEAM_BATTING_3B+TEAM_BATTING_BB+sqrt_TEAM_BASERUN_SB+
                                             TEAM_BASERUN_CS+TEAM_PITCHING_H +sqrt_TEAM_PITCHING_HR+TEAM_PITCHING_BB +log_TEAM_PITCHING_SO+TEAM_FIELDING_E+TEAM_FIELDING_DP+
                                             TEAM_BATTING_H:TEAM_BATTING_2B+TEAM_BATTING_H:sqrt_TEAM_BATTING_3B+TEAM_BATTING_HR:TEAM_BATTING_2B+TEAM_BATTING_HR:TEAM_BATTING_BB+
                                             TEAM_BATTING_2B:sqrt_TEAM_BATTING_3B +TEAM_BATTING_2B:TEAM_BATTING_BB+TEAM_PITCHING_H:sqrt_TEAM_PITCHING_HR +
                                             TEAM_PITCHING_H:TEAM_PITCHING_BB +sqrt_TEAM_PITCHING_HR:log_TEAM_PITCHING_SO, data=data, subset=index)
  return(mean(a$residuals^2))
}
boot(glm4_data,boot.mse4,2000) #147.5 error 5.25

####Coefficient Bootstrap estimates for glm2####
# #Coefficient bootstrap for glm2
# boot.coef2=function(data,index) {
#   a=glm(TARGET_WINS ~TEAM_BATTING_1B+TEAM_BATTING_H+sqrt_TEAM_BATTING_3B + TEAM_BATTING_HR  + TEAM_BATTING_BB + TEAM_BATTING_SO +
#           sqrt_TEAM_BASERUN_SB + TEAM_BASERUN_CS + TEAM_PITCHING_H + TEAM_PITCHING_BB + log_TEAM_PITCHING_SO +
#           TEAM_FIELDING_E + TEAM_FIELDING_DP, data=data, subset=index)
#   return(a$coefficients)
# }
# 
# boot(glm2_data,boot.coef2,2000)
# 
# #Coefficient bootstrap for glm3
# boot.coef3=function(data,index) {
#   a=glm(TARGET_WINS ~TEAM_BATTING_H + TEAM_BATTING_2B+sqrt_TEAM_BATTING_3B + TEAM_BATTING_BB + 
#           sqrt_TEAM_BASERUN_SB + TEAM_BASERUN_CS + TEAM_PITCHING_H + sqrt_TEAM_PITCHING_HR + TEAM_PITCHING_BB + log_TEAM_PITCHING_SO +
#           TEAM_FIELDING_E + TEAM_FIELDING_DP, data=data, subset=index)
#   return(a$coefficients)
# }
# 
# boot(glm2_data,boot.coef3,2000)
# 
# #Coefficient bootstrap for glm4
# boot.coef4=function(data,index) {
#   a=glm(TARGET_WINS~TEAM_BATTING_H+TEAM_BATTING_HR+TEAM_BATTING_2B+sqrt_TEAM_BATTING_3B+TEAM_BATTING_BB+sqrt_TEAM_BASERUN_SB+
#           TEAM_BASERUN_CS+TEAM_PITCHING_H +sqrt_TEAM_PITCHING_HR+TEAM_PITCHING_BB +log_TEAM_PITCHING_SO+TEAM_FIELDING_E+TEAM_FIELDING_DP+
#           TEAM_BATTING_H:TEAM_BATTING_2B+TEAM_BATTING_H:sqrt_TEAM_BATTING_3B+TEAM_BATTING_HR:TEAM_BATTING_2B+TEAM_BATTING_HR:TEAM_BATTING_BB+
#           TEAM_BATTING_2B:sqrt_TEAM_BATTING_3B +TEAM_BATTING_2B:TEAM_BATTING_BB+TEAM_PITCHING_H:sqrt_TEAM_PITCHING_HR +
#           TEAM_PITCHING_H:TEAM_PITCHING_BB +sqrt_TEAM_PITCHING_HR:log_TEAM_PITCHING_SO, data=data, subset=index)
#   return(a$coefficients)
# }
# 
# boot(glm2_data,boot.coef4,2000)


####Ridge Regression####
##Based off of glm2
library(glmnet)
set.seed(1)
train=sample (1: nrow(moneyball), nrow(moneyball)/2)
test=(-train)
x=as.matrix(glm2_data[,-1])
y=glm2_data[,1]
y.test=y[test]

grid=10^seq(10,-2,length=100)
ridge.mod=glmnet(x=x[train,],y=y[train],alpha=0,lambda=grid,thresh=1e-12)
cv.out=cv.glmnet(x[train,],y[train],alpha=0)
plot(cv.out)
bestlam=cv.out$lambda.min
bestlam #The best lambda is .5921
#With is the test MSE associated with \lambda=.5921?
ridge.pred=predict(ridge.mod,s=bestlam,newx=as.matrix(glm2_data[test,-1]))
mean((ridge.pred-y.test)^2) #167.7986

#Refit ridge regression model with with data and cross-validated optimal lambda
out=glmnet(x,y,alpha=0)
predict(out,type="coefficients",s=bestlam)

####Lasso Regression####
#Includes interactions

glm5_data=glm4_data
attach(glm5_data)
glm5_data$BAT_H.BAT_2B=TEAM_BATTING_H*TEAM_BATTING_2B
glm5_data$BAT_H.BAT_3B=TEAM_BATTING_H*sqrt_TEAM_BATTING_3B
glm5_data$BAT_HR.BAT_2B=TEAM_BATTING_HR*TEAM_BATTING_2B
glm5_data$BAT_HR.BAT_BB=TEAM_BATTING_HR*TEAM_BATTING_BB
glm5_data$BAT_2B.sBAT_3B=TEAM_BATTING_2B*sqrt_TEAM_BATTING_3B
glm5_data$BAT_2B.BAT_BB=TEAM_BATTING_2B*TEAM_BATTING_BB
glm5_data$PIT_H.sPIT_HR=TEAM_PITCHING_H*sqrt_TEAM_PITCHING_HR
glm5_data$PIT_H.PIT_BB=TEAM_PITCHING_H*TEAM_PITCHING_BB 
glm5_data$sPIT_HR.lPIT_SO=sqrt_TEAM_PITCHING_HR*log_TEAM_PITCHING_SO
attach(glm5_data)

x=as.matrix(glm5_data[,-1])
y=glm5_data[,1]
y.test=y[test]

grid=10^seq(10,-2,length=100)
lasso.mod=glmnet(x=x[train,],y=y[train],alpha=1,lambda=grid,thresh=1e-12)
cv.out=cv.glmnet(x[train,],y[train],alpha=1)
plot(cv.out)
bestlam=cv.out$lambda.min
bestlam #The best lambda is .011
#With is the test MSE associated with \lambda=.011?
lasso.pred=predict(lasso.mod,s=bestlam,newx=as.matrix(glm5_data[test,-1]))
mean((lasso.pred-y.test)^2) #155.9083

#Fit lasso regression model with optimal lambda
out=glmnet(x,y,alpha=1)
predict(out,type="coefficients",s=bestlam)[1:20,]

####Partial Least Squares####
#Includes interactions
set.seed(1)
library(pls)
attach(glm5_data)
x=model.matrix(TARGET_WINS~.-INDEX,data=glm5_data)[,-1]
y=glm5_data$TARGET_WINS

train=sample(1:nrow(x), nrow(x)/2)
test=(-train)
y.test=y[test]

pls.fit=plsr(TARGET_WINS~., data=glm5_data,subset=train,scale=TRUE, validation="CV")
summary(pls.fit)
validationplot(pls.fit,val.type="MSEP")
pls.pred=predict(pls.fit,x[test,],ncomp=15)
mean((pls.pred-y.test)^2) #156.32
pls.fit=plsr(TARGET_WINS~., data=glm5_data,scale=TRUE,ncomp=15)
summary(pls.fit) #36% of the variance in TARGET_WINS is explained by the 15 component regression

####Generalized Additive Models####
# GAMs
library(gam)

gam=gam(TARGET_WINS~TEAM_BATTING_H+TEAM_BATTING_HR+TEAM_BATTING_2B +
          sqrt_TEAM_BATTING_3B +TEAM_BATTING_BB +sqrt_TEAM_BASERUN_SB +
          TEAM_BASERUN_CS+s(TEAM_PITCHING_H,5)+sqrt_TEAM_PITCHING_HR+
          TEAM_PITCHING_BB+ log_TEAM_PITCHING_SO +
          s(TEAM_FIELDING_E,5) + s(TEAM_FIELDING_DP,5)+
          BAT_H.BAT_2B +BAT_H.BAT_3B+BAT_HR.BAT_2B+BAT_HR.BAT_BB +
          BAT_2B.sBAT_3B +BAT_2B.BAT_BB+PIT_H.sPIT_HR +PIT_H.PIT_BB +
          sPIT_HR.lPIT_SO,data=glm5_data[train,])

par(mfrow=c(4,4))
plot.Gam(gam, se=TRUE, col="red")
summary(gam)
preds.gam=predict(gam,newdata=glm5_data[-train])
mean((TARGET_WINS-preds.gam)^2) #146.5

#Fit the GAM to the full training data
gam=gam(TARGET_WINS~TEAM_BATTING_H+TEAM_BATTING_HR+TEAM_BATTING_2B +
          sqrt_TEAM_BATTING_3B +TEAM_BATTING_BB +sqrt_TEAM_BASERUN_SB +
          TEAM_BASERUN_CS+s(TEAM_PITCHING_H,4)+sqrt_TEAM_PITCHING_HR+
          TEAM_PITCHING_BB+ log_TEAM_PITCHING_SO +
          s(TEAM_FIELDING_E,4) + s(TEAM_FIELDING_DP,4)+
          BAT_H.BAT_2B +BAT_H.BAT_3B+BAT_HR.BAT_2B+BAT_HR.BAT_BB +
          BAT_2B.sBAT_3B +BAT_2B.BAT_BB+PIT_H.sPIT_HR +PIT_H.PIT_BB +
          sPIT_HR.lPIT_SO ,data=glm5_data)

gam$aic #8020.5
gam$deviance #158676.5

####Test Data ####
moneyball_test=read.csv("moneyball_test_2.csv",header=T)

#Correct for outliers and missing values in the test data using the training data
moneyball_test$temp=NA #Adding a temporary column so the training and test indexes match
moneyball_test=moneyball_test[,c(1,17,2:16)]

for (i in 2:17){
  outlier_impute(moneyball,moneyball_test,i)
  colnames(moneyball_test)[2*(i-1)+16]=paste("flagOutlier",colnames(moneyball_test)[i],sep="_")
  missingValue(moneyball,moneyball_test,i)
  colnames(moneyball_test)[2*(i-1)+17]=paste("flagMissing",colnames(moneyball_test)[i],sep="_")
}

moneyball_test=moneyball_test[c(-2,-18)] #Remove temporary dataframe column and placeholder missing value column
moneyball_test=moneyball_test[,colSums(moneyball_test!=0)>0] #Remove missing value or outlier flag for variables with no missing values or outliers


#Transformations
attach(moneyball_test)
moneyball_test$sqrt_TEAM_PITCHING_HR= sqrt(TEAM_PITCHING_HR)
moneyball_test$sqrt_TEAM_BATTING_3B= sqrt(TEAM_BATTING_3B)
moneyball_test$sqrt_TEAM_BASERUN_SB=sqrt(TEAM_BASERUN_SB)
moneyball_test$log_TEAM_PITCHING_SO = log(TEAM_PITCHING_SO+1)

#Interactions
attach(moneyball_test)
moneyball_test$BAT_H.BAT_2B=TEAM_BATTING_H*TEAM_BATTING_2B
moneyball_test$BAT_H.BAT_3B=TEAM_BATTING_H*sqrt_TEAM_BATTING_3B
moneyball_test$BAT_HR.BAT_2B=TEAM_BATTING_HR*TEAM_BATTING_2B
moneyball_test$BAT_HR.BAT_BB=TEAM_BATTING_HR*TEAM_BATTING_BB
moneyball_test$BAT_2B.sBAT_3B=TEAM_BATTING_2B*sqrt_TEAM_BATTING_3B
moneyball_test$BAT_2B.BAT_BB=TEAM_BATTING_2B*TEAM_BATTING_BB
moneyball_test$PIT_H.sPIT_HR=TEAM_PITCHING_H*sqrt_TEAM_PITCHING_HR
moneyball_test$PIT_H.PIT_BB=TEAM_PITCHING_H*TEAM_PITCHING_BB 
moneyball_test$sPIT_HR.lPIT_SO=sqrt_TEAM_PITCHING_HR*log_TEAM_PITCHING_SO

preds.gam=predict(gam,newdata=moneyball_test)

#Predicted values using training model
moneyball_test$P_TARGET_WINS <- preds.gam
  
#subset
prediction <- moneyball_test[c("INDEX","P_TARGET_WINS")]

#Clean up output
par(mfrow=c(1,2))
hist(prediction$P_TARGET_WINS, col = "gold", xlab = "Target Wins", main = "Histogram of Wins (Test)") #Distribution is pretty normal
boxplot(prediction$P_TARGET_WINS) #A few outliers

outlier_impute(moneyball, prediction,2)

prediction$P_TARGET_WINS=round(prediction$P_TARGET_WINS,digits=0)

#Review cleaned output
hist(prediction$P_TARGET_WINS, col = "gold", xlab = "Target Wins", main = "Histogram of Wins (Test)") #Distribution is pretty normal
boxplot(prediction$P_TARGET_WINS) #A few outliers

#Prediction File
write.csv(prediction[,1:2], file = "HelpM4V2.csv",row.names=FALSE)
