# Data Import and Variable Type Changes
setwd("D:/Class/Online MSBA/ML1 Online/Mod1")
creditdata <- read.csv("MLCredit.csv")

# Need to make sure our data is understood correctly by R, there are both numerical and categorical variables
creditdata$Index <- as.factor(creditdata$Index)
creditdata$Income <- as.numeric(creditdata$Income)
creditdata$Limit <- as.numeric(creditdata$Limit)
creditdata$Rating <- as.numeric(creditdata$Rating)
creditdata$Cards <- as.numeric(creditdata$Cards)
creditdata$Age <- as.numeric(creditdata$Age)
creditdata$Education <- as.numeric(creditdata$Education)
creditdata$Gender <- as.factor(creditdata$Gender)
creditdata$Married <- as.factor(creditdata$Married)

# Checks to see if the data frame is built correctly
str(creditdata)

# Summary of data (as inputted)
summary(creditdata)

# Evaluation of Age variable in more detail
boxplot(creditdata$Age, col = "dark green", main = "Boxplot of Age")
creditdata$FlagAge <- as.factor(ifelse(creditdata$Age > 17, 0, 1))
creditdata$Age <- as.factor(ifelse(creditdata$FlagAge == 1, quantile(creditdata$Age,c(.05)), creditdata$Age))

# Evaluation of Cards variable in more detail
hist(creditdata$Cards, col = "dark green", xlab = "Number of Credit Cards", main = "Credit Cards")
creditdata$FlagCards <- as.factor(ifelse(is.na(creditdata$Cards), 1, 0))
creditdata$Cards[is.na(creditdata$Cards)] = median(creditdata$Cards, na.rm = TRUE)

# Example of Coding a Categorical Variable to 0 and 1
creditdata$GenderCode <- as.factor(ifelse(creditdata$Gender == "Male", 1, 0))

# Summary of data (as corrected)
summary(creditdata)

# Rewriting data to a new file (as corrected)
write.csv(creditdata, file = "CDataOutput.csv")