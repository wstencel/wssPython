catalan3 = function(x) {
  i = 2
  y = numeric(1)
  y[1] = 1
  
  while (i <= x) {
    y[i] = ((x + i) / i)
    i = i + 1
  }
  answer <- prod(y)
  return(answer)
  
  
}

i = 2
y = numeric(10)
y[1] = 1

while (i <= 5) {
  y[i] = ((5 + i) / i)
  i = i + 1
}

prod(y)



catalan3 = function(x) {
  i = 2
  y = numeric(10)
  y[1] = 1
  
  repeat {
    y[i] = ((x + i) / i)
    i = i + 1
    if (i = x) break
  }
  answer <- prod(y)
  return(prod(y))
  
  
}


n = 1000000
x = numeric(n)
for (i in 1:n) x[i] = rpois(1, 3) + rpois(1, 5)




max(rep((rpois(1, 3) + rpois(1, 5)), 1000000))



checkerboard = function(color1, color2) {
  plot(c(1:8), c(1:8), type = "n")
  rect(7, 1, 8, 2, col = color1)
  rect(7, 3, 8, 4, col = color1)
  rect(7, 5, 8, 6, col = color1)
  rect(7, 7, 8, 8, col = color1)
  rect(5, 1, 6, 2, col = color1)
  rect(5, 3, 6, 4, col = color1)
  rect(5, 5, 6, 6, col = color1)
  rect(5, 7, 6, 8, col = color1)
  rect(3, 1, 4, 2, col = color1)
  rect(3, 3, 4, 4, col = color1)
  rect(3, 5, 4, 6, col = color1)
  rect(3, 7, 4, 8, col = color1)
  rect(1, 1, 2, 2, col = color1)
  rect(1, 3, 2, 4, col = color1)
  rect(1, 5, 2, 6, col = color1)
  rect(1, 7, 2, 8, col = color1)
}

checkerboard = function(color1, color2) {
  plot(c(1:5), c(1:5), type = "n")
  rect(4, 1, 5, 2, col = color1)
  rect(4, 3, 5, 4, col = color1)
  rect(2, 1, 3, 2, col = color1)
  rect(2, 3, 3, 4, col = color1)
  rect(1, 2, 2, 3, col = color1)
  rect(1, 4, 2, 5, col = color1)
  rect(3, 2, 4, 3, col = color1)
  rect(3, 4, 4, 5, col = color1)
  rect(3, 1, 4, 2, col = color2)
  rect(3, 3, 4, 4, col = color2)
  rect(1, 1, 2, 2, col = color2)
  rect(1, 3, 2, 4, col = color2)
  rect(2, 2, 3, 3, col = color2)
  rect(2, 4, 3, 5, col = color2)
  rect(4, 2, 5, 3, col = color2)
  rect(4, 4, 5, 5, col = color2)
}


for (i in 1:8){
  for (j in 1:8){
    cat(sprintf("(Column: Xs, Row: Xs) ",i,j))
  }
}