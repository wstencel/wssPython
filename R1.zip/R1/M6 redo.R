my.abs = function(x) {
  if (x < 0) x = -x
  return(x)
}

my.abs = function(x) {
  if (mode(x) != "numeric") stop("poopoo")
  x[x < 0] = -x[x < 0]
  return(x)
}

is.leapyear = function(year) {
  if (year %% 4 == 0 && year %% 100 !=0 || year %% 400 == 0)
    return(TRUE)
  else
    return(FALSE)
}

is.leapyear(1865)
is.leapyear(1984)
is.leapyear(2100)
is.leapyear(2000)

Fib <- numeric(10)
Fib[1] = 1
Fib[2] = 1
i = 3
while (i <= 10) {
  Fib[i] = Fib[i - 1] + Fib[i - 2]
  i = i + 1
}
Fib


Fib <- rep(1, 10)
for (i in 3:10) Fib[i] = Fib[i -1] + Fib[i - 2]
Fib

Fib1 = function(x) {
  a <- rep(1, x)
  for (i in 3:x) a[i] = a[i - 1] + a[i -2]
  return(a)
}


sieve = function(N) {
  prime = c(FALSE, rep(TRUE, N - 1))
  for (n in 2:sqrt(N))
    if (prime[n]) for (s in 2:(N / n)) prime[s * n] = FALSE   #the statement: "if (prime[n])" works because prime(n) might contain the value TRUE
    return(which(prime))
}






