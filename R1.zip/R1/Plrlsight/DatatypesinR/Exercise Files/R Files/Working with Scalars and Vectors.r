
# Assign a value of 5 to some variable and value 'a' to some variable. This is an example of a scalar!
v <- 5
w <- 'a'
x <- TRUE
y <- 2L
z <- 1+5i

# Print the value to visualize
print(v)
print(w)
print(x)
print(y)
print(z)

# If needed we can use coercion to change/assign data types.  This works for scalars and vectors!
f <- as.character(5)
g <- as.integer(2)
h <- as.numeric(3L)
i <- as.complex(6)
j <- as.logical(0)

print(f)
print(g)
print(h)
print(i)
print(j)

# Some data types R will not be able to use coercion between!
k <- as.numeric('a')
print(k)

# Use the class() function to see the data type.  
# Notice R has correctly guessed x to be a numeric, and y a character!
class(v)
class(w)
class(x)
class(y)
class(z)

# Another way we can check data types is using the is.numeric() functions
# Will return true if the variable is in fact that data type
is.numeric(v)
is.character(w)
is.logical(x)
is.integer(y)
is.complex(z)

# Will return false if the variable is not that data type
is.character(v)

# Use the length() function to see the length of the vectors. 
length(v)
length(w)
length(x)
length(y)
length(z)

# We can also name scalars ... this might become more useful later on!
student_data <- 75

print(student_data)

# We can give our data a name using the names() function.
names(student_data) <- "Justins Grade"

print(student_data)

# The attributes() function can give us additional useful information of our object.  Will become more useful later!
attributes(student_data)

# Use the c() function to combine elements into a vector!
a <- c(1, 2, 3, 4, 5)
b <- c('a','b','c')
c <- c(TRUE, TRUE, FALSE, TRUE)
d <- c(2L, 6L)
e <- c(1+5i, 2+7i, 3+4i)

# Print to visualize
print(a)
print(b)
print(c)
print(d)
print(e)

# Use the class() function to see the data type.  
# Notice R has correctly guessed x to be a numeric, and y a character!
class(a)
class(b)
class(c)
class(d)
class(e)

# Use the length() function to see the length of the vectors. 
length(a)
length(b)
length(c)
length(d)
length(e)

# Vectors must always be of the same type ... if they are not, R will coerce/force them into the same type!
multiple_types <-c(1, 'two', 3L, 4+2i, FALSE)

print(multiple_types)
class(multiple_types)

# Create a vector of students grades
student_grades <- c(75, 87, 63)

# Print out student grades. In some cases it might be nice to have some names/labels to go along with these values!
print(student_grades)

# Create some vector of student names
student_names <- c('Justin', 'Sarah', 'Dave')

# Assign names to our students grades by using the names() function
names(student_grades) <- student_names

print(student_grades)

# Various other methods to give names to vector elements
student_grades_1 <- c(Jeff = 71, Sam = 83, Chris = 91)
print(student_grades_1)

student_grades_2 <- c("Joel" = 68, "Mike" = 83, "Stef" = 91)
print(student_grades_2)

# Use the attributes() function to see attributes of our variables.  Attributes returns names and dimensions of structures.
attributes(student_grades)

# The str() function is also useful to show information regarding the structure of the object
str(student_grades)
