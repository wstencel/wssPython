
# Create a matrix using the matrix() function. nrow specifies number of rows, ncol specifies number of columns.
# byrow orders by rows if TRUE or by columns if FALSE.
my_matrix <- matrix(c(1,2,3,4,5,6), nrow=3, byrow=FALSE)

print(my_matrix)

# Can also create matrices using cbind() or rbind() functions. Notice columns take names from vectors.
age <- c(22, 35, 53)
salary <- c(55000, 65000, 75000)

age_salary_matrix_bycolumn <- cbind(age, salary)
print(age_salary_matrix_bycolumn)

# Similarly rbind() binds my vectors together by rows.
age_salary_matrix_byrow <- rbind(age, salary)
print(age_salary_matrix_byrow)

# Similar to naming vectors, here use rownames() to name rows and colnames() to name columns
employee_matrix <- matrix(c(1,2,3,25,35,45,50000,65000,75000), nrow = 3)

colnames(employee_matrix) <- c("ID", "Age", "Salary")

rownames(employee_matrix) <- c("Jim", "Sally", "John")

print(employee_matrix)

# Use the class() function to see the data type.  
class(employee_matrix)

# Another way we can check data types is using the is.matrix() functions
is.matrix(employee_matrix)

# The str() function is also useful to show information regarding the structure of the object
str(employee_matrix)

# Finding lengths work the same as well.  Notice length gives total number of elements for matrix.
length(employee_matrix)

# The nrow(), ncol() and dim() functions may also be useful for data frames, matrices, and arrays! 
nrow(employee_matrix)
ncol(employee_matrix)
dim(employee_matrix)

# Also in the same way we can see the attributes of matrices using the attributes() function
attributes(employee_matrix)

# Create an array using the array() function. dim specifies the dimensions of the array
my_array <- array(c(1,2,3,4,5,6,7,8,9,10,11,12), dim = c(2,2,3))

print(my_array)

# Similar idea for naming arrays as well! Use argument dimnames that takes a list of vectors
my_array <- array(c(1,2,3,4,5,6,7,8,9,10,11,12), 
                  dim = c(2,2,3), 
                  dimnames = list(c('row1','row2'), c('col1','col2'), c('DataSet1','DataSet2','DataSet3')))

print(my_array)

# Use the class() function to see the data type.  
class(my_array)

# Another way we can check data types is using the is.matrix() functions
is.array(my_array)

# The str() function is also useful to show information regarding the structure of the object
str(my_array)

# Finding lengths work the same as well.  Notice length gives total number of elements for matrix.
length(my_array)

# The nrow(), ncol(), and dim() functions may also be useful for data frames, matrices, and arrays! 
nrow(my_array)
ncol(my_array)
dim(my_array)

# Also in the same way we can see the attributes of arrays using the attributes() function
attributes(my_array)

# Create a dataframe using the data.frame() function.  Similar to matrices, but can use different types! 
# Notice by default column names take my vector names.
employee_name <- c('Joe', 'Jim', 'John', 'Jeff')
employee_dept <- c('Sales', 'Eng', 'Mgmt', 'Mgmt')
employee_salary <- c(75000, 73000, 78000, 79000)

my_df <- data.frame(employee_name, employee_dept, employee_salary)

print(my_df)

# Can change these names using the names(), colnames() and rownames() functions just as we do with vectors and matrices.
# Generally you will only want to name columns as dataframes are used for tabular data.
colnames(my_df) <- c('NAME', 'DEPT', 'SALARY')

print(my_df)

# Use the class() function to see the data type.  
class(my_df)

# Another way we can check data types is using the is.matrix() functions
is.data.frame(my_df)

# The str() function is also useful to show information regarding the structure of the object.
# Note all character vectors came in as factors by default.
str(my_df)

# By default data.frame() will import all character vectors as factors.  
# If we dont want this set the argument stringsAsFactors = FALSE
my_df <- data.frame(employee_name, employee_dept, employee_salary, stringsAsFactors = FALSE)

# Print out data frame and structure, note all character vectors are character vectors instead of factors.
print(my_df)
str(my_df)

# If we even need to sepcifically state column data types individually,
# One way we can accomplish this is by using the as.factor() / as.integer() functions
my_df$employee_dept <- as.factor(my_df$employee_dept)

my_df$employee_salary <- as.integer(my_df$employee_salary)

# Print out data frame and structure, note name comes in as character, 
# dept as factor, and salary as integer as we have explicitly stated.
print(my_df)
str(my_df)

# Finding lengths work the same as well.  Notice length gives total number of columns for dataframe.
length(my_df)

# The nrow(), ncol() and dim() functions may also be useful for data frames, matrices, and arrays! 
nrow(my_df)
ncol(my_df)
dim(my_df)

# Also in the same way we can see the attributes of dataframes using the attributes() function
attributes(my_df)
