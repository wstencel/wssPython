
# Use the list() function to combine elements into a list!
my_list <- list(1, "Two", 3L, 4+2i, FALSE)

# Print out my_list to help visualize.  Lists can be of different data types!
print(my_list)

# Using str() function to show the structure is a great way to visualize lists
str(my_list)

# Use the class() function to see the data type.  
class(my_list)

# Another way we can check data types is using the is.list() functions
# Will return true if the variable is in fact that data type
is.list(my_list)

# Will return false if the variable is not that data type
is.numeric(my_list)

# Use the length() function to see the length of the list. 
length(my_list)

# Create a vector of students grades
student_grades <- list(75, 'A+', 63)

# Print out student grades. In some cases it might be nice to have some names/labels to go along with these values!
print(student_grades)

# Create some vector of student names
student_names <- c('Justin', 'Sarah', 'Dave')

# Assign names to our students grades by using the names() function
names(student_grades) <- student_names

print(student_grades)

# Using str() is a great way to visualize lists
str(student_grades)

# Various other methods to give names to list elements
student_grades_1 <- list(Jeff = 71, Sam = 'B+', Chris = 91)
str(student_grades_1)

student_grades_2 <- list("Joel" = 68, "Mike" = 'A-', "Stef" = 91)
str(student_grades_2)

# Use the attributes() function to see attributes of our variables.  Attributes returns names and dimensions of structures.
attributes(student_grades)

# Use the factors() function to create a factor from some vector
department <- c('Sales', 'Engineering', 'Management', 'Management', 'Sales', 'Sales')
department_factor <- factor(department)

#Print out the character vector to visulaize
department

# Print out factor to visualize.  Notice levels are ordered alphabetically in R.
department_factor

# Use str() to help visualize factors as well.
str(department_factor)

# Use the class() function to see the data type.  
class(department_factor)

# Another way we can check data types is using the is.list() functions
# Will return true if the variable is in fact that data type
is.factor(department_factor)

# Will return false if the variable is not that data type
is.list(department_factor)

# Use the length() function to see the length of the factor. 
length(department_factor)

# Assign names to our employees by using the names() function with factors.
employee_names <- c('Jeff', 'John', 'Suzy', 'Sally', 'Barb', 'Bob')
names(department_factor) <- employee_names

department_factor

# Use the attributes() function to see attributes of our variables.  Attributes returns names and dimensions of structures.
attributes(department_factor)
