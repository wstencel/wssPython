my.abs = function(x) { 
  if(x < 0 ) x = -x
  return(x)
}
my.abs(-3)
my.abs(0)
my.abs(12)
my.abs(c(-2, 0, 3, -17))


my.abs = function(x) { 
  if(mode(x) != "numeric") stop("poopoo")
  x[x < 0] = -x[x < 0]
  return(x)
}

my.abs("Hello")

is.leapyear = function(y){
  if (y %% 4 == 0 && y %% 100 != 0 || y %% 400 == 0)
    return(TRUE)
  else
    return(FALSE)
}

is.leapyear(1865)
is.leapyear(1984)
is.leapyear(2100)
is.leapyear(2000)



Fib <- numeric(10)
Fib[1] = 1
Fib[2] = 1
i = 3
while (i <= 15) {
 Fib[i] = Fib[i - 1] + Fib[i - 2]
 i = i + 1
}
Fib

# for loop simple Fibonacci
Fib <- rep(1, 10)
for (i in 3:10) Fib[i] = Fib[i -1] + Fib[i - 2]
Fib

#for loop complicated Sieve of Eratosthenes
sieve = function(N) {
  prime = c(FALSE, rep(TRUE, N - 1))
  for (n in 2:sqrt(N))
    if (prime[n]) for (s in 2:(N/n)) prime[s * n] = FALSE
  return(which(prime))
}

#Recursion
fact1 = function(x) {
  i = 1
  for (j in 2:x) i = i * j
  return(i)
}

fact2 = function(x) prod(1:x)

fact3 = function(x) if (x == 1) 1 else x * fact3(x - 1)


