x = seq(-2, 3, by = 0.01)
y = x ^ 2
plot(x, y, type = "l", lwd = 1.5, xlab = "", ylab = "", xlim = c(-2, 3), ylim = c(0,9), axes = FALSE)
axis(side = 1, labels = TRUE, at = -2:3, font = 1)
axis(side = 2, labels = TRUE, at = c(0, 4, 9), font = 1, las = 1)
text(3.5, -0.3, "x", font = 1, xpd = TRUE)
text(-2.2, 9.9, "y", font = 1, xpd = TRUE)


rm(y)
rm(x)