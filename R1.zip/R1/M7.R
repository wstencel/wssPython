nrep <- 100000
count = 0
for (i in 1:nrep) {
  x = sample(5)
  if (x[1] * x[3] * x[5] == 15) count = count +1
}
count
nrep

print(count / nrep)

nrep = 1000000
count = 0
for (i in 1:nrep) {
  x = sample(1:6, 3, replace = TRUE)
  if(sum(x) == 10) count = count + 1
}
count
print(count / nrep)

for (i in 1:20) {
  plot (runif(2), runif(2), pch = 19, xlim = c(0, 1), ylim = c(0, 1), type = "o")
  Sys.sleep(1)
}

nrep = 4000000
x1 = runif(nrep)
x2 = runif(nrep)
y1 = runif(nrep)
y2 = runif(nrep)
d = sqrt((x1-x2)^2 + (y1 - y2)^2)
sort(d)[0.9 * nrep]


#25.2
nrep = 1000000
count = 0
for (i in 1:nrep) {
  x = sample(1:6, 6, replace = TRUE)
  if(sum(x) == 21) count = count + 1
}
count
print(count / nrep)



#25.3

nrep = 1000000
count = 0
M <- rep("m", 40)
W <- rep("w", 10)
for (i in 1:nrep) {
  x = sample(c(M, W), 50)
  x1 = paste(x, collapse = "")
  if ((grepl("ww", x1, fixed = TRUE))==1) count = count + 1
}
count
print(count / nrep)





test1 = c("wmwmwmwmww")
grep("ww",test1)


M <- rep("m", 40)
W <- rep("w", 10)
x = sample(c(M, W), 50)
x
x1 = paste(x, collapse = "")
x1
if (grep("ww", x1, fixed = TRUE) ==1) print("good")



#25.4
nrep = 500000
count = 0
x1 = c(1, 1, 1, 1, 1)
for (i in 1:nrep) {
  x = sample(1:6, 5, replace = TRUE)
  y = paste((x == x1), collapse = "")
  if (grepl("TRUETRUETRUE", y, fixed = TRUE)==1) count = count + 1
}
count
print(count / nrep)



#25.10
nrep = 100000
count = 0
for (i in 1:nrep) {
  x = sample(6, 5, replace = TRUE)
  if (min(x) >= 2) count = count +1
}
count
print(count / nrep)










nrep = 500000
count = 0
x1 = c(1, 1, 1)

x = sample(1:6, 5, replace = TRUE)
y = paste((x == x1), collapse = "")
y
if(grepl("TRUETRUETRUE", y, fixed = TRUE)==1)

count
print(count / nrep)



#26.2

n = length(precip)
xbar = mean(precip)
sdev = sd(precip)
alph = 0.10
crit = qt(1 - alph / 2, n - 1)
half = crit * sdev / sqrt(n)
c(xbar - half, xbar + half)

t.test(precip, conf.level = .9)


A <- matrix(c(-1, 0, 1, 2, 3, 4), 2, 3)





