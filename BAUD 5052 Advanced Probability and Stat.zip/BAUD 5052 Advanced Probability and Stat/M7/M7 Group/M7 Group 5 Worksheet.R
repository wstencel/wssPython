# Question 5
# 

# Catalog Company's Current Model
# Arrivals: lambda = 9.3/hr
# Service Rate: mu = 13.23/hr
# Phone Operator Pay = $9/hr * 40hr * 4wks = 1440
# Avg cost for completed 800 call = $1.50 * 80 for 100% answer is $120 * 20 = 2400
# Profit = Revenue * 0.4
# Avg Revenue Per Call: $37.46
# Assume avg 80 calls per day - total revenue at 100% answer = $2996.8 * 20 = $59936
# Assume avg 80 calls per day - total profit at 100% answer = $1198.72 * 20 = $23974.4
# 20 workdays per month


# Use the Erlang B model
options(scipen = 999, digits = 4)
probAnswer_data <- c()
serverCost <- c()
serverNo <- c(1, 2, 3, 4, 5, 6, 7)
for (i in 1:7) {
  probNoAnswer <- B_erlang(c=i, u= 9.3/13.23)
  probAnswer_data[i] <- 1 - probNoAnswer
  serverCost[i] <- i * (1440 + 40)
}
revenue_data <- probAnswer_data * 59936
profit_data <- probAnswer_data * (23974.4 - 2400)
probAnswer_data <- probAnswer_data * 100
netProfit <- profit_data - serverCost
options(scipen = 999, digits = 0)
Catalog_data <- rbind(serverNo,probAnswer_data,serverCost,revenue_data,profit_data)
Catalog_data
barplot(probAnswer_data, xlab = "Number of operators and phone lines",ylim = c(0, 100), 
        main = "Call Answer Probability by Number of Operators & Lines",
        ylab = "Percentage of calls answered",names.arg = serverNo)

barplot(netProfit, xlab = "Number of operators and phone lines", 
        main = "Net Profit by Number of Operators & Lines",
        col = c("grey","grey","green","grey","grey","grey","grey"),
        ylab = "Profit minus costs for additional lines & operators",names.arg = serverNo)


