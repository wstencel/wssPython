# M7 Queuing Worksheet

#rm(list=ls()) #remove all the old variables

install.packages('queueing')
library(queueing)

# ex 12.4 p688

# 1: mu=30/hr
# 5: mu=6/hr
# Arrival: lambda=25/hr

a <- QueueingModel(NewInput.MM1(lambda = 25, mu = 30))
b <- QueueingModel(NewInput.MMC(lambda = 25, mu = 6, c = 5))

summary(a); summary(b)

# Exercise 9
# Arrival: lambda=40/hr
# service time: mu=60/hr

FastFood <- QueueingModel(NewInput.MM1(lambda = 40, mu = 60))
summary(FastFood)
1 - pexp(3, rate = 1/FastFood$Lq)
#Lq = avg number of customers waiting in line
#Wq = avg time waiting in line
# a: avg number custs waiting in line = Lq
# b: avg time in spent at restaurant (til service is complete) = W
# c: what fraction of time are more than 3 cars in line (find this on page 685) = 10.5

# Exercise 10

# Arrival: lambda=4/hr
# waiting time fast copier: mu=10/hr    $15/hr
# waiting time slow copier: mu=6/hr   $4/hr
# copier per hour = Rate x RO
# Employee cost = 15 x L x W
FastCopier <- QueueingModel(NewInput.MM1(lambda = 4, mu = 10))
SlowCopier <- QueueingModel(NewInput.MM1(lambda = 4, mu = 6))
summary(FastCopier); summary(SlowCopier)
FastCopierCost <- (FastCopier$RO * 15) + (FastCopier$L * FastCopier$W * 15)
SlowCopierCost <- (SlowCopier$RO * 4) + (SlowCopier$L * SlowCopier$W * 15)
FastCopierCost
SlowCopierCost

# Exercise 19

# Arrival: lambda=18/hr
# Service Time: mu=15/hr
# Operate cash register: $20/hr
# Each minute customer waits in line is 0.25: $15/hr

cshRegisters1 <- QueueingModel(NewInput.MM1(lambda = 18, mu= 15))
str(cshRegisters1)
(20) + (cshRegisters1$Lqq * cshRegisters1$Wqq)

cshRegisters <- QueueingModel(NewInput.MMC(lambda = 18, mu= 15, c = 3))
str(cshRegisters)
(cshRegisters$Inputs$c * 20) + (cshRegisters$Lqq * cshRegisters$Wqq * 15)

# Exercise 30

# Arrival: lambda=1.8
# Arrival2: lambda=3.9
# Service Time: mu=4
# Backlog: 0.45
# Backlog2: 0.975

qitimes <- c()
qtt <- seq(from = 1.8, to = 3.9, by = 0.1)
i <- 1
for (qt in qtt) {
  worker1 <- 0
  worker1 <- QueueingModel(NewInput.MM1(lambda = qt, mu= 4))
  qitimes[i] <- as.numeric(worker1$Wqq)
  i <- i+1
  print(worker1$Wqq)
}
qtt4 <- qtt / 4
par(mfrow = c(2,1))
barplot(qtt, xlab = "Submittals per week increases linearly", names.arg = qtt, ylim = c(0, 8))
#axis(side = 2, at = c(1, 2, 3, 4, 5, 6, 7, 8, 9))
barplot(qitimes, xlab = "Traffic Intensity increases exponentially", names.arg = qtt4, ylab = "Wait Times")






