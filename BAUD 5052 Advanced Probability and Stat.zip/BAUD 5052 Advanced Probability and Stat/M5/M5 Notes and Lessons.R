#how many pounds of fish will be available daily
#
#how many days will there be no fish
#
#what is the average quantity of pounds per fish daily
#
#Starts at 3:30am daily
#8 hours
#Catch is brought to the dock at 11:30am
#
#fishing conditions occur as follows: 
#Great: 	10%
#Ok: 	60%
#Bad:	30%
#
#"arrival process" = # of fish in daily catch
#Poisson distributed.
#Averages of the distributions occuring as:
#Great:	7
#Ok:	4
#Bad: 	2
#lambda = fish/day

#mix of Yellowfin and Blue fin tuna:
#25% of occasions: 	0% Yellowfin
#50% of occasions: 	25% Yellowfin
#25% of occasions:	35% Yellowfin

#Weight:
#All fish must weigh more than 20 lbs
#Yellowfin average weight: 	30 lbs
#Bluefin average weight: 	35 lbs
#Weight is normally distributed for both
#Standard deviation for both:	18 lbs
#
#Edible yield of a catch (%, proportion):
#determined from a Beta Distribution with:
#alpha=70
#beta=30
#This is for base case of "Ok" fishing conditions
#"Great" conditions: base case goes up 10%
#"Bad" conditions: base is reduced by 25%

#Randomness

runif(1000)

#Benford's Law
# P(d) = log10(1 + 1/d)


#Shuffle 1..n   how to shuffle a vector or array -- standard swap operation
n <- 5
x <- 1:n
for (i in 1:n) {
  idx <- trunc(runif(1, min=1, max=n+1))# generate 2 indices, random
  idx2 <- trunc(runif(1, min=1, max=n+1))
  tmp <- x[idx]
  x[idx] <- x[idx2]
  x[idx2] <- tmp
  
}
x

# Naive Shuffle -- known to have bad statistical properties, produces consistant peaks in bar chart. not random
n <- 5
all <- c()
for (j in 1:30000) {
  x <- 1:n
  for (i in 1:n) {
    idx <- trunc(runif(1, min=1, max=n+1))# generate 2 indices, random
    idx2 <- trunc(runif(1, min=1, max=n+1))
    tmp <- x[idx]
    x[idx] <- x[idx2]
    x[idx2] <- tmp
  }
  all[j] <- paste(x,collapse = '') # test for randomness. Look for peaks in the bar chart over multiple tries.
}
barplot(table(all)) # test for randomness. Look for peaks in the bar chart over multiple tries.


# Fisher-Yates shuffle -- this is a good random shuffler
all <- c()
for (j in 1:30000) {
  x <- 1:n
  for (i in 1:n) {
    idx <- trunc(runif(1, min=i, max=n+1))
    tmp <- x[i]
    x[i] <- x[idx]
    x[idx] <- tmp
  }
  all[j] <- paste(x,collapse = '')
}
barplot(table(all))

#### RANDOM NUMBER GENERATORS ###

# Linear Congruential Generator (LCG)
myRand <- 1 #seed is 1 (starting value)
myRand <- (myRand * 1103515245 + 12345) %% (2^31) # multiplier is 1103515245, increment is 12345
myRand

# Mersenne Twister -- based on the Mersenne Prime 
# runif() uses this to generate psuedo randoms
# this one has a very high period. Is used for Monte-Carlo 
runif(n=1,min=1,max=10)
hist(replicate(1000, sum(runif(10)))) # replicate() wraps around a function and lets you perform it multiple times
#the above code generates a normal distribution which is stable. We want a uniform distribution (not stable)

hist(runif(n=1000)) # this results in a uniform distribution (random), and is not stable.
# the above give you values from 0 to 1
hist(runif(n=1000)*10) # mult by 10 to give values from 1 to 10

# Generating Random Variates
# getting the normal distribution, or the Poisson distribution, or some other exponential distribution
# Inverse Transform
runif(n=10)
rnorm(n=10, mean=0, sd=1) # NORMALLY distributed random variates
rbinom(n=10, size=5, prob = .5) # random binomial, this models 10 sets of 5 coin flips, 50/50 chance 
# rgamma() -- generates Gamma distributed random variables
# rpois() # Poisson
# library(triangle) - this package gives us rtriangle() which is the Triangle distribution
# Triangular distribution is used with expert judgement

# Newsvendor model
qnorm(.80) # gives you 0.85 which is the z score (critical value) assoc with 80% so..
# we need 0.85 standard deviations of extra papers to be 80% sure of not running out
qnorm(.80, mean=90, sd=10) # this = 98.42. That means you need 98.42 papers to have an 80% prob. of not running out

# Walton Bookstore - Problem 10.1 in book (replaced by 1. Drugs Simulation)

#1.) Drugs Simulation
#Mean Demand: 50000
#standard deviation: 12000
options(scipen = 999)
library(Rmisc)
CapList <- c(30000, 35000, 40000, 45000, 50000, 55000, 60000)  # capacity of Wozac plant
Price <- 3.70
MeanProfit <- data.frame(Capacity=NA, Mean_Profit=NA, Lower_Conf_Int=NA, Upper_Conf_Int=NA)
MeanProfit <- MeanProfit[-1,]
MeanProfitRow <- data.frame(Capacity=NA, Mean_Profit=NA, Lower_Conf_Int=NA, Upper_Conf_Int=NA)
for (Cap in CapList) {
  profs <- c()
  for (i in 1:1000) {
    d <- sum(rnorm(n=10, mean=50000, sd=12000))     # demand for Wozac sum of 10 random values using rnorm()
    Production <- min(Cap*10, d)  #the lesser of capacity * 10 and d for demand, sum of 10 random values using rnorm()
    Cost <- (Cap * 16) + (Production * 0.2) + (10 * Cap * 0.4)
    Revenue <- Price * Production
    Profit <- Revenue - Cost
    profs[i] <- Profit
  }
  MeanProfitRow$Capacity <- Cap
  MeanProfitRow$Mean_Profit <- as.numeric(CI(profs, ci = 0.95)["mean"])
  MeanProfitRow$Lower_Conf_Int <- as.numeric(CI(profs, ci = 0.95)["lower"])
  MeanProfitRow$Upper_Conf_Int <- as.numeric(CI(profs, ci = 0.95)["upper"])
  MeanProfit <- rbind(MeanProfit, MeanProfitRow)
}
#MeanProfit <- MeanProfit[complete.cases(MeanProfit),] # gets rid of NAs produced from the way I initialized the dataframe
MeanProfit[order(MeanProfit$Mean_Profit, decreasing = TRUE),]
plot(MeanProfit$Capacity,MeanProfit$Mean_Profit, xlab = "Capacity", ylab = "Mean Profit", col = "Blue")
#title(main="Simulation - Mean Profit by Capacity Purchased, n=1000")
yLine <- max(MeanProfit$Mean_Profit)
xLine <- MeanProfit[order(MeanProfit$Mean_Profit, decreasing = TRUE),][1,1]
abline(v=xLine, lty=2, col = "Red")
abline(h=yLine, lty=2, col = "Red")

# Simulation number 3, Clearance
#3.) Clearance Simulation
# P(0 arrivals)  .15
# P(1 arrivals)  .25
# P(2 arrivals)  .30
# P(3 arrivals)  .20
# P(4 arrivals)  .10

# want to purchase .60

# top-loaders 5     .40
# regular front loaders 4   .35
# hi cap front loaders 3    .25

days_data <- c()
for (j in 1:10000) {
  topL_cnt <- 5
  frontR_cnt <- 4
  frontH_cnt <- 3
  days_n <- 0
  # one single simulation run 
  while (sum(topL_cnt,frontR_cnt,frontH_cnt) > 0) {
    people <- sample(x=c(0,1,2,3,4),  replace = TRUE, prob = c(.15,.25,.30,.20,.10), size = 1)
    willBuy <- rbinom(1, size = people, prob = .6)
    for (i in willBuy) {
      washer <- sample(x=c("top-loader","front-reg","front-hi"), replace = FALSE, prob = c(.40,.35,.25), size = 1)
      if (washer == "top-loader" & topL_cnt > 0) {
        topL_cnt <- topL_cnt - 1
      } else if (washer == "front-reg" & frontR_cnt > 0) {
        frontR_cnt <- frontR_cnt - 1
      } else if (washer == "front-hi" & frontH_cnt > 0) {
        frontH_cnt <- frontH_cnt - 1
      }
    }
    days_n <- days_n + 1
  }
  days_data[j] <- days_n
}
hist(days_data, breaks = 50,xlim = c(0, 60), ylim = c(0, 2000), xlab = "Number of Days to Sell Entire Stock", 
     main = "Histogram of Days to Sell All the Washers",
     ylab = "Frequency Out of 10000 Simulations")
axis(side = 1, at=seq(0,100,5), labels = seq(0,100,5))

summary(days_data)
library(gmodels)
suppressWarnings(ci(days_data, confidence = 0.95))



# Simulation number 4, Warranty
# size = alpha, scale = beta

cost_data <- c()
failDuring_data <- c()
device_cnt_data <- c()
for (e in 1:10000) {
  time_elapsed <-0 
  cost <- 100
  warranty <- 1
  failDuring <- 0
  device_cnt <- 1
  while (time_elapsed < 6) {
    timetoFail <- rgamma(1, shape = 2, scale = 0.5)
    if (timetoFail > warranty) {
      cost <- cost + 100
      time_elapsed <- time_elapsed + timetoFail
      device_cnt <- device_cnt + 1
    } else if (timetoFail <= warranty) {
      time_elapsed <- time_elapsed + timetoFail
      device_cnt <- device_cnt + 1
      failDuring <- failDuring + 1
    }
  }
  cost_data[e] <- cost
  failDuring_data[e] <- failDuring
  device_cnt_data[e] <- device_cnt
}
par(mfrow=c(3,1))
hist(cost_data,xlim = c(100, 800), ylim = c(0, 5000), xlab = "Cost of Purchases, Out of Warranty", 
     main = "Cost Data",
     ylab = "Frequency",
     breaks = nrow(count(cost_data))) # counts the number of unique values to set the break
hist(failDuring_data,xlim = c(0, 15), ylim = c(0, 2000), xlab = "Number of Devices Failed Under Warranty", 
     main = "Failed During Warranty Period",
     ylab = "Frequency")
hist(device_cnt_data,xlim = c(2, 16), ylim = c(0, 3000), xlab = "Number of Devices Owned", 
     main = "Devices Owned During Six Year Period",
     ylab = "Frequency")

