#################################################
# William Stencel                               #
# Module 5 -- Akebono Simulation                #
# 2/9/2020                                      #
#################################################

#how many pounds of fish will be available daily
#
#how many days will there be no fish
#
#what is the average quantity of pounds per fish daily
#
#Starts at 3:30am daily
#8 hours
#Catch is brought to the dock at 11:30am
#
#fishing conditions occur as follows: 
#Great: 	10%
#Ok: 	60%
#Bad:	30%
#
#"arrival process" = # of fish in daily catch
#Poisson distributed.
#Averages of the distributions occuring as:
#Great:	7
#Ok:	4
#Bad: 	2
#lambda = fish/day

#mix of Yellowfin and Blue fin tuna:
#25% of occasions: 	0% Yellowfin
#50% of occasions: 	25% Yellowfin
#25% of occasions:	35% Yellowfin

#Weight:
#All fish must weigh more than 20 lbs
#Yellowfin average weight: 	30 lbs
#Bluefin average weight: 	35 lbs
#Weight is normally distributed for both
#Standard deviation for both:	18 lbs
#
#Edible yield of a catch (%, proportion):
#determined from a Beta Distribution with:
#alpha=70
#beta=30
#This is for base case of "Ok" fishing conditions
#"Great" conditions: base case goes up 10%
#"Bad" conditions: base is reduced by 25%

n_sample <- 10000 # number of samples
n_DailyFish <- c(7,4,2) # daily arrival process (number of fish arriving at the dock)
fishingConditions <- c(.1,.6,.3) # fishing conditions (great, ok, bad)
weather <- sample(x=n_DailyFish, replace = TRUE, prob = fishingConditions, size = n_sample)
#weather
fishCaught <- sapply(weather, rpois, n=1) # number of fish caught
#fishCaught

# percentages of yellow and blue fin
pctyellowFin <- sample(x=c(0,.25,.35), prob = c(.25,.5,25), size=n_sample, replace=TRUE)
n_yellowFin <- round(fishCaught * pctyellowFin) # rounded so you can't catch partial fish
#n_yellowFin <- (fishCaught * pctyellowFin) # try with no rounding

#n_yellowFin
n_blueFin <- fishCaught - n_yellowFin
#n_blueFin

# weight of fish
legalYellow <- unlist(lapply(sapply(n_yellowFin, rnorm, mean=30, sd=18), 
                                    function(l){sum(l[l>20])}))
legalBlue <- unlist(lapply(sapply(n_blueFin, rnorm, mean=35, sd=18),
                                    function(l){sum(l[l>20] )}))

# reduce catch in bad conditions and increase it in great
lbsYellow <- legalYellow * rbeta(n_sample, shape1=70, shape2=30)
lbsBlue <- legalBlue * rbeta(n_sample, shape1=70, shape2=30)

lbsYellow[which(weather==2)] <- lbsYellow[which(weather==2)]*0.75
lbsYellow[which(weather==7)] <- lbsYellow[which(weather==7)]*1.10
lbsBlue[which(weather==2)] <- lbsBlue[which(weather==2)]*0.75
lbsBlue[which(weather==7)] <- lbsBlue[which(weather==7)]*1.10

par(mfrow=c(3,1))
hist(c(lbsBlue, lbsYellow), breaks = 100) # many days with zero -- is the dip just before zero because of rounding?
hist(lbsBlue, breaks = 100)
hist(lbsYellow, breaks = 100)

summary(lbsBlue)
summary(lbsYellow)




