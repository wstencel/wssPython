rm(list = ls()) # clears all variables from the environment

#bring data in through clipboard

bank <- readClipboard()

str(bank)

#Numbers with commas - creating a custom Class (datatype) of numbers with commas so R can read Amount straight into a number format
setClass('numWithCommas')
setAs("character","numWithCommas", function(from) as.numeric(gsub(',','',from)))

#File
bank <- read.table(file="clipboard", sep="\t", header=T)
str(bank)

#use this with numWithCommas above
bank <- read.table(file="clipboard", sep="\t", header=T,
                   colClasses = c("Amount"="numWithCommas"))


bank$Date <- as.Date(bank$Date, format='%m/%d/%Y')

library(lubridate)
library(dplyr)

#1. what is the total deposit amount for each branch, broken down by account type?
table(bank$AcctType)

bank$Amount <- as.numeric(bank$Amount)

bank %>%
  group_by(AcctType) %>%
  summarise(sum(Amount))

bank %>%
  group_by(AcctType) %>%
  summarise(sum = sum(Amount))

#2. how many accounts were opened at each branch, broken down by account type?
bank %>%
  group_by(AcctType) %>%
  summarise(sum = sum(Amount), count = n())

#3. what is the distribution among the various account types?
boxplot(bank$Amount)
boxplot(bank$Amount ~ bank$AcctType) #builds a box plot based on the different account types. thats what ~ does
boxplot(bank$Amount ~ bank$AcctType, ylim=c(0,25000)) #limits range
hist(bank$Amount)

#to make a seperate histogram for each account
par(mfrow=c(2,2)) #this sets up 4 plot spaces. we can call the plot function 4 times in a row
for (i in levels(bank$AcctType)) hist(bank$Amount[bank$AcctType==i], main=i, xlab='Amount', breaks=20)

#to show the density of the different values (likelyhood/frequency of occurance) in a smooth line graph for each
for (i in levels(bank$AcctType))
  plot(density(bank$Amount[bank$AcctType==i]),main=i,xlab='Amount')

#controls scientific notation
options(scipen = 100, digits=4)

#(cumulative) to show the density of the different values (likelyhood/frequency of occurance) in a smooth line graph for each
for (i in levels(bank$AcctType))
  plot(ecdf(bank$Amount[bank$AcctType==i]),main=i,xlab='Amount')

#using ggplot
library(ggplot2)
par(mfrow=c(1,1))
ggplot(bank,aes(x=bank$Amount)) + geom_histogram(bins=20) + 
  facet_wrap(~bank$AcctType, ncol=2)

#4, do tellers have a propensity to open a particular type of account?
table(bank$AcctType, bank$OpenedBy)

#another way
library(tidyr)
#puts the data in wide format using spread
bank %>%
  group_by(AcctType, OpenedBy) %>%
  summarise(cnt = n()) %>%
  spread(OpenedBy, cnt)
  
#puts the data in long format using gather
bank %>%
  group_by(AcctType, OpenedBy) %>%
  summarise(cnt = n()) %>%
  spread(OpenedBy, cnt) %>%
  gather(AcctType)


#Quiz Q1

bank %>%
  group_by(Customer, Branch) %>%
  summarise(cnt = n()) %>%
  spread(Branch, cnt)

bank %>%
  group_by(Customer, Branch) %>%
  summarise(sum = sum(Amount)) %>%
  spread(Branch, sum)




