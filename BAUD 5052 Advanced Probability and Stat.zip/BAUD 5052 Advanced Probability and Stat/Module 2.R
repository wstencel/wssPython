# r - when Romeo arrives
# j - when Juliet arrives


#Geometric Process

#six sided die - chances of getting the right number after 2 rolls
dgeom(2,(1/6))



X = c(10,1,1, 10, 5000)
mean(X)
gMean(X) #this and geoMean() supposedly exist but I cannot find the package and there's no way to find it

gm_mean = function(a){prod(a)^(1/length(a))} # this is a homemade way I found on Stack overflow
gm_mean(X)


geometric.mean(X) # yet another that doesn't exist

X<- rnorm(n=1000000,mean=0,sd=1)
summary(X)

plot(density(X))

hist(X)

X = X + 2

X<- rnorm(n=1000000,mean=0,sd=1)
Y<- rnorm(n=1000000,mean=0,sd=1)
# when I add these two together it is still a normal distribution
Z = X + Y
plot(density(Z))

a<- runif(n=100000,min=0,max=1)
b<- runif(n=100000,min=0,max=1)

hist(a)
plot(density(a))
hist(b)
plot(density(b))
c <- a + b
hist(c)
plot(density(c))


x<-seq(-pi,pi,.1)
plot(exp((-x^2)))



barplot(c(.03,.09,.24,.27,.25,.09,.03),names.arg=c(0,1,2,3,4,5,6),xlab="Visits per Hour")

Weba <- data.frame(PerHour = c(0,1,2,3,4,5,6), Prob = c(.03,.09,.24,.27,.25,.09,.03))

Weba[5,"Prob"]+Weba[6, "Prob"]+Weba[7, "Prob"]

sum(Weba[,"Prob"])
Weba["PerHour",]  Weba[,"Prob"]
Prob = c(.03,.09,.24,.27,.25,.09,.03)
Prob
PerHour = c(0,1,2,3,4,5,6)
PerHour
ProbPerHour = Prob * PerHour
Q1Mean = sum(ProbPerHour)

Q1Var = sum(((PerHour - Q1Mean)^2) * Prob)
Q1Var

sqrt(Q1Var)


n=11
p=0.68
q=1-p
sqrt(n*p*q)

dbinom(8, size=20, prob=0.38)
dbinom(12,size=20,prob=(1-0.38))+dbinom(13,size=20,prob=(1-0.38))+dbinom(14,size=20,prob=(1-0.38))
sum(dbinom(c(12,13,14),size=20,prob=(1-0.38)))
sum(dbinom(c(0,1,2,3),size=20,prob=(1-0.38)))
format(sum(dbinom(c(0,1,2,3),size=20,prob=(1-0.38))),scientific = F)

dbinom(1, size=3,prob=0.09)
sum(dbinom(c(0,1,2,3,4,5),size=11,prob=0.8))
sum(dbinom(10,size=11,prob=0.8))

