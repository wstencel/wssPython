# Warranty Costs for Camara
# gamma distribution
# shape = alpha (α), scale = beta (β)
# mean = α * β
# standard deviation = sqrt(α)β
# α = mean^2 / sd^2
# β = sd^2 / mean
# α = 2.5^2 / 1^2 = 6.25 = shape = 6.25
# β = 1^2 / 2.5 = 0.4 = scale = 0.4
# probability of failure under warranty is 0.15
# warranty period = 1.5

cost_toCompany_data <- c()
timetoZero_data <- c()
failinWarranty_data <- c()
for (c in 1:100000) {
  cost_toCompany <- 0
  timetoZero <- 0 
  timetoFail <- 0
  failinWarranty <- 0
  warranty <- 1.5
  while (timetoFail <= warranty) {
    timetoFail <- rgamma(1, shape = 6.25, scale = 0.4)
    if (timetoFail <= warranty) {
      failinWarranty <- failinWarranty + 1
      timetoZero <- timetoZero + timetoFail
      cost_toCompany <- cost_toCompany + (225 * (1/(1+.08)^timetoZero))
      timetoFail <- 0
    }
  }
  failinWarranty_data[c] <- failinWarranty
  timetoZero_data[c] <- timetoZero
  cost_toCompany_data[c] <- cost_toCompany
}
par(mfrow=c(2,1))
hist(failinWarranty_data, breaks = 5, main = "Failed in Warranty", 
     xlab = "Number of Failures During Warranty Period", col = "Red")
hist(cost_toCompany_data, main = "Net Present Value of Cost", 
     xlab = "Net Present Value of Cost Due to Failures", col = "Green")
axis(side = 1, at=seq(0, 900, 100))

summary(failinWarranty_data)
summary(cost_toCompany_data)



testwss <- c()
for (j in 1:1000000) {
  testwss[j] <- rgamma(1, shape = 6.25, scale = 0.4)
}
summary(testwss)
hist(testwss)
axis(side = 1, at = seq(0, 12, 1))
