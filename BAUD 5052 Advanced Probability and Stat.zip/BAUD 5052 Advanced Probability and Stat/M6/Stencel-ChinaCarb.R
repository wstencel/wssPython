#########################
#    William Stencel    #
#    ChinaCarb          #
#########################

# Analysis of Catyl65S0 Time Series

library(DescTools)
library(tseries)
library(forecast)
library(outliers)
library(dplyr)
Catyl65S0.ts <- ts(c(4250,3800,3950,3800,3700,3600,3650,3500,3550,3650,3700), frequency = 1, start = 2000)
par(mfrow = c(2,1))
meantxt <- toString(round(mean(Catyl65S0.ts), digits = 0))
subtxt <- paste("Mean = ", meantxt, " shown in red")
plot(forecast(arima(Catyl65S0.ts, c(0,1,0))), sub = subtxt)
abline(h=mean(Catyl65S0.ts), col = "Red")
plot(ses(Catyl65S0.ts), sub = subtxt)
abline(h=mean(Catyl65S0.ts), col = "Red")