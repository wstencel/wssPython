#ChinaCarb Notes and work

#Load DescTools, ggplot2, tseries, and forecast
library(DescTools)
library(tseries)
library(forecast)
library(outliers)
library(dplyr)
Catyl65S0.ts <- ts(c(4250,3800,3950,3800,3700,3600,3650,3500,3550,3650,3700), frequency = 1, start = 2000)
Catyl65S0.ts
plot(Catyl65S0.ts)

plot(ses(Catyl65S0.ts))
acf(Catyl65S0.ts)
outlier(Catyl65S0.ts)
filter(!Catyl65S0.ts %in% c(outlier(Catyl65S0.ts)))
filter(!outlier(Catyl65S0.ts),Catyl65S0.ts)
mean(Catyl65S0.ts, outlier = T)


library(DescTools)
library(tseries)
library(forecast)
library(outliers)
library(dplyr)
Catyl65S0.ts <- ts(c(4250,3800,3950,3800,3700,3600,3650,3500,3550,3650,3700), frequency = 1, start = 2000)
auto.arima(Catyl65S0.ts, stepwise = FALSE, approximation = FALSE)
arima(Catyl65S0.ts, c(0,1,0))
par(mfrow = c(2,1))
meantxt <- toString(round(mean(Catyl65S0.ts), digits = 0))
subtxt <- paste("Mean = ", meantxt, " shown in red")
plot(forecast(arima(Catyl65S0.ts, c(0,1,0))), sub = subtxt)
abline(h=mean(Catyl65S0.ts), col = "Red")
plot(ses(Catyl65S0.ts), sub = subtxt)
abline(h=mean(Catyl65S0.ts), col = "Red")
mean(Catyl65S0.ts)

library(utility)
