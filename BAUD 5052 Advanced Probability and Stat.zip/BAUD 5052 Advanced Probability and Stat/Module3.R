rm(list = ls()) # clears all variables from the environment


x <- rnorm(100)

runs.test(x)

y <- c(12.85, 13.29, 12.41, 15.21, 14.23, 13.56)

runs.test(y, exact=TRUE)

excel <- readClipboard()
excel1 <- as.numeric(excel)

runs.test(excel1, exact=TRUE)
runs.test(excel1)

#compute differences
intel <- as.numeric(readClipboard())
str(intel)


plot(intel)
plot.ts(intel)
hist(intel)
plot.ts(diff(intel))
hist(diff(intel))
hist(diff(diff(intel)))
plot.ts(diff(diff(intel)))

#Random Walk
y <- rnorm(1000,mean=0,sd=1)
plot(y)
plot.ts(y)

y<-c()
y[1] <- 0
for (i in 2:1000) {
  y[i] <- y[i-1] + rnorm(n = 1, mean=0, sd=15)
}
plot.ts(y)
plot.ts(diff(y))


