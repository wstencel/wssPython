### ENTER YOUR NAME [                   ] ###
#############################################
# Time Series in R  - Practice              #
#############################################

#Load DescTools, ggplot2, tseries, and forecast 
beer
acf(beer)
ggAcf(beer)
acf(rnorm(100))
plot.ts(goog)
ggAcf(goog)
plot.ts(diff(goog))
hist(diff(goog))
acf(goog)
pacf(goog)

#Load stereo, hammer, cola, intel, reebok, exxon, and dow into R

exxon <- as.numeric(readClipboard())
plot(exxon)
exxon.ts <- ts(exxon, frequency = 4, start = c(1986, 1))
plot(exxon.ts)

stereo <- as.numeric(readClipboard())
stereo.ts <- ts(stereo, frequency=12, start=c(2005,1))
plot(stereo.ts)

ses(exxon)
summary(ses(exxon))
exxon.fit <- ses(exxon.ts)
plot(forecast(exxon.fit))
lines(fitted(forecast(exxon.fit)), lwd=2)

plot(stereo.ts)
summary(ses(stereo.ts))
plot(forecast(ses(stereo.ts)))
lines(fitted(forecast(ses(stereo.ts))), lwd=2)

summary(ets(exxon))

HoltWinters(exxon.ts)

HoltWinters(exxon.ts,beta=F,gamma=F) # gives the same alpha as exponential smoothing tab in M4 excel file


pacf(goog) # shows only the first lag is of any value
plot(goog)

library(urca) # Need to load this for ur.kpss to work
ur.kpss(goog) #to see if we can find evidence to reject the null hypothesis that this data is stationary
summary(ur.kpss(goog)) #is the test statistic under the critical values? that means test passed for stationary

summary(ur.kpss(diff(goog))) # test statistic is 0.0324 which is well below the critical values. So it is stationary
plot(diff(goog))
#kpss test and Dicky Fuller test are designed to be used together

ndiffs(goog) # runs a series of kpss tests over and over until the test is passed and data is stationary

x <- rnorm(1000)  # is level stationary
kpss.test(x)
kpss.test(goog)

plot(diff(visitors))
plot(visitors)
summary(ndiffs(visitors))
kpss.test(visitors)
summary(ur.kpss(diff(visitors)))
summary(ur.kpss(visitors))
nsdiffs(visitors)
nsdiffs(diff(visitors))
summary(nsdiffs(visitors))
summary(nsdiffs(diff(visitors)))
acf(visitors)
acf(diff(visitors))
plot(ses(diff(log(visitors))))


usmelec %>% autoplot()
usmelec %>% log() %>% autoplot()
usmelec %>% log() %>% diff(lag=1) %>% autoplot()
usmelec %>% diff(lag=1) %>% autoplot()
summary(ur.kpss(usmelec))


#ARIMA - Backshift Notation
plot.ts(uschange[,"Consumption"]) 
# Would this be well modeled by ARIMA? p, d, and q to choose from,
# differencing to consider, moving average coefficients, how many autoregressive terms? we can try looking at 
# autocorrelatio function acf() 
acf(uschange[,"Consumption"]) # can see the first 3 lags are significant
pacf(uschange[,"Consumption"])
summary(ur.kpss(uschange[,"Consumption"]))

# auto-ARIMA Ron Hindman
auto.arima(uschange[,"Consumption"])
auto.arima(uschange[,"Consumption"], seasonal = F, max.p = 2, max.q = 2)
# Assign the above ARIMA model to a variable, and then plot a forecast using this ARIMA model
fit <- auto.arima(uschange[,"Consumption"], seasonal = F, max.p = 2, max.q = 2)
fit %>% forecast(h=10) %>% autoplot(include=80)


# compare auto.arima to acf pacf
par(mfrow=c(3,1)) # sets the lower right window to 3 rows, 1 column
par(mfrow=c(2,1))
plot(visitors)
acf(visitors)
pacf(visitors)
auto.arima(visitors)
plot(forecast(auto.arima(visitors)))
plot(fitted(forecast(auto.arima(visitors))))
plot(forecast(visitors))


plot(diff(visitors))
acf(diff(visitors))
pacf(diff(visitors))
auto.arima(diff(visitors))


plot(stereo)
acf(stereo)
pacf(stereo)
auto.arima(stereo)

# to force auto-arima to be more exact, use these parameters:
auto.arima(stereo, stepwise = FALSE, approximation = FALSE)

par(mfrow=c(1,1))
plot(forecast(auto.arima(stereo)))
lines(fitted(forecast(auto.arima(stereo))))

plot(fitted(forecast(auto.arima(stereo))))

#CODE FOR M4 ASSIGNMENT - INDIA HOLIDAY BUREAU

#indiaArrivals <- as.numeric(readClipboard())  need to do this from file
indiaArrivals <- read.csv("C:\\Grad\\BAUD 5052 Advanced Probability and Stat\\M4\\IndiaHolidayArrivals.csv")
indiaArrivals
indiaArrivals.ts <- ts(indiaArrivals, frequency = 12, start = c(2001, 1))
indiaArrivals.ts
exchangeRate <- c(44.9401, 47.1857,48.5993,46.5818,45.3165,44.1,45.307,41.3485,43.5049,48.4049,45.7262,46.6723,53.4376,58.5978)
exchangeRate.ts <- ts(exchangeRate, frequency = 1, start = 2000)
exchangeRate.ts
indiaArrivalsYearly <- c(2537282,2384364,2726214,3457477,3918610,4447167,5081504,5282603,5167699,5775692,6309222,6577745,6967871)
indiaArrivalsYearly.ts <- ts(indiaArrivalsYearly, frequency = 1, start = 2001)

plot(indiaArrivals.ts)

par(mfrow=c(2,1))
plot(exchangeRate.ts)
plot(indiaArrivalsYearly.ts)

par(mfrow=c(1,1))
plot(exchangeRate.ts, axis(side = 2, labels = TRUE, at = 0:100, font = 1))
par(new=TRUE)
lines(indiaArrivalsYearly.ts / 100000)

par(mfrow=c(1,1))
plot(indiaArrivalsYearly.ts / 100000, col="Red", ylab="Arrivals X100,000 (red) and Exchange Rate", lwd=2)
title(main = "Yearly Exchange Rate vs Arrivals", sub = "Arrivals in red", col.sub="Red")
par(new=TRUE)
lines(exchangeRate.ts)

acf(indiaArrivals.ts, lag.max = 60)


par(mfrow=c(1,1))
plot(diff(indiaArrivals.ts, lag=1))
title(main = "Arrivals after 1st Differencing", sub = "figure D")

par(mfrow=c(2,1))
acf(indiaArrivals.ts)
title(sub="before differencing")
acf(diff(indiaArrivals.ts, lag=1))
title(sub="after 1st differencing \n figure E")

summary(pacf(diff(indiaArrivals.ts, lag=1)))


pacf(diff(indiaArrivals.ts, lag=1))


par(mfrow=c(2,1))
acf(diff(indiaArrivals.ts, lag=1))
acf(diff(indiaArrivals.ts, lag=2))

par(mfrow=c(2,1))
pacf(diff(indiaArrivals.ts, lag=1))
pacf(diff(indiaArrivals.ts, lag=2))


auto.arima(indiaArrivals.ts, stepwise = FALSE, approximation = FALSE)

forecast(auto.arima(indiaArrivals.ts, stepwise = FALSE, approximation = FALSE), 6)

plot(forecast(auto.arima(indiaArrivals.ts, stepwise = FALSE, approximation = FALSE), 6))

checkresiduals(forecast(auto.arima(indiaArrivals.ts, stepwise = FALSE, approximation = FALSE), 6))


#######Module 5 M5

# Shuffle 1..n

n <- 5
x <- 1:n
x










#Let's create a time series object ts/start/frequency

#plot the time series using standard R plot

#plot using ggplot2's autoplot

# Stereo/runs test 
#   Q: Is it stationary? 
#   Q: How does it compare to the p-value from the runs test in Excel? 
#   Q: What is the null hypothesis, do we reject it, and what is the result in plain english?

#Simple exponential smoothing
#   Q: How does alpha for ses() compare to HoltWinters (without trend or seasonality)

#Compute the autocorrelation function for stereo
#   Q: How does it look compared to the one in Excel? 

#Compute the autocorrelation and partial autocorrelation for hammer data 
#   Plot them both in the same window  :  par(mfrow=c(2,1))
#   Q: What does the shape tell you? 

#Autoregression
# Compute an autoregression using 3 lags and 1 lag on hammer data 
#   Q: Was there an improvement? How did you know? (e.g. How did you quantify the improvement?)

#Compare the "lag 1" model to Excel and examine the coefficient for lag 1
#   Q: Why does R not match the coefficient from Excel? 

#Fit a "simple linear model" to Reebok .. use lm()
#   Q: What is the predictor variable in a simple regression? 
#   Q: Can you get the coefficient to match up to the one in Excel? 

#Use HoltWinters to fit exxon with gamma=F. 
#   Q: What is the interpretation for the value of alpha given by the function?

#Examine the autocorrelation and partial autocorrelation for cola
#   Q: What do the "flat" regions imply? 

# Show a holt-winters autoplot forecast (with error) for cola

#Produce an additive seasonal regression model for cola 
# of the form y = a + bt + Q1t + tQ2 + x3Q3


#ARIMA models
# Examine the ACF and PACF for exxon, cola, stereo, dow, reebok, and hammer
#   Q: Which are MA?  (why)
#   Q: Which are AR?  (why)
#   Q: Which require differencing? 


#Validate the above using auto.arima() 
#   ARIMA models are parameterized by order (p,d,q)
#     p: # of lags in the AR
#     d: # of times for differencing
#     q: # of MA parameters 

# Which of the above data sets does auto.arima suggest we add in seasonality? 
  #Hint: You can tell by the output. It will have (p,d,q)(P,D,Q), where the second
  #      three numbers are seasonality controls. 

# Why does auto.arima 