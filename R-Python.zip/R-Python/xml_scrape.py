# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 16:15:03 2020

@author: William Stencel
"""
"""
https://www.ncdc.noaa.gov/cag/statewide/rankings/44/tavg/201811/data.xml
"""
import requests
from lxml import objectify

template = "https://www.ncdc.noaa.gov/cag/statewide/rankings/%s/%s/%s%s/data.xml"

Avg_temp = 'tavg'
State = '44'
Year = '2018'
Month = '08'

print(template % (State, Avg_temp, Year, Month))

NOAA_url = template % (State, Avg_temp, Year, Month)
NOAA_data = requests.get(NOAA_url).content

root = objectify.fromstring(NOAA_data)
mylist = ['value', 'mean', 'departure', 'lowRank', 'highRank']
print('\n\nWSSTENCEL')
for i in range(3,7):
    for j in mylist:
        print(j, ' ', root['data'][i][j])
#        print(root['data'][i][j])


