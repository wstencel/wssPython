# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 19:24:53 2019

@author: WS0140
"""


h = lambda x:x[0]

j = lambda x: 'small' if x < 10 else 'big'

k = lambda x: 'small' if x < 10 else('large' if x > 100 else 'medium')

m = lambda x: [x[1],x[2],x[0]]

print(m([3,5,7]))