#######################################
# William Stencel Module 3 Assignment #
#######################################

# Some other R Packages to try.
# ROCR [allowing you to compute ROC curves, etc.]
# MASS [allows for stepwise variable selection for BIC, AIC, etc.]

install.packages("psych")
install.packages("ROCR")
install.packages("corrplot")
install.packages("InformationValue")
install.packages("glm2")
install.packages("aod")
install.packages("pROC") # for calculating ROC and AUC
install.packages("olsrr") # added this to do Mallows Cp

library(olsrr) # added this to do Mallows Cp
library(pROC) # for calculating ROC and AUC
library(readr)
library(dplyr)
library(zoo)
library(psych)
library(ROCR)
library(corrplot)
library(car)
library(InformationValue)
library(pbkrtest)
library(car)
library(leaps)
library(MASS)
library(corrplot)
library(glm2)
library(aod)

# Data Import and Variable Type Changes
setwd("C:\\Users\\ws0140")
rm(data)
rm(test)
data <- read.csv("buad5122-m3-insurance-training.csv") #training data
test <- read.csv("buad5122-m3-insurance-test.csv")

### Need to make sure our data is understood correctly by R, since we have a mix of numerical and categorical
# handle NAs

data$JOB <- as.character(data$JOB)
data$JOB[nchar(data$JOB) < 3] = "none"


data$INDEX <- as.factor(data$INDEX)
data$TARGET_FLAG <- as.factor(data$TARGET_FLAG)
data$SEX <- as.factor(data$SEX)
data$EDUCATION <- as.factor(data$EDUCATION)
data$PARENT1 <- as.factor(data$PARENT1)
data$INCOME <- suppressWarnings(as.numeric(gsub("[^0-9.]", "", data$INCOME)))

data$HOME_VAL <- suppressWarnings(as.numeric(gsub("[^0-9.]", "", data$HOME_VAL)))
data$MSTATUS <- as.factor(data$MSTATUS)
data$REVOKED <- as.factor(data$REVOKED)
data$RED_CAR <- as.factor(ifelse(data$RED_CAR=="yes", 1, 0))
data$URBANICITY <- ifelse(data$URBANICITY == "Highly Urban/ Urban", "Urban", "Rural")
data$URBANICITY <- as.factor(data$URBANICITY)
data$JOB <- as.factor(data$JOB)
data$CAR_USE <- as.factor(data$CAR_USE)
data$CAR_TYPE <- as.factor(data$CAR_TYPE)
data$DO_KIDS_DRIVE <- as.factor(ifelse(data$KIDSDRIV > 0, 1, 0 ))
##################### Eliminate dollar signs from money fields #######################
data$OLDCLAIM <- suppressWarnings(as.numeric(gsub("[^0-9.]", "", data$HOME_VAL)))
data$BLUEBOOK <- suppressWarnings(as.numeric(gsub("[^0-9.]", "", data$BLUEBOOK)))

# my code to correct some outliers and NAs. Tries to replace NAs or outliers with means from same income group.
# omg I did this before I saw the code below that handles this. 
jb <- unique(data$JOB)
for (i in jb) {
  data$YOJ[is.na(data$YOJ)] = mean(data$YOJ, na.rm = TRUE)
  data$AGE[is.na(data$AGE)] = mean(data$AGE, na.rm = TRUE)
  data$INCOME[is.na(data$INCOME)] = mean(data$INCOME, na.rm = TRUE)
}
data$HOME_VAL[is.na(data$HOME_VAL)] = 0
data$OLDCLAIM[is.na(data$OLDCLAIM)] = 0
data$CAR_AGE[is.na(data$CAR_AGE)] = mean(data$CAR_AGE, na.rm = TRUE)
data$CAR_AGE[data$CAR_AGE < 1] = mean(data$CAR_AGE, na.rm = TRUE)

summary(data)

######## Same treatment on test data set ###########################

### Need to make sure our data is understood correctly by R, since we have a mix of numerical and categorical
test$JOB <- as.character(test$JOB)
test$JOB[nchar(test$JOB) < 3] = "none"

test$INDEX <- as.factor(test$INDEX)
test$TARGET_FLAG <- as.factor(test$TARGET_FLAG)
test$SEX <- as.factor(test$SEX)
test$EDUCATION <- as.factor(test$EDUCATION)
test$PARENT1 <- as.factor(test$PARENT1)
test$INCOME <- suppressWarnings(as.numeric(gsub("[^0-9.]", "", test$INCOME)))
test$HOME_VAL <- suppressWarnings(as.numeric(gsub("[^0-9.]", "", test$HOME_VAL)))
test$MSTATUS <- as.factor(test$MSTATUS)
test$REVOKED <- as.factor(test$REVOKED)
test$RED_CAR <- as.factor(ifelse(test$RED_CAR=="yes", 1, 0))
test$URBANICITY <- ifelse(test$URBANICITY == "Highly Urban/ Urban", "Urban", "Rural")
test$URBANICITY <- as.factor(test$URBANICITY)
test$JOB <- as.factor(test$JOB)
test$CAR_USE <- as.factor(test$CAR_USE)
test$CAR_TYPE <- as.factor(test$CAR_TYPE)
test$DO_KIDS_DRIVE <- as.factor(ifelse(test$KIDSDRIV > 0, 1, 0 ))
test$OLDCLAIM <- suppressWarnings(as.numeric(gsub("[^0-9.]", "", test$HOME_VAL)))
test$BLUEBOOK <- suppressWarnings(as.numeric(gsub("[^0-9.]", "", test$BLUEBOOK)))

# my code to correct some outliers and NAs. Tries to replace NAs or outliers with means from same income group.
jb <- unique(test$JOB)
for (i in jb) {
  test$YOJ[is.na(test$YOJ)] = mean(data$YOJ, na.rm = TRUE)
  test$AGE[is.na(test$AGE)] = mean(data$AGE, na.rm = TRUE)
  test$INCOME[is.na(test$INCOME)] = mean(data$INCOME, na.rm = TRUE)
}
test$HOME_VAL[is.na(test$HOME_VAL)] = 0
test$OLDCLAIM[is.na(test$OLDCLAIM)] = 0
test$CAR_AGE[is.na(test$CAR_AGE)] = mean(data$CAR_AGE, na.rm = TRUE) # uses training data means
test$CAR_AGE[test$CAR_AGE < 1] = mean(data$CAR_AGE, na.rm = TRUE) # uses training data means

summary(test)

#################### Part 1: Data Exploration ##############################################
# Histograms for Numeric Variables
#par(mfrow=c(2,2))
#hist(data$AGE, col = "red", xlab = "Age", main = "AGE Hist")
#data0<- subset(data, TARGET_FLAG == 1 )
#boxplot(data$AGE, col = "red", main = "AGE BoxPlot")
#par(mfrow=c(1,1))
#
#par(mfrow=c(2,2))
#hist(sqrt(data$TRAVTIME), col = "green", xlab = "SQRT TRAVTIME", main = "SQRT TRAVTIME Hist")
#hist(data$YOJ, col = "blue", xlab = "YOJ", main = "YOJ Hist")
#boxplot(sqrt(data$TRAVTIME), col = "green", main = "SQRT TRAVTIME BoxPlot")
#boxplot(data$YOJ, col = "blue", main = "YOJ BoxPlot")
#par(mfrow=c(1,1))
#
#par(mfrow=c(2,2))
#hist(sqrt(data$BLUEBOOK), col = "green", xlab = "SQRT BLUEBOOK", main = "SQRT BLUEBOOK Hist")
#hist((data$TIF), col = "blue", xlab = "TIF", main = "TIF Hist")
#boxplot(sqrt(data$BLUEBOOK), col = "green", main = "SQRT BLUEBOOK BoxPlot")
#boxplot(data$TIF, col = "blue", main = "TIF BoxPlot")
#par(mfrow=c(1,1))
#
#par(mfrow=c(2,2))
#hist(data$MVR_PTS, col = "red", xlab = "MVR_PTS", main = "MVR_PTS Hist")
#hist(data$CAR_AGE, col = "blue", xlab = "CAR_AGE", main = "CAR_AGE Hist")
#boxplot(data$MVR_PTS, col = "red", main = "MVR_PTS BoxPlot")
#boxplot(data$CAR_AGE, col = "blue", xlab = "CAR_AGE", main = "CAR_AGE BoxPlot")
#par(mfrow=c(1,1))

########### Part 2: Data Transformation ##################
# Fix NA's, note car age
# I think I found my own way to fix these problems in the code above because I didn't see this section... :-0

#data$AGE[is.na(data$AGE)] <- mean(data$AGE, na.rm = "TRUE")   # used my own code to do this
#data$YOJ <- na.aggregate(data$YOJ, data$JOB, mean, na.rm = TRUE) # did this using a for loop above
#data$INCOME <- na.aggregate(data$INCOME, data$JOB, mean, na.rm = TRUE) # did this using a for loop above
#data$HOME_VAL <- na.aggregate(data$HOME_VAL, data$JOB, mean, na.rm = TRUE )
#data$CAR_AGE <- na.aggregate(data$CAR_AGE, data$CAR_TYPE, mean, na.rm = TRUE)
#data$CAR_AGE[data$CAR_AGE < 0 ] <- 0 
#data$OLDCLAIM <- ifelse(data$CAR_AGE < 5 & !is.na(data$CAR_AGE),0,data$OLDCLAIM)
#data$OLDCLAIM <- na.aggregate(data$OLDCLAIM, data$CAR_AGE, mean, na.rm = TRUE )
data$HOME_OWNER <- ifelse(data$HOME_VAL == 0, 0, 1)
data$SQRT_TRAVTIME <- sqrt(data$TRAVTIME)
data$SQRT_BLUEBOOK <- sqrt(data$BLUEBOOK)

# Bin Income
data$INCOME_bin[is.na(data$INCOME)] <- "NA"
data$INCOME_bin[data$INCOME == 0] <- "Zero"
data$INCOME_bin[data$INCOME >= 1 & data$INCOME < 30000] <- "Low"
data$INCOME_bin[data$INCOME >= 30000 & data$INCOME < 80000] <- "Medium"
data$INCOME_bin[data$INCOME >= 80000] <- "High"
data$INCOME_bin <- factor(data$INCOME_bin)
data$INCOME_bin <- factor(data$INCOME_bin, levels=c("NA","Zero","Low","Medium","High"))

# Bin Travel Time
data$TRAVTIME_bin[is.na(data$TRAVTIME)] <- "zero"
data$TRAVTIME_bin[data$TRAVTIME < 1] <- "Zero"
data$TRAVTIME_bin[data$TRAVTIME >= 1 & data$TRAVTIME < 20] <- "close"
data$TRAVTIME_bin[data$TRAVTIME >= 20 & data$TRAVTIME < 45] <- "far"
data$TRAVTIME_bin[data$TRAVTIME >= 45 & data$TRAVTIME < 79] <- "reallyfar"
data$TRAVTIME_bin[data$TRAVTIME >= 79] <- "crazy"
#data$TRAVTIME_bin <- factor(data$TRAVTIME_bin)
data$TRAVTIME_bin <- factor(data$TRAVTIME_bin, levels=c("NA","Zero","close","far","reallyfar","crazy"))

data$AGE_bin[data$AGE < 40] <- "HRisk"
data$AGE_bin[data$AGE > 67] <- "HRisk"
data$AGE_bin[data$AGE >= 40 & data$AGE <= 67] <- "LRisk"
data$AGE_bin <- factor(data$AGE_bin, levels=c("HRisk", "LRisk"))

data$OLDCLAIM_bin[data$OLDCLAIM == 0] <- 0
data$OLDCLAIM_bin[data$OLDCLAIM > 0] <- 1

#data$MVR_PTS_bin[data$MVR_PTS > 2] <- 1
#data$MVR_PTS_bin[data$MVR_PTS <= 2] <- 0

# TIF over 17 years because there seems to be fewer accidents
data$TIF_OVER17[data$TIF > 17] <- 1
data$TIF_OVER17[data$TIF < 18] <- 0

#test$AGE[is.na(test$AGE)] <- mean(test$AGE, na.rm = "TRUE")
#test$YOJ <- na.aggregate(test$YOJ, test$JOB, mean, na.rm = TRUE)
#test$INCOME <- na.aggregate(test$INCOME, test$JOB, mean, na.rm = TRUE)
#test$HOME_VAL <- na.aggregate(test$HOME_VAL, test$JOB, mean, na.rm = TRUE )
#test$CAR_AGE <- na.aggregate(test$CAR_AGE, test$CAR_TYPE, mean, na.rm = TRUE)
#test$CAR_AGE[test$CAR_AGE < 0 ] <- 0 
#test$OLDCLAIM <- ifelse(test$CAR_AGE < 5 & !is.na(test$CAR_AGE),0,test$OLDCLAIM)
#test$OLDCLAIM <- na.aggregate(test$OLDCLAIM, test$CAR_AGE, mean, na.rm = TRUE )
test$HOME_OWNER <- ifelse(test$HOME_VAL == 0, 0, 1)
test$SQRT_TRAVTIME <- sqrt(test$TRAVTIME)
test$SQRT_BLUEBOOK <- sqrt(test$BLUEBOOK)

# Bin Income
test$INCOME_bin[is.na(test$INCOME)] <- "NA"
test$INCOME_bin[test$INCOME == 0] <- "Zero"
test$INCOME_bin[test$INCOME >= 1 & test$INCOME < 30000] <- "Low"
test$INCOME_bin[test$INCOME >= 30000 & test$INCOME < 80000] <- "Medium"
test$INCOME_bin[test$INCOME >= 80000] <- "High"
test$INCOME_bin <- factor(test$INCOME_bin)
test$INCOME_bin <- factor(test$INCOME_bin, levels=c("NA","Zero","Low","Medium","High"))

# Bin Travel Time
test$TRAVTIME_bin[is.na(test$TRAVTIME)] <- "zero"
test$TRAVTIME_bin[test$TRAVTIME < 1] <- "Zero"
test$TRAVTIME_bin[test$TRAVTIME >= 1 & test$TRAVTIME < 20] <- "close"
test$TRAVTIME_bin[test$TRAVTIME >= 20 & test$TRAVTIME < 45] <- "far"
test$TRAVTIME_bin[test$TRAVTIME >= 45 & test$TRAVTIME < 79] <- "reallyfar"
test$TRAVTIME_bin[test$TRAVTIME >= 79] <- "crazy"
#test$TRAVTIME_bin <- factor(test$TRAVTIME_bin)
test$TRAVTIME_bin <- factor(test$TRAVTIME_bin, levels=c("NA","Zero","close","far","reallyfar","crazy"))

test$AGE_bin[test$AGE < 40] <- "HRisk"
test$AGE_bin[test$AGE > 67] <- "HRisk"
test$AGE_bin[test$AGE >= 40 & test$AGE <= 67] <- "LRisk"
test$AGE_bin <- factor(test$AGE_bin, levels=c("HRisk", "LRisk"))


test$OLDCLAIM_bin[test$OLDCLAIM == 0] <- 0
test$OLDCLAIM_bin[test$OLDCLAIM > 0] <- 1

# TIF over 17 years because there seems to be fewer accidents
test$TIF_OVER17[test$TIF > 17] <- 1
test$TIF_OVER17[test$TIF < 18] <- 0


summary(data)
summary(test)

####### correlation plot ############
#numeric <- subset(data, select = c(AGE, HOMEKIDS, YOJ, INCOME, HOME_VAL, TRAVTIME, BLUEBOOK, TIF,
#                                   CLM_FREQ, MVR_PTS, CAR_AGE), na.rm = TRUE)
#c <- cor(numeric)
#corrplot(c, method = "square")

############# Model Development workspace ######################


#plot(data$AGE, data$INCOME)
#lines(data$Model3Prediction, data$SQRT_TRAVTIME)

#plot(data$AGE, data$INCOME)
#plot(data$TARGET_FLAG, data$MVR_PTS)

#Histogram Blue Book
#par(mfrow=c(2,2))
#data0<- subset(data, TARGET_FLAG == 0 )
#hist(data0$BLUEBOOK, col = "blue", xlab = "Bluebook", main = "no accident", ylim = c(0, 1500))
#data1<- subset(data, TARGET_FLAG == 1 )
#hist(data1$BLUEBOOK, col = "red", xlab = "Bluebook", main = "accident", ylim = c(0, 1500))
#par(mfrow=c(1,1))




############# Part 3: Model Development ######################
#Model Development for TARGET_FLAG

rm(Model1)
Model1 <- glm(TARGET_FLAG ~ AGE + BLUEBOOK + TRAVTIME + KIDSDRIV + SEX + URBANICITY + HOMEKIDS + 
                CLM_FREQ + REVOKED + MVR_PTS + CAR_AGE + TIF + EDUCATION + MSTATUS + PARENT1 + RED_CAR + 
                CAR_USE + CAR_TYPE + YOJ + JOB + INCOME_bin + HOME_VAL, 
              data = data, family = binomial())
summary(Model1)
data$Model1Prediction <- predict(Model1, type = "response")
Model1ROC <- roc(data$TARGET_FLAG, data$Model1Prediction)

rm(Model2)
Model2 <- glm(TARGET_FLAG ~ AGE + BLUEBOOK + TRAVTIME + KIDSDRIV + SEX +  URBANICITY +
                CLM_FREQ + REVOKED + MVR_PTS + TIF + EDUCATION + MSTATUS + PARENT1 + CAR_USE + CAR_TYPE + YOJ + JOB + 
                HOME_VAL,
                data = data, family = binomial())
summary(Model2)
data$Model2Prediction <- predict(Model2, type = "response")
Model2ROC <- roc(data$TARGET_FLAG, data$Model2Prediction)

rm(Model3)
Model3 <- glm(TARGET_FLAG ~ AGE + SQRT_TRAVTIME + SQRT_BLUEBOOK + DO_KIDS_DRIVE + URBANICITY +
                CLM_FREQ + REVOKED + MVR_PTS + TIF + EDUCATION + MSTATUS + PARENT1 + CAR_USE + CAR_TYPE + JOB + 
                HOME_OWNER,
              data = data, family = binomial())
summary(Model3)
data$Model3Prediction <- predict(Model3, type = "response")
Model3ROC <- roc(data$TARGET_FLAG, data$Model3Prediction)

rm(WSS_Model)
WSS_Model <- glm(TARGET_FLAG ~ AGE_bin + SQRT_TRAVTIME + SQRT_BLUEBOOK + DO_KIDS_DRIVE + TIF +
                   CAR_TYPE + CAR_USE - EDUCATION - HOMEKIDS + INCOME_bin + JOB - TIF_OVER17 +
                   MSTATUS + MVR_PTS + PARENT1 + REVOKED + URBANICITY + HOME_VAL - TRAVTIME_bin +
                   OLDCLAIM_bin + HOME_OWNER,
                 data = data, family = binomial())
summary(WSS_Model)
data$WSS_ModelPrediction <- predict(WSS_Model, type = "response")
WSS_ModelROC <- roc(data$TARGET_FLAG, data$WSS_ModelPrediction)



#rm(WSS_Model)
#WSS_Model <- glm(TARGET_FLAG ~ CLM_FREQ + CAR_TYPE + CAR_USE + EDUCATION + HOMEKIDS + HOME_VAL + INCOME_bin + JOB +
#                   MSTATUS + MVR_PTS + OLDCLAIM + PARENT1 + REVOKED + TIF + URBANICITY,
#                 data = data, family = binomial())
#summary(WSS_Model)
#data$WSS_ModelPrediction <- predict(WSS_Model, type = "response")


########## Part 4: Model Selection 
#Function for Mean Square Error Calculation
mse <- function(sm) 
  mean(sm$residuals^2)

rm(M3Stats)
M3Stats <- data.frame("Model" = c("Model1","Model2", "Model3","WSS_Model"),
                      "AIC" = c(AIC(Model1),AIC(Model2), AIC(Model3), AIC(WSS_Model)),
                      "BIC" = c(BIC(Model1), BIC(Model2), BIC(Model3), BIC(WSS_Model)),
                      "MSE" = c(mse(Model1), mse(Model2), mse(Model3), mse(WSS_Model)),
                      "AUC" = c(auc(Model1ROC), auc(Model2ROC), auc(Model3ROC), auc(WSS_ModelROC)))

M3Stats

print(-2*logLik(Model1, REML = TRUE))
print(-2*logLik(Model2, REML = TRUE))
print(-2*logLik(Model3, REML = TRUE))
print(-2*logLik(WSS_Model, REML = TRUE))
ks_stat(actuals=data$TARGET_FLAG, predictedScores=data$Model1Prediction)
ks_stat(actuals=data$TARGET_FLAG, predictedScores=data$Model2Prediction)
ks_stat(actuals=data$TARGET_FLAG, predictedScores=data$Model3Prediction)
ks_stat(actuals=data$TARGET_FLAG, predictedScores=data$WSS_ModelPrediction)

# I'm choosing my model, WSS_Model
coef(WSS_Model)

#### Part 5:  Score Model on Test Data set and output csv file

# Again, double-checking to make sure we don't have any NA's in our Test Data Set
summary(test)

########### STAND ALONE SCORING PROGRAM ###############
##### Model coefficients used to create P_TARGET_FLAG
test$P_TARGET_FLAG <- predict(WSS_Model, newdata = test, type = "response")

#Prediction File 
prediction <- test[c("INDEX","P_TARGET_FLAG")]
write.csv(prediction, file = "M3-William-Stencel-write.csv")

