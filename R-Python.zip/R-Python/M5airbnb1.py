# -*- coding: utf-8 -*-
"""
Created on Fri Apr 10 19:19:41 2020

@author: WS0140

To iterate through JSON
"""


import requests

search_url = 'https://www.airbnb.com/api/v2/calendar_months?_format=with_conditions&count=4&listing_id=9595397&month=9&year=2020&key=d306zoyjsyarp7ifhu67rjxn52tv0t20&currency=USD&locale=en'
header = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36"}
response = requests.get(search_url, headers=header)

root=response.json()

days = root['calendar_months'][0]['days']
print('Type of variable days: ', type(days))
for day in days:
    print('Data type of day: ', type(day))
    for k,v in day.items():
        print(k, ': ',v)
    print()