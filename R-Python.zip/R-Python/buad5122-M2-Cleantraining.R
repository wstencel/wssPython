#BUAD5122 William Stencel Module 2 Assignment - Training Data cleaning
setwd("C:/Users/ws0140")
Balldata <- read.csv("buad5122-m2-moneyball-training.csv")


Balldata$TARGET_WINS <- as.numeric(Balldata$TARGET_WINS)
Balldata$TEAM_BATTING_H <- as.numeric(Balldata$TEAM_BATTING_H)
Balldata$TEAM_BATTING_2B <- as.numeric(Balldata$TEAM_BATTING_2B)
Balldata$TEAM_BATTING_3B <- as.numeric(Balldata$TEAM_BATTING_3B)
Balldata$TEAM_BATTING_HR <- as.numeric(Balldata$TEAM_BATTING_HR)
Balldata$TEAM_BATTING_BB <- as.numeric(Balldata$TEAM_BATTING_BB)
Balldata$TEAM_BATTING_SO <- as.numeric(Balldata$TEAM_BATTING_SO)
Balldata$TEAM_BASERUN_SB <- as.numeric(Balldata$TEAM_BASERUN_SB)
Balldata$TEAM_BASERUN_CS <- as.numeric(Balldata$TEAM_BASERUN_CS)
Balldata$TEAM_BATTING_HBP <- as.numeric(Balldata$TEAM_BATTING_HBP)
Balldata$TEAM_PITCHING_H <- as.numeric(Balldata$TEAM_PITCHING_H)
Balldata$TEAM_PITCHING_HR <- as.numeric(Balldata$TEAM_PITCHING_HR)
Balldata$TEAM_PITCHING_BB <- as.numeric(Balldata$TEAM_PITCHING_BB)
Balldata$TEAM_PITCHING_SO <- as.numeric(Balldata$TEAM_PITCHING_SO)
Balldata$TEAM_FIELDING_E <- as.numeric(Balldata$TEAM_FIELDING_E)
Balldata$TEAM_FIELDING_DP <- as.numeric(Balldata$TEAM_FIELDING_DP)

summary(Balldata)

#take care of NAs and create flag variables
#in these cases I'm replacing with the median.
Balldata$FlagNA_BATTING_SO <- as.factor(ifelse(is.na(Balldata$TEAM_BATTING_SO), 1, 0))
Balldata$TEAM_BATTING_SO[is.na(Balldata$TEAM_BATTING_SO)] <- median(Balldata$TEAM_BATTING_SO, na.rm = TRUE)

Balldata$FlagNA_BASERUN_SB <- as.factor(ifelse(is.na(Balldata$TEAM_BASERUN_SB), 1, 0))
Balldata$TEAM_BASERUN_SB[is.na(Balldata$TEAM_BASERUN_SB)] <- median(Balldata$TEAM_BASERUN_SB, na.rm = TRUE)

Balldata$FlagNA_BASERUN_CS <- as.factor(ifelse(is.na(Balldata$TEAM_BASERUN_CS), 1, 0))
Balldata$TEAM_BASERUN_CS[is.na(Balldata$TEAM_BASERUN_CS)] <- median(Balldata$TEAM_BASERUN_CS, na.rm = TRUE)

Balldata$FlagNA_BATTING_HBP <- as.factor(ifelse(is.na(Balldata$TEAM_BATTING_HBP), 1, 0))
Balldata$TEAM_BATTING_HBP[is.na(Balldata$TEAM_BATTING_HBP)] <- median(Balldata$TEAM_BATTING_HBP, na.rm = TRUE)

Balldata$FlagNA_PITCHING_SO <- as.factor(ifelse(is.na(Balldata$TEAM_PITCHING_SO), 1, 0))
Balldata$TEAM_PITCHING_SO[is.na(Balldata$TEAM_PITCHING_SO)] <- median(Balldata$TEAM_PITCHING_SO, na.rm = TRUE)

Balldata$FlagNA_FIELDING_DP <- as.factor(ifelse(is.na(Balldata$TEAM_FIELDING_DP), 1, 0))
Balldata$TEAM_FIELDING_DP[is.na(Balldata$TEAM_FIELDING_DP)] <- median(Balldata$TEAM_FIELDING_DP, na.rm = TRUE)

#take care of outliers and create flag variables
Balldata$Flag_BASERUN_SB <- as.factor(ifelse(Balldata$TEAM_BASERUN_SB
                                             > (quantile(Balldata$TEAM_BASERUN_SB, .75)*2),1,0))
Balldata$TEAM_BASERUN_SB <- ifelse(Balldata$Flag_BASERUN_SB == 1, 
                                   median(Balldata$TEAM_BASERUN_SB, na.rm = TRUE),Balldata$TEAM_BASERUN_SB)

Balldata$Flag_BASERUN_CS <- as.factor(ifelse(Balldata$TEAM_BASERUN_CS
                                             > (quantile(Balldata$TEAM_BASERUN_CS, .75)*2),1,0))
Balldata$TEAM_BASERUN_CS <- ifelse(Balldata$Flag_BASERUN_CS == 1, 
                                   median(Balldata$TEAM_BASERUN_CS, na.rm = TRUE),Balldata$TEAM_BASERUN_CS)

Balldata$Flag_PITCHING_H <- as.factor(ifelse(Balldata$TEAM_PITCHING_H
                                             > (quantile(Balldata$TEAM_PITCHING_H, .75)*2),1,0))
Balldata$TEAM_PITCHING_H <- ifelse(Balldata$Flag_PITCHING_H == 1, 
                                   median(Balldata$TEAM_PITCHING_H, na.rm = TRUE),Balldata$TEAM_PITCHING_H)

Balldata$Flag_PITCHING_HR <- as.factor(ifelse(Balldata$TEAM_PITCHING_HR
                                             > (quantile(Balldata$TEAM_PITCHING_HR, .75)*2),1,0))
Balldata$TEAM_PITCHING_HR <- ifelse(Balldata$Flag_PITCHING_HR == 1, 
                                   median(Balldata$TEAM_PITCHING_HR, na.rm = TRUE),Balldata$TEAM_PITCHING_HR)

Balldata$Flag_PITCHING_BB <- as.factor(ifelse(Balldata$TEAM_PITCHING_BB
                                              > (quantile(Balldata$TEAM_PITCHING_BB, .75)*2),1,0))
Balldata$TEAM_PITCHING_BB <- ifelse(Balldata$Flag_PITCHING_BB == 1, 
                                    median(Balldata$TEAM_PITCHING_BB, na.rm = TRUE),Balldata$TEAM_PITCHING_BB)

Balldata$Flag_PITCHING_SO <- as.factor(ifelse(Balldata$TEAM_PITCHING_SO
                                              > (quantile(Balldata$TEAM_PITCHING_SO, .75)*2),1,0))
Balldata$TEAM_PITCHING_SO <- ifelse(Balldata$Flag_PITCHING_SO == 1, 
                                    median(Balldata$TEAM_PITCHING_SO, na.rm = TRUE),Balldata$TEAM_PITCHING_SO)

Balldata$Flag_FIELDING_E <- as.factor(ifelse(Balldata$TEAM_FIELDING_E
                                              > (quantile(Balldata$TEAM_FIELDING_E, .75)*2),1,0))
Balldata$TEAM_FIELDING_E <- ifelse(Balldata$Flag_FIELDING_E == 1, 
                                    median(Balldata$TEAM_FIELDING_E, na.rm = TRUE),Balldata$TEAM_FIELDING_E)

summary(Balldata)

write.csv(Balldata, file = "Balldata-Cleaned-Training.csv")