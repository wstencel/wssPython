# -*- coding: utf-8 -*-
"""
@author: William Stencel
"""
# Determine start time
import time
import random
start = time.time()

# Need itertools and combinations to form all combinations of items.
from itertools import combinations
 
def anycomb(items):
    # Creates all possible combinations of items.
    return ( comb
             for r in range(1, len(items)+1)
             for comb in combinations(items, r)
             )

"""
Below is my custom function that replaces anycomb() if the items list is longer than 18. It sorts the items
list randomly, then puts the first item from the random sort into the knapsack. It then looks down the randomly
sorted item list and adds items until max volume is reached. 
Since this is random, and not optimized at all, I run this proceedure len(list) * 10, and then use totalvalue()
to help select the highest value from the resulting tuple of tuples. This way, for easy items lists, the algorithm uses
all possible combinations, and when the items list is too long for that approach, it uses an easier method that still
produces ok but not perfect results. 
"""
def wsscomb(items):
    combo = []
    for i in range(1,len(items)*10):
        rand_item_list = []
        for i in range(0, len(items), 1):
            rand_item_list.append(i)
        random.shuffle(rand_item_list)
        first_item = rand_item_list[0]
        combo_temp = []
        cap_sum = items[first_item][1]
        combo_temp.append(items[first_item])
        for i in rand_item_list[1:]:
            if cap_sum + items[i][1] < cap:
                cap_sum = cap_sum + items[i][1]
                combo_temp.append(items[i])
        combo_temp = tuple(combo_temp)
        combo.append(combo_temp)
    combo = tuple(combo)
    return (combo)

 
def totalvalue(comb):
    # Calculate the total value and check feasibility of a combination of items.
    totwt = totval = 0
    for item, wt, val in comb:
        totwt  += wt
        totval += val
    return (totval, -totwt) if totwt <= cap else (0, 0)

# Items a collection of = ((Item Name, Volume, Value), ...)

# Data Set Trial (From Prof. Bradley's Video):
items = (
    ("Item 1", 382745, 825594), ("Item 2", 799601, 1677009), ("Item 3", 909247, 1676628), ("Item 4", 729069, 1523970), ("Item 5", 467902, 943972), ("Item 6", 44328, 97426), ("Item 7", 34610, 69666), ("Item 8", 698150, 1296457), ("Item 9", 823460, 1679693), ("Item 10", 903959, 1902996), ("Item 11", 853665, 1844992), ("Item 12", 551830, 1049289), ("Item 13", 610856, 1252836), ("Item 14", 670702, 1319836), ("Item 15", 488960, 953277), ("Item 16", 951111, 2067538), ("Item 17", 323046, 675367), ("Item 18", 446298, 853655), ("Item 19", 931161, 1826027), ("Item 20", 31385, 65731), ("Item 21", 496951, 901489), ("Item 22", 264724, 577243), ("Item 23", 224916, 466257), ("Item 24", 169684, 369261),
    )
cap = 6404180

#print(len(items))

"""
The anycomb() function finds the best solution to the problem, but begins to slow down
significantly if the item list is longer than 18 items. The if statement below allows anycomb() to 
be used for knapsack packing lists with 18 or fewer items and then switches to a less demanding 
greedy algorithm for other cases.
"""
if len(items) < 19:
    bagged = max( anycomb(items), key=totalvalue)
else:
    bagged = max( wsscomb(items), key=totalvalue)
    
print('WSSTENCEL')
print("Knapsack contains the following items\n  " +
      '\n  '.join(sorted(item for item,_,_ in bagged)))
val, wt = totalvalue(bagged)
print("For a total value of %i and a total volume of %i" % (val, -wt))

# Determine ending time
end = time.time()

# Print total time.
print("For a total time in seconds of ")
print(end - start)
#print(bagged)
