#######################################
# William Stencel Module 4 Assignment #
#######################################


install.packages("dplyr")
install.packages("broom")
install.packages("car")
install.packages("MASS")
install.packages("dvmisc")
install.packages("leaps")
install.packages("ISLR")
install.packages("knitr")
install.packages("printr")
install.packages("pROC") # for calculating ROC and AUC
install.packages("olsrr") # added this to do Mallows Cp
install.packages("boot")
install.packages("glmnet")
install.packages("pls")
install.packages("splines")
install.packages("gam")
install.packages("akima")

library(olsrr) # added this to do Mallows Cp
library(pROC) # for calculating ROC and AUC
library(ISLR)
library(knitr)
library(printr)
library(dplyr)
library(broom)
library(car)
library(MASS)
library(dvmisc)
library(leaps)
library(boot)
library(glmnet)
library(pls)
library(splines)
library(gam)
library(akima)

setwd("C:/Users/ws0140")
# read the moneyball training data
moneyball=read.csv("buad5122-m4-moneyball-training.csv",header=T)

############## Part 1: Data Exploration ##########################################################################
str(moneyball)
summary(moneyball)



######################### Part 2: Data Preparation #####################

#Fix Missing Values Using Mean of All Seasons
moneyball$TEAM_BATTING_SO[is.na(moneyball$TEAM_BATTING_SO)] = mean(moneyball$TEAM_BATTING_SO, na.rm = TRUE)
moneyball$TEAM_BATTING_HBP[is.na(moneyball$TEAM_BATTING_HBP)] = mean(moneyball$TEAM_BATTING_HBP, na.rm = TRUE)
moneyball$TEAM_BASERUN_SB[is.na(moneyball$TEAM_BASERUN_SB)] = mean(moneyball$TEAM_BASERUN_SB, na.rm = TRUE)
moneyball$TEAM_BASERUN_CS[is.na(moneyball$TEAM_BASERUN_CS)] = mean(moneyball$TEAM_BASERUN_CS, na.rm = TRUE)
moneyball$TEAM_FIELDING_DP[is.na(moneyball$TEAM_FIELDING_DP)] = mean(moneyball$TEAM_FIELDING_DP, na.rm = TRUE)
moneyball$TEAM_PITCHING_SO[is.na(moneyball$TEAM_PITCHING_SO)] = mean(moneyball$TEAM_PITCHING_SO, na.rm = TRUE)

#Straighten Relationships
moneyball$TEAM_BATTING_1B <- moneyball$TEAM_BATTING_H - moneyball$TEAM_BATTING_HR - moneyball$TEAM_BATTING_3B -
                             moneyball$TEAM_BATTING_2B
#moneyball$log_TEAM_BATTING_1B <- log(moneyball$TEAM_BATTING_1B)
#moneyball$log_TEAM_BATTING_3B <- log(moneyball$TEAM_BATTING_3B)
#moneyball$log_TEAM_BASERUN_SB <- log(moneyball$TEAM_BASERUN_SB)
#moneyball$log_TEAM_BASERUN_CS <- log(moneyball$TEAM_BASERUN_CS)
moneyball$TEAM_BATTING_SO[is.na(moneyball$TEAM_BATTING_SO)] = mean(moneyball$TEAM_BATTING_SO, na.rm = TRUE)
moneyball$TEAM_FIELDING_E[(moneyball$TEAM_FIELDING_E > 500)] = 500
moneyball$sqrt_TEAM_PITCHING_HR <- sqrt(moneyball$TEAM_PITCHING_HR)
moneyball$SB_PCT <- moneyball$TEAM_BASERUN_SB/(1.0*moneyball$TEAM_BASERUN_SB+moneyball$TEAM_BASERUN_CS)
moneyball$SB_PCT[is.na(moneyball$SB_PCT)] = mean(moneyball$SB_PCT, na.rm = TRUE)

#Check that na's are gone. 
summary(moneyball)



#################### Part 3: Model Creation ############################################

############################################################
#################### Ridge Regression ######################
############################################################
rm(ridge_fit)

x <- model.matrix(TARGET_WINS~., moneyball)
y <- moneyball$TARGET_WINS
lambdas <- 10^seq(10, -2, by = -.1)
ridge_fit <- glmnet(x, y, alpha = 0, lambda = lambdas)

# use cross validation to find the best lambda value
cv_ridge_fit <- cv.glmnet(x, y, alpha = 0, lambda = lambdas)
plot(cv_ridge_fit)
opt_lambda <- cv_ridge_fit$lambda.min
opt_lambda

ridge_Model <- predict(ridge_fit, s = opt_lambda, newx = x)
summary(ridge_Model)
str(ridge_Model)

########## Ridge evaluation #########

plot(ridge_Model, moneyball$TARGET_WINS)

plot(ridge_Model, col="red")
points(moneyball$TARGET_WINS, col="blue", pch='*')
summary(ridge_Model)
summary(moneyball$TARGET_WINS)

plot(coefficients(lm(moneyball$TARGET_WINS ~ moneyball$TEAM_PITCHING_HR)), type='l')
lines(coefficients(lm(ridge_Model ~ moneyball$TEAM_PITCHING_HR)))

sd(ridge_Model)
sd(moneyball$TARGET_WINS)
ridge_mse <- mean((ridge_Model-y)^2)

############################################################
#################### Lasso Regression ######################
############################################################
rm(lasso_fit)

x <- model.matrix(TARGET_WINS~., moneyball)
y <- moneyball$TARGET_WINS
lambdas <- 10^seq(10, -2, by = -.1)
lasso_fit <- glmnet(x, y, alpha = 1, lambda = lambdas)

# use cross validation to find the best lambda value
cv_lasso_fit <- cv.glmnet(x, y, alpha = 1, lambda = lambdas)
plot(cv_lasso_fit)
opt_lambda_lasso <- cv_lasso_fit$lambda.min
opt_lambda_lasso


lasso_Model <- predict(lasso_fit, s = opt_lambda_lasso, newx = x)
summary(lasso_Model)
str(lasso_Model)
#fix(lasso_Model)

########## Lasso evaluation #########

plot(lasso_Model, moneyball$TARGET_WINS)

plot(lasso_Model, col="red")
points(moneyball$TARGET_WINS, col="blue", pch='*')
summary(lasso_Model)
summary(moneyball$TARGET_WINS)

plot(coefficients(lm(moneyball$TARGET_WINS ~ moneyball$TEAM_PITCHING_HR)), type='l')
lines(coefficients(lm(lasso_Model ~ moneyball$TEAM_PITCHING_HR)))


sd(lasso_Model)
sd(moneyball$TARGET_WINS)
lasso_mse <- mean((lasso_Model-y)^2)

############################################################
################## Bootstrap Regression ####################
############################################################
lm_moneyball.fn = function(data,index)
  return(coef(lm(TARGET_WINS ~ 
                   TEAM_BATTING_H +
                   TEAM_BATTING_HR +
                   TEAM_BATTING_HBP +
                   TEAM_PITCHING_H +
                   TEAM_PITCHING_HR +
                   TEAM_PITCHING_BB +
                   (TEAM_FIELDING_DP * TEAM_BATTING_3B) +
                   (TEAM_BATTING_2B * TEAM_BATTING_BB), data = moneyball, subset=index)))

Bootstrap_fit <- boot(moneyball, lm_moneyball.fn, R=1000)
boot_stats <- print(Bootstrap_fit)
#predict(Bootstrap_fit, newdata = moneyball, type = "response")
names(Bootstrap_fit$t0)

#boot.ci(Bootstrap_fit, index = 1, conf=0.95, type = 'bca')
str(boot_stats)

# below I am subtracting the bias from the bootstrap statistics from the original coefficients.
# why am I doing this? because there are about 1000 articles about how great bootstrapping is 
# but nothing that tells you what you're supposed to do with the results to help you improve your model!!!!!!
moneyball$Boot_TARGET_WINS <- (-36.1943478698 - 0.110007048757) + 
  (0.0473257722 - 0.000634602370) * moneyball$TEAM_BATTING_H +
  (0.1006405619 - (-0.006434351734)) * moneyball$TEAM_BATTING_HR +
  (0.0594260479 - 0.000002178987) * moneyball$TEAM_BATTING_HBP +
  (-0.0018643038 - (-0.000053520026)) * moneyball$TEAM_PITCHING_H +
  (-0.0374698860 - 0.006422207005) * moneyball$TEAM_PITCHING_HR +
  (0.0089670454 - (-0.001259972751)) * moneyball$TEAM_PITCHING_BB +
  (-0.0272336549 - 0.000248068334) * moneyball$TEAM_FIELDING_DP +
  (0.3430010612 - 0.002216272350) * moneyball$TEAM_BATTING_3B +
  (0.1195814140 - -0.003374132966) * moneyball$TEAM_BATTING_2B +
  (0.0809782352 - 0.000268551599) * moneyball$TEAM_BATTING_BB +
  (-0.0018914525 - (-0.000009735336)) * (moneyball$TEAM_FIELDING_DP * moneyball$TEAM_BATTING_3B) +
  (-0.0002713487 - 0.000004220456) * (moneyball$TEAM_BATTING_2B * moneyball$TEAM_BATTING_BB)

Boot_mse <- mean((moneyball$Boot_TARGET_WINS-moneyball$TARGET_WINS)^2)


############################################################
########### Linear regression used in Module 2 #############
############################################################
rm(OLD_Model)
OLD_Model <- lm(TARGET_WINS ~ 
               TEAM_BATTING_H +
               TEAM_BATTING_HR +
               TEAM_BATTING_HBP +
               TEAM_PITCHING_H +
               TEAM_PITCHING_HR +
               TEAM_PITCHING_BB +
               (TEAM_FIELDING_DP * TEAM_BATTING_3B) +
               (TEAM_BATTING_2B * TEAM_BATTING_BB), data = moneyball)
options(scipen = 999)
summary(OLD_Model)

mse <- function(sm) 
  mean(sm$residuals^2)

OLD_Model_mse <- mse(OLD_Model)

######## Model Performance (MSE, AIC, BIC, mult r squared, adj R squared, F-stat) #######
#mse <- function(sm) 
#  mean(sm$residuals^2)

rm(M4Stats)
M4Stats <- data.frame("Model" = c("ridge_Model","lasso_Model", "Bootstrap_Model","OLD_Model"),
                      "MSE" = c(lasso_mse, ridge_mse, Boot_mse, OLD_Model_mse))

M4Stats




#################### Test Data ##########################
moneyball_test=read.csv("buad5122-m4-moneyball-test.csv",header=T)

# Fixing na's 
# I switched the means from moneyball_test to moneyball in order to use the training data to replace NAs in the test data
moneyball_test$TEAM_BATTING_1B <- moneyball_test$TEAM_BATTING_H - moneyball_test$TEAM_BATTING_HR -
moneyball_test$TEAM_BATTING_3B -moneyball_test$TEAM_BATTING_2B
moneyball_test$TEAM_BATTING_SO[is.na(moneyball_test$TEAM_BATTING_SO)] = mean(moneyball$TEAM_BATTING_SO, na.rm = TRUE)
moneyball_test$TEAM_BATTING_HBP[is.na(moneyball_test$TEAM_BATTING_HBP)] = mean(moneyball$TEAM_BATTING_HBP, na.rm = TRUE)
moneyball_test$TEAM_BASERUN_SB[is.na(moneyball_test$TEAM_BASERUN_SB)] = mean(moneyball$TEAM_BASERUN_SB, na.rm = TRUE)
moneyball_test$TEAM_BASERUN_CS[is.na(moneyball_test$TEAM_BASERUN_CS)] = mean(moneyball$TEAM_BASERUN_CS, na.rm = TRUE)
moneyball_test$TEAM_FIELDING_DP[is.na(moneyball_test$TEAM_FIELDING_DP)] = mean(moneyball$TEAM_FIELDING_DP, na.rm = TRUE)
moneyball_test$TEAM_PITCHING_SO[is.na(moneyball_test$TEAM_PITCHING_SO)] = mean(moneyball$TEAM_PITCHING_SO, na.rm = TRUE)
moneyball_test$TEAM_BASERUN_CS[moneyball_test$TEAM_BASERUN_CS < 1] = 1
moneyball_test$SB_PCT <- moneyball_test$TEAM_BASERUN_SB/(1.0*moneyball_test$TEAM_BASERUN_SB+moneyball_test$TEAM_BASERUN_CS)
moneyball_test$SB_PCT[is.na(moneyball_test$SB_PCT)] = mean(moneyball$SB_PCT)
moneyball_test$log_TEAM_BASERUN_CS <- log(moneyball_test$TEAM_BASERUN_CS)
#create additional fields to match dimensions of moneyball dataframe
#moneyball_test$P_TARGET_WINS <- 0
#moneyball_test$Boot_TARGET_WINS <- 0
moneyball_test$sqrt_TEAM_PITCHING_HR <- sqrt(moneyball_test$TEAM_PITCHING_HR)
#moneyball_test$TARGET_WINS <- 0



# clean outliers in test data
moneyball_test$TEAM_BASERUN_SB[moneyball_test$TEAM_BASERUN_SB > (quantile(moneyball_test$TEAM_BASERUN_SB, .75)*2)] = 
  mean(moneyball$TEAM_BASERUN_SB, na.rm = TRUE)
moneyball_test$TEAM_BASERUN_CS[moneyball_test$TEAM_BASERUN_CS > (quantile(moneyball_test$TEAM_BASERUN_CS, .75)*2)] = 
  mean(moneyball$TEAM_BASERUN_CS, na.rm = TRUE)
moneyball_test$TEAM_PITCHING_H[moneyball_test$TEAM_PITCHING_H > (quantile(moneyball_test$TEAM_PITCHING_H, .75)*2)] = 
  mean(moneyball$TEAM_PITCHING_H, na.rm = TRUE)
moneyball_test$TEAM_PITCHING_HR[moneyball_test$TEAM_PITCHING_HR > (quantile(moneyball_test$TEAM_PITCHING_HR, .75)*2)] = 
  mean(moneyball$TEAM_PITCHING_HR, na.rm = TRUE)
moneyball_test$TEAM_PITCHING_BB[moneyball_test$TEAM_PITCHING_BB > (quantile(moneyball_test$TEAM_PITCHING_BB, .75)*2)] = 
  mean(moneyball$TEAM_PITCHING_BB, na.rm = TRUE)
moneyball_test$TEAM_PITCHING_SO[moneyball_test$TEAM_PITCHING_SO > (quantile(moneyball_test$TEAM_PITCHING_SO, .75)*2)] = 
  mean(moneyball$TEAM_PITCHING_SO, na.rm = TRUE)
moneyball_test$TEAM_FIELDING_E[moneyball_test$TEAM_FIELDING_E > (quantile(moneyball_test$TEAM_FIELDING_E, .75)*2)] = 
  mean(moneyball$TEAM_FIELDING_E, na.rm = TRUE)

# verify test data is fixed
str(moneyball_test)
summary(moneyball_test)

#############################################
#           I used the lasso model          #
#############################################

lasso_coefs <- coef(lasso_fit, s = opt_lambda_lasso)
lasso_coefs

# the coefficients from the command above are now plugged in the the code below to produce the prediction
# I found that the predict() command with glmnet lasso method always produces an error
moneyball_test$P_TARGET_WINS <- 16.876819772099 + 
  0.048012076812 * moneyball_test$TEAM_BATTING_H +
  -0.022059715543 * moneyball_test$TEAM_BATTING_2B +
  0.086784514170 * moneyball_test$TEAM_BATTING_3B +
  0.048660694347 * moneyball_test$TEAM_BATTING_HR + 
  0.011690679289 * moneyball_test$TEAM_BATTING_BB +
  -0.012197239672 * moneyball_test$TEAM_BATTING_SO +
  0.022779516063 * moneyball_test$TEAM_BASERUN_SB +
  0.005543557017 * moneyball_test$TEAM_BASERUN_CS + 
  0.078185464767 * moneyball_test$TEAM_BATTING_HBP +
  -0.001905060843 * moneyball_test$TEAM_PITCHING_H + 
  0.012109638741 * moneyball_test$TEAM_PITCHING_HR + 
  0.001654961519 * moneyball_test$TEAM_PITCHING_BB +
  0.003789345516 * moneyball_test$TEAM_PITCHING_SO + 
  -0.041619853727 * moneyball_test$TEAM_FIELDING_E + 
  -0.117285475288 * moneyball_test$TEAM_FIELDING_DP + 
  0.000004870212 * moneyball_test$TEAM_BATTING_1B + 
  0.000087407823 * moneyball_test$sqrt_TEAM_PITCHING_HR +
  13.891922405154 * moneyball_test$SB_PCT


#subset of data set for the deliverable "Scored data file"
prediction <- moneyball_test[c("INDEX","P_TARGET_WINS")]

#####
#Note, this next function will output a CSV file in your work environment called write.csv.
#####

#Prediction File 
write.csv(prediction, file = "write-M4-Assignment-result.csv")