# -*- coding: utf-8 -*-
"""
Created on Tue May 31 16:32:02 2016

@author: james.bradley
"""

import requests
from lxml import objectify

response = requests.get("http://w1.weather.gov/xml/current_obs/KJGG.xml").content

print("\nXML from web site")
print("===========================")
print(response)

root = objectify.fromstring(response)
print('Root Tag: ', root.tag, '\n')

def getChild(myTag,indent):
    if myTag.text is not None:
        print(indent,myTag.tag+':',myTag.text)
    else:
        print(indent,myTag.tag)
    indent += '    '
    for child in myTag.getchildren():
        getChild(child,indent)
    return

print("Selected data from XML structure")
print("=================================")
print('Temperature: ',root["temperature_string"])
print('Wind: ', root['wind_string'])
#print('Heat Index: ',root['heat_index_string'])
print('Title: ', root['image']['title'])
print("==============getChild function===================")
getChild(root,'')