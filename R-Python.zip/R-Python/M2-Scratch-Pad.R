x <- c(1,3,2,5)
x
x <- rnorm(50)
x