# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 19:57:14 2019

@author: WS0140
"""

f = lambda x:x**2
y = f(2)
print(y)