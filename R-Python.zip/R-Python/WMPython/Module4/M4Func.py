# -*- coding: utf-8 -*-
"""
Created on Tue Nov 26 19:40:40 2019

@author: William Stencel
"""

dict = {0:5,1:2,2:3,3:6,4:'non-numeric'}  #this is the dictionary that the program will use as input. It has 2 even numbers that add up to 8.
y = 0
for x in dict.values():
    if type(x) is int or type(x) is float:  #this allows the addition only if x is numeric
        if x % 2 == 0:
            y = y + x
print(y)
        