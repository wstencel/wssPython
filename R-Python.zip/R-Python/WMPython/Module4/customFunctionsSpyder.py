# -*- coding: utf-8 -*-
"""
Created on Fri May 11 08:51:20 2018

@author: jrbrad
"""

def sqr(z):
    return z**2

x = 2
y = sqr(x)
print(x,'\n',y)
print(str(x) + '\n' + str(y))