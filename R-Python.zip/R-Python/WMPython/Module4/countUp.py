# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 09:53:42 2018

@author: jrbrad
"""

for i in range(1000000):
    print(i)