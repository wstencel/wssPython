# -*- coding: utf-8 -*-
"""
Created on Fri Jun 15 17:11:10 2018

@author: jrbrad
"""

def attire(temp):
if temp <= 32:
choice = 'Wear wool overcoat'
elif temp < 80:
choice = 'Wear sport coat or suit'
else:
choice = 'Loosen Tie'


temperature = 99
clothes = attire(temperature)
print(clothes)