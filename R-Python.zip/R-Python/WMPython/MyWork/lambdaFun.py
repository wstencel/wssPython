# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 19:31:00 2019

@author: William Stencel
"""
#the first print statement at the top of each section is to divide the output. 
print('\n')
print('\n')
print("------Part 1-------")
x = lambda b: int(1) if b == True else(int(0) if b == False else 'Error, bad input')

y = x(True)
print(y)

y = x(False)
print(y)

y = x('Bad Data')
print(y)


print('\n')
print('\n')
print("------Part 2-------")
y = lambda b: print('The type is: ', type(b[0]))

q = y(['string data', 0, 21, 83.0])
q = y([0, 21, 83.0,'string data'])
q = y([83.0,'string data', 0, 21])


print('\n')
print('\n')
print("------Part 3-------")
z = lambda x: 1 if x == 0 else x * z(x-1)

print(z(3))
print(z(4))
print(z(5))






# code example from exercise

#def fac(num):
#   num = int(num)
#    if num > 1:
#        return num * fac(num - 1)
#    else:
#        return 1