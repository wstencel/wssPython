# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

fixed_cost_for_setting_up_the_board_manufacturing_machine = 100.0

variable_cost_for_producing_each_board_on_the_machine = 2.0

quantity_of_boards_produced = 100000

total_cost_for_producing_boards = fixed_cost_for_setting_up_the_board_manufacturing_machine + quantity_of_boards_produced * variable_cost_for_producing_each_board_on_the_machine