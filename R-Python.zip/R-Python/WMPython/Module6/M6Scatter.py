# -*- coding: utf-8 -*-

""" Recall that the data for this assignment is called ozoneTemp.csv """
""" Write programming code to create the scatterplot here using the
    variable names below as directed in the assignment.     
William Stencel         
x =   the variables I have to use
y =   the variables I have to use
"""

""" Input data """
f_in = open('C:\\Users\\ws0140\\WMPython\\Module6\\ozoneTemp.csv','r')
data = f_in.readlines() # reads the data from file
f_in.close()   # closes the file after reading
 
""" Strip carriage returns and split each row of data """
for i in range(len(data)):
    data[i] = data[i].strip().split(',')

colHeadings = [b.strip() for b in data[0]] # deletes the row containing column headers after storing the headers in a variable. 
del data[0]

x = [int(temp[1].strip()) for temp in data] # puts the tempurature column in a list called x
y = [int(ozone[0].strip()) for ozone in data] # puts the ozone data in a list called y

import matplotlib.pyplot as plt # brings in matplotlib


""" create variables for accessing the Figure adn Axes sub-objects """
fig,ax = plt.subplots()

""" set up the x,y scatter plot, I set the opacity down to 0.2 to 
    make it easier to see when several data points overlapped. """
ax.scatter(x,y,c='b', alpha=0.2,s=150) 
ax.xaxis.set_label_text('Temperature (F)', fontsize = 16)  # sets x axis label
ax.yaxis.set_label_text('Ozone Level', fontsize = 16)  # sets y axis label
ax.xaxis.set_tick_params(labelsize=14)  # sets tick mark size
ax.yaxis.set_tick_params(labelsize=14)

#ax.axhline(1.0)       not needed so commented out
#ax.axhline(1.9)       not needed so commented out

""" Figure sub-object properties and methods """
fig.suptitle('Temperature and Ozone Level in NYC', fontsize = 20)
fig.set_size_inches(16,9)
fig.savefig('M6oz.jpg')

""" Display graph """
plt.show()
