# -*- coding: utf-8 -*-
#william stencel
import numpy as np # imports numpy and assigns to variable np 
from numpy import linalg    # imports linalg, the linear algebra module from numpy

""" Compute the eigenvalues for the transition matrix here """
P = np.array([[0.4,0.3,0.2,0.1],[0.2,0.4,0.3,0.1],[0.1,0.3,0.4,0.2],[0.1,0.2,0.3,0.4]])
eigs = linalg.eigvals(P) # this creates a vector which contains only the eigenvalues.
