# -*- coding: utf-8 -*-

import numpy as np # starts the numpy package
from numpy import linalg # loads linear algebra package

""" Solve the nutritional programming problem here using the variable x
    for your solution                                                   """
    
A = np.array([[105,130,120],[1,3,5],[2,4,2]]) # matrix
b = [[245],[6],[7]] # right hand side of augmented matrix
x = np.dot(np.linalg.inv(A), b) # performs elementary row operations to get a RRE matrix
