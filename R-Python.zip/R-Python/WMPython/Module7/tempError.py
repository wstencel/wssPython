# -*- coding: utf-8 -*-

f = input('Enter a Fahrenheit temperature: ')
print('Celsius = ',(f-32.0)*5/9)