# -*- coding: utf-8 -*-
""" The data file for this is ozone.csv """

""" Write programming code using the variable names as directed 
    in the assignment.                                          """

import pandas as pd # loads the pandas package
df_oz = pd.read_csv('ozone.csv') # reads the csv file into the dataframe

dfCorr = df_oz.corr() # this assigns the correlation matrix to a variable

print(dfCorr) #prints the matrix so I can see the highest and lowest correlations
# temp and ozone - highest correlation
# radiation and wind - lowest correlation


import matplotlib.pyplot as plt #loads the plot package
fig,ax = plt.subplots() # creates the necessary plotting variables


""" HIGHEST CORRELATION
    set up the x,y scatter plot, I set the opacity down to 0.2 to 
    make it easier to see when several data points overlapped. """
ax.scatter(df_oz['temperature'],df_oz['ozone'],c='b', alpha=0.2,s=150) 
ax.xaxis.set_label_text('Temperature (F)', fontsize = 16)  # sets x axis label
ax.yaxis.set_label_text('Ozone Level', fontsize = 16)  # sets y axis label
ax.xaxis.set_tick_params(labelsize=14)  # sets tick mark size
ax.yaxis.set_tick_params(labelsize=14)

""" Figure sub-object properties and methods """
fig.suptitle('Highest Correlation - Temperature and Ozone Level in NYC', fontsize = 20)
fig.set_size_inches(16,9)
fig.savefig('ozHi.jpg')

""" Display graph """
plt.show()

fig2,ax2 = plt.subplots() # creates the necessary plotting variables

""" LOWEST CORRELATION
    set up the x,y scatter plot, I set the opacity down to 0.2 to 
    make it easier to see when several data points overlapped. """
ax2.scatter(df_oz['radiation'],df_oz['wind'],c='r', alpha=0.2,s=150) 
ax2.xaxis.set_label_text('Radiation', fontsize = 16)  # sets x axis label
ax2.yaxis.set_label_text('Wind', fontsize = 16)  # sets y axis label
ax2.xaxis.set_tick_params(labelsize=14)  # sets tick mark size
ax2.yaxis.set_tick_params(labelsize=14)

""" Figure sub-object properties and methods """
fig2.suptitle('Lowest Correlation - Radiation Level and Wind in NYC', fontsize = 20)
fig2.set_size_inches(16,9)
fig2.savefig('ozLo.jpg')

""" Display graph """
plt.show()