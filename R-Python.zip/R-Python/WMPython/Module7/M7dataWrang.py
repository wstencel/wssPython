# -*- coding: utf-8 -*-

""" The data file for this is WburgWeather.csv """

""" Write programming code to create the cleansed DataFrame here 
    using the variable name dfWeather for your DataFrame as directed 
    in the assignment.                                               """
    
# dfWeather =    this is the variable I have to use
    
import pandas as pd # loads the pandas package
dfWeather = pd.read_csv('WburgWeather.csv') # reads the csv file into the dataframe



# the 3 commands below will remove the NaNs from the 3 columns specified in the instructions.
dfWeather.dropna(subset = ['HOURLYDRYBULBTEMPF'],inplace=True)  # this column is still an object datatype so needs more cleaning
dfWeather.dropna(subset = ['HOURLYWETBULBTEMPF'],inplace=True)   # this one is good as-is, it is a float
dfWeather.dropna(subset = ['HOURLYDewPointTempF'],inplace=True)  # this column is still an object datatype so needs more cleaning

dfWeather['HOURLYDRYBULBTEMPF'] = dfWeather['HOURLYDRYBULBTEMPF'].replace('s','',regex=True)  # strips a random character that was hiding in the data
dfWeather['HOURLYDRYBULBTEMPF'] = dfWeather['HOURLYDRYBULBTEMPF'].astype(float) # converts the column from object to float
dfWeather['HOURLYDewPointTempF'] = dfWeather['HOURLYDewPointTempF'].replace('s','',regex=True)  # strips a random character that was hiding in the data
dfWeather['HOURLYDewPointTempF'] = dfWeather['HOURLYDewPointTempF'].astype(float) # converts the column from object to float

# the 3 lines below create 3 new columns, convert the data to Celsius, and populate the new columns
dfWeather['HOURLYDRYBULBTEMPC'] = (dfWeather['HOURLYDRYBULBTEMPF'] - 32.0)*(5/9)
dfWeather['HOURLYWETBULBTEMPC'] = (dfWeather['HOURLYWETBULBTEMPF'] - 32.0)*(5/9)
dfWeather['HOURLYDewPointTempC'] = (dfWeather['HOURLYDewPointTempF'] - 32.0)*(5/9)

# the line below replaces VRB with Variable Direction
dfWeather['HOURLYWindDirection'] = dfWeather['HOURLYWindDirection'].replace('VRB','Variable Direction',regex=True)

# saves the clean data to a new csv file
dfWeather.to_csv('newWeather.csv', index=False)