# -*- coding: utf-8 -*-

import numpy as np

""" Complete your solution to the first research task here, which 
    involves the data file named temperatures.csv and using the 
    variable names as directed in the assignment.                 """
# myTemps = # Assign you solution to this variable

f_in = open('C:/Users/ws0140\\WMPython\\Module7\\temperatures.csv','r')  #imports data from csv
myTemps = []  # initializes the list
myTemps = f_in.readlines()  #reads the file into the list
f_in.close() #closes the file after reading the data in

"""This splits the numeric data from the string data using the double spaces as a separator, and puts them in separate lists within the main list """
for i in range(len(myTemps)):
    myTemps[i] = myTemps[i].strip().split('  ')  # uses the double spaces as a separator
#print(myTemps)

""" discards the string data and changes the data type of the numeric data to float """
for i in range(len(myTemps)):
    myTemps[i] = float(myTemps[i][0])  # the numeric list is converted to floating point
print(myTemps)    #prints the final list, temperatures in float datatype


print('\n', '\n', '\n')  # carriage returns to separate the results for easier reading


""" Complete your soution to the second research task here, which 
    involves combining numpy arrays    """                           
x = np.array([0,1,2,3])
y = np.array([4,5,6,7])
a = np.hstack((x, y))  # this combines the two arrays so the reshape command will work
z = np.reshape(a, (4, 2), order='F') # the reshape command takes the intermediate array and puts it into its final form

print(z) #prints the array z
print(type(z))
