# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 13:19:51 2020

@author: WS0140
"""

"""
Python graphing BAUD 5112 (BB)
"""
