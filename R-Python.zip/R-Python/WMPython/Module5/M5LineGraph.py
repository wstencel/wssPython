# -*- coding: utf-8 -*-
"""
Created on Thu Jun  7 10:38:57 2018

@author: W Stencel
"""

data = [['Jun',4.3],['Jul',4.3],['Aug',4.4],['Sep',4.2],['Oct',4.1],['Nov',4.1],['Dec',4.1],['Jan',4.1],['Feb',4.1],['Mar',4.1],['Apr',3.9],['May',3.8],]

""" Program you solution to this assignment below using 
    the variable names as defined below                 """
    
import matplotlib.pyplot as plt # importing the plotting package
    
x = [datum[0] for datum in data] # list comprehension statement, takes the first element from each sublist in data and places into list x
    
    
y = [datum[1] for datum in data] # list comprehension statement, takes the second element from each sublist in data and places into list y

plt.plot(y) # tells matplotlib to plot on the y list populated above
plt.suptitle('U.S. Unemployment Rate') # chart title
plt.xlabel('Month') # x-axis label
plt.ylabel('Unemployment Rate (%)') # y-axis label
plt.gcf().set_size_inches(12,6) # this sets the size and makes the chart rectangular
plt.xticks(range(len(x)), x) # sets the list x as the x-axis labels
plt.show() #shows the graph