# -*- coding: utf-8 -*-

""" Program you solution to this assignment below using 
    the variable names as defined below.                
    
    Recall that the data for this assignment is contained 
    in a file named length.csv                            """
# William Stencel   'C:/Users/ws0140\\WMPython\\Module5\\length.csv'


f_in = open('C:/Users/ws0140\\WMPython\\Module5\\length.csv','r')  

data = []
data = f_in.readlines()
f_in.close() #closes the file after reading the data in
for i in range(len(data)):
    data[i] = data[i].strip() #strips the carriage returns and whatever other non-printing characters
    
data = [int(i) for i in data] # converts the character counts to integer from string

charCountDict = {} # initializes a dictionary
bins = list(set(data)) #creates a list of unique character count entries using set
for b in bins:
    charCountDict[b] = 0
for charCount in data:
    charCountDict[charCount] += 1 # populates the frequency 


x = []    # use this variable for the x-axis data

y = []    # use this variable for the y-axis data

for k,v in charCountDict.items(): # populates x and y lists
    y.append(k)
    x.append(v)

import matplotlib.pyplot as plt #imports matplotlib

plt.plot(x)
plt.suptitle("Analysis of President Trump's Tweet Length")
plt.xlabel('Number of Characters')
plt.ylabel('Frequency')
plt.gcf().set_size_inches(12,6) # sets the graph to a width of 12 and height of 6
plt.show()

