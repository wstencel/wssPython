# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:12:39 2018

@author: jrbrad
"""

f_in = open('C:/Users/ws0140\\WMPython\\Module5\\sf.csv','r')
data = f_in.readlines()
f_in.close()

for i in range(len(data)):
    data[i] = data[i].strip().split(',')
    data[i] = [data[i][0][-5:],float(data[i][1])]
    
x = [datum[0] for datum in data]
y = [datum[1] for datum in data]