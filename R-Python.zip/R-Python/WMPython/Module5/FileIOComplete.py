# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:12:39 2018

@author: jrbrad
"""

f_in = open('C:/Users/jrbrad\\WMPython\\Module5\\sf.csv','r')
data = f_in.readlines()
f_in.close()