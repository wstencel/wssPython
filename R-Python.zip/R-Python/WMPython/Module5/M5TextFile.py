# -*- coding: utf-8 -*-

""" Program you solution to this assignment below using 
    the variable names as defined below                 """

f_in = open('C:\\Users\\ws0140\\WMPython\\Module5\\states.csv','r') # opens the csv file 
statesData = f_in.readlines() # reads the lines from the file into a list
f_in.close() # closes the file

statesPOP = [] # create empty lists to hold states data to be summed
statesElec = []
statesHM = []
statesSM = []

for i in range(len(statesData)):
    statesData[i] = statesData[i].strip().split(',') # strips the carriage return character and splits the string at the commas
    try:   # used the try-except-continue structure because the first line is column headers, which are str datatype
        statesData[i] = [str(statesData[i][0]),int(statesData[i][1]),int(statesData[i][2]),
                  float(statesData[i][3]),float(statesData[i][4])] # converts the elements in each sublist to the correct datatype
    except:
        continue # tells python to abandon the iteration if error and jump to the next.
    # below populates lists with elements to be summed.
    statesPOP.append(statesData[i][1])
    statesElec.append(statesData[i][2])
    statesHM.append(statesData[i][3])
    statesSM.append(statesData[i][4])
        
sums = [sum(statesPOP),sum(statesElec),sum(statesHM),sum(statesSM)] # sums up the lists and puts the sum into a new list called sums.


 