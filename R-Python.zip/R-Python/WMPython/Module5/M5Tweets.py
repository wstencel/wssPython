# -*- coding: utf-8 -*-
"""
Created on Thu Jun  7 16:08:38 2018

@author: jrbrad
"""

""" The list below contains words that you are to exclude form your analysis """
stopWords = ['to', 'the', 'a', 'to', 'is', 'and', 'in', 'of', 'that', 'it', 'be','at', 'this', 'are', 'be', 'for', 'will', 'with', 'at', 'have','on','&amp', 'by']

""" Program you solution to this assignment below using 
    the variable names as defined below.                
    
    Recall that the data for this assignment is contained 
    in a file named length.csv                            """

""" the variables I have to use
x =         # use this variable for the x-acis data


y =         # use this variable for the y-axis data
"""
f_in = open('C:\\Users\\ws0140\\WMPython\\Module5\\words.csv','r')  # the Trump words provided

data = f_in.readlines() # reads the contents of the file into a list
for i in range(len(data)):
    data[i] = data[i].strip()#.split(',')    strips the carriage returns, commented out the split statement because it turned the list into a dictionary prematurely
f_in.close() # closes the file


data = [x for x in data if x not in stopWords] # filters out the Stopword list from above

wordDict = {}
bins = list(set(data)) # makes a list with no duplicates using set
for b in bins:
    wordDict[b] = 0
for word in data:
    wordDict[word] += 1 # creates the dictionary with frequency as value 
    
import operator # needed this to use operator below
sortedwordDict = dict(sorted(wordDict.items(), key=operator.itemgetter(1), reverse=True)[:10]) #sorts by value and collects 10 highest.


x = []             # use this variable for the x-axis data


y = []             # use this variable for the y-axis data
for k,v in sortedwordDict.items():
    x.append(k)
    y.append(v)


import matplotlib.pyplot as plt #imports matplotlib

fig,ax = plt.subplots() # Creates fig variable for the Figure object and ax variable for the Axes object

plt.suptitle("President Trump's Most Tweeted Words", fontsize=18)
ax.bar(x,y, align='center',color='k') #sets color to black
ax.xaxis.set_label_text("Words in Trump's Tweets",fontsize=18)
ax.yaxis.set_label_text('Number of Occurances',fontsize=18)
ax.xaxis.set_tick_params(labelsize=14)
ax.yaxis.set_tick_params(labelsize=12)
ax.set_xticklabels(x, rotation = 90)
ax.spines['right'].set_visible(False)  # makes the right hand border invisible
ax.spines['top'].set_visible(False) # makes the top border invisible
ax.grid(False) # sets no display grid
plt.gcf().set_size_inches(12,6) # sets the graph to a width of 12 and height of 6 to better display the data
ax.tick_params(axis = 'y', which = 'both', direction = 'in', width = 2, color = 'black') #controls the Number of Occurances axis

""" section below creates a jpg file of the graph for use in documents """
fig.suptitle("President Trump's Most Tweeted Words",fontsize=20)
fig.set_size_inches(12,6)
fig.savefig('tweets.jpg',bbox_inches='tight')

plt.show() # Display the graph