# -*- coding: utf-8 -*-

""" Program you solution to this assignment below using 
    the variable names as defined below.                
    
    Recall that the data for this assignment is contained 
    in a file named length.csv                            """
# William Stencel   'C:/Users/ws0140\\WMPython\\Module5\\length.csv'


f_in = open('C:/Users/ws0140\\WMPython\\Module5\\length.csv','r')  

data = []
data = f_in.readlines()
f_in.close() #closes the file after reading the data in
for i in range(len(data)):
    data[i] = data[i].strip() #strips the carriage returns and whatever other non-printing characters
    
data = [int(i) for i in data] # converts the character counts to integer from string

charCountDict = {} # initializes a dictionary
bins = list(set(data)) #creates a list of unique character count entries using set
for b in bins:
    charCountDict[b] = 0
for charCount in data:
    charCountDict[charCount] += 1 # populates the frequency 


x = []    # use this variable for the x-axis data

y = []    # use this variable for the y-axis data

for k,v in charCountDict.items(): # populates x and y lists
    y.append(k)
    x.append(v)

import matplotlib.pyplot as plt #imports matplotlib

fig,ax = plt.subplots() # Creates fig variable for the Figure object and ax variable for the Axes object

plt.suptitle("Analysis of President Trump's Tweet Length", fontsize=18)
ax.bar(y,x, align='center',color='k') #sets color to black
ax.xaxis.set_label_text('Number of Characters',fontsize=14)
ax.yaxis.set_label_text('Frequency',fontsize=14)
ax.xaxis.set_tick_params(labelsize=14)
ax.yaxis.set_tick_params(labelsize=12)
ax.spines['right'].set_visible(False)  # makes the right hand border invisible
ax.spines['top'].set_visible(False) # makes the top border invisible
ax.grid(False) # sets no display grid
plt.gcf().set_size_inches(12,6) # sets the graph to a width of 12 and height of 6 to better display the data
ax.tick_params(axis = 'y', which = 'both', direction = 'in', width = 2, color = 'black') #controls the Frequency axis

""" section below creates a jpg file of the graph for use in documents """
fig.suptitle("Analysis of President Trump's Tweet Length",fontsize=20)
fig.set_size_inches(12,6)
fig.savefig('M5Hist.jpg',bbox_inches='tight')

plt.show() # Display the graph

