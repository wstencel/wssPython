# -*- coding: utf-8 -*-
"""
Created on Fri May 11 16:12:39 2018

@author: jrbrad
"""

f_in = open('C:/Users/jrbrad\\WMPython\\Module5\\sf.csv','r')
data = f_in.readlines()
f_in.close()

for i in range(len(data)):
    data[i] = data[i].strip().split(',')
    data[i] = [data[i][0][-5:],float(data[i][1])]