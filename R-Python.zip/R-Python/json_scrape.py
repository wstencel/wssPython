# -*- coding: utf-8 -*-
"""
Created on Fri Apr 10 19:38:52 2020

@author: William Stencel
"""
import requests

search_url = 'https://buckets.peterbeshai.com/api/?player=201939&season=2015'
header = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36"}
response = requests.get(search_url, headers=header)

root=response.json()
#print(type(root))
#print(root)


jumpShots = 0
madeShots = 0
madeShots = 0
for i in range(0,len(root)):
    if root[i]['ACTION_TYPE'] == 'Jump Shot':
        jumpShots = jumpShots + 1
        if root[i]['EVENT_TYPE'] == 'Made Shot':
            madeShots = madeShots + 1

percentage = madeShots / jumpShots
print('WSSTENCEL')
print(jumpShots)
print(madeShots)
print("{:.2%}".format(percentage))
