#######################################
# William Stencel Module 2 Assignment #
#######################################

setwd("C:/Users/ws0140")
# read the pre-cleaned moneyball training data
moneyball=read.csv("Balldata-Cleaned-Training.csv",header=T)
install.packages("leaps")
install.packages("dplyr")
install.packages("broom")
install.packages("car")
install.packages("MASS")
install.packages("dvmisc")
install.packages("leaps")
install.packages("ISLR")
install.packages("knitr")
install.packages("printr")
library(ISLR)
library(knitr)
library(printr)
library(dplyr)
library(broom)
library(car)
library(MASS)
library(dvmisc)
library(leaps)
############## Part 1: Data Exploration ##########################################################################
str(moneyball)
summary(moneyball)

# Wins - Use lower bound for lower outliers, upper bound for higher outliers.
#par(mfrow=c(1,2))
#hist(moneyball$TARGET_WINS, col = "#A71930", xlab = "TARGET_WINS", main = "Histogram of Wins")
#boxplot(moneyball$TARGET_WINS, col = "#A71930", main = "Boxplot of Wins")
#par(mfrow = c(1,1))

################# Batting ####################
# Hits and Doubles
#par(mfrow=c(2,2))
#hist(moneyball$TEAM_BATTING_H, col = "#A71930", xlab = "Team_Batting_H", main = "Histogram of Hits")
#hist(moneyball$TEAM_BATTING_2B, col = "#09ADAD", xlab = "Doubles", main = "Histogram of Doubles")
#boxplot(moneyball$TEAM_BATTING_H, col = "#A71930", main = "Boxplot of Hits")
#boxplot(moneyball$TEAM_BATTING_2B, col = "#09ADAD", main = "Boxplot of Doubles")
#par(mfrow=c(1,1))

# Triples and Home Runs
#par(mfrow=c(2,2))
#hist(moneyball$TEAM_BATTING_3B, col = "#A71930", xlab = "Triples", main = "Histogram of Triples")
#hist(moneyball$TEAM_BATTING_HR, col = "#DBCEAC", xlab = "Home Runs", main = "Histogram of Home Runs")
#boxplot(moneyball$TEAM_BATTING_3B, col = "#A71930", main = "Boxplot of Triples")
#boxplot(moneyball$TEAM_BATTING_HR, col = "#DBCEAC", main = "Boxplot of Home Runs")
#par(mfrow=c(1,1))

# Walks, Strikeouts, HBP
#par(mfrow=c(2,3))
#hist(moneyball$TEAM_BATTING_BB, col = "#A71930", xlab = "Walks", main = "Histogram of Walks")
#hist(moneyball$TEAM_BATTING_SO, col = "#09ADAD", xlab = "Strikeouts", main = "Histogram of Strikeouts")
#hist(moneyball$TEAM_BATTING_HBP, col = "#DBCEAC", xlab = "Hit By Pitches", main = "Histogram of HBP")
#boxplot(moneyball$TEAM_BATTING_BB, col = "#A71930", main = "Boxplot of Walks")
#boxplot(moneyball$TEAM_BATTING_SO, col = "#09ADAD", main = "Boxplot of Strikeouts")
#boxplot(moneyball$TEAM_BATTING_HBP, col = "#DBCEAC", main = "Boxplot of HBP")
#par(mfrow=c(1,1))

# Stolen Bases and Caught Stealing
#par(mfrow=c(2,2))
#hist(moneyball$TEAM_BASERUN_SB, col = "#A71930", xlab = "Stolen Bases", main = "Histogram of Steals")
#hist(moneyball$TEAM_BASERUN_CS, col = "#DBCEAC", xlab = "Caught Stealing", main = "Histogram of CS")
#boxplot(moneyball$TEAM_BASERUN_SB, col = "#A71930", main = "Boxplot of Steals")
#boxplot(moneyball$TEAM_BASERUN_CS, col = "#DBCEAC", main = "Boxplot of CS")
#par(mfrow=c(1,1))

################ Pitching ############
# Hits and Home Runs
#par(mfrow=c(2,2))
#hist(moneyball$TEAM_PITCHING_H, col = "#A71930", xlab = "Hits Against", main = "Histogram of Hits Against")
#hist(moneyball$TEAM_PITCHING_HR, col = "#09ADAD", xlab = "Home Runs Against", main = "Histograms of HR Against")
#boxplot(moneyball$TEAM_PITCHING_H, col = "#A71930", main = "Boxplot of Hits Against")
#boxplot(moneyball$TEAM_PITCHING_HR, col = "#09ADAD", main = "Boxplot of HR Against")
#par(mfrow=c(1,1))

# Walks and Strikeouts
#par(mfrow=c(2,2))
#hist(moneyball$TEAM_PITCHING_BB, col = "#A71930", xlab = "Walks Allowed", main = "Histogram of Walks Allowed")
#hist(moneyball$TEAM_PITCHING_SO, col = "#DBCEAC", xlab = "Strikeouts", main = "Histograms of Strikeouts")
#boxplot(moneyball$TEAM_PITCHING_BB, col = "#A71930", main = "Boxplot of Walks Allowed")
#boxplot(moneyball$TEAM_PITCHING_SO, col = "#DBCEAC", main = "Boxplot of Strikeouts")
#par(mfrow=c(1,1))

############## Fielding ###########
# Double Plays and Errors 
#par(mfrow=c(2,2))
#hist(moneyball$TEAM_FIELDING_DP, col = "#A71930", xlab = "Double Plays", main = "Histogram of Double Plays")
#hist(moneyball$TEAM_FIELDING_E, col = "#09ADAD", xlab = "Errors Committed", main = "Histogram of Errors Committed")
#boxplot(moneyball$TEAM_FIELDING_DP, col = "#A71930", main = "Boxplot of Double Plays")
#boxplot(moneyball$TEAM_FIELDING_E, col = "#09ADAD", main = "Boxplot of Errors Committed")
#par(mfrow=c(1,1))

######## Scatterplot Matrix ##########
#panel.cor <- function(x, y, digits=2, prefix="", cex.cor, ...)
#{
#  usr <- par("usr"); on.exit(par(usr))
#  par(usr = c(0, 1, 0, 1))
#  r <- abs(cor(x, y))
#  txt <- format(c(r, 0.123456789), digits=digits)[1]
#  txt <- paste(prefix, txt, sep="")
#  if(missing(cex.cor)) cex.cor <- 0.8/strwidth(txt)
#  text(0.5, 0.5, txt, cex = cex.cor * r)
#}

# Batting Stats and Wins
#pairs(moneyball[2:8], lower.panel=panel.smooth, upper.panel = panel.cor)

#Baserunning  Stats and Wins
#pairs(~ moneyball$TARGET_WINS + moneyball$TEAM_BASERUN_CS + moneyball$TEAM_BASERUN_SB, lower.panel = panel.smooth)

#Pitcher Stats and Wins
#pairs(~ moneyball$TARGET_WINS + moneyball$TEAM_PITCHING_BB + moneyball$TEAM_PITCHING_H + 
#        moneyball$TEAM_PITCHING_HR + moneyball$TEAM_PITCHING_SO, lower.panel = panel.smooth)

#pairs(moneyball[2,9,10, 11, 12, 13])

# I commented this part out since I already replaced the NAs with means.
######################### Part 2: Data Preparation #####################

#Fix Missing Values Using Mean of All Seasons
#moneyball$TEAM_BATTING_SO[is.na(moneyball$TEAM_BATTING_SO)] = mean(moneyball$TEAM_BATTING_SO, na.rm = TRUE)
#moneyball$TEAM_BATTING_HBP[is.na(moneyball$TEAM_BATTING_HBP)] = mean(moneyball$TEAM_BATTING_HBP, na.rm = TRUE)
#moneyball$TEAM_BASERUN_SB[is.na(moneyball$TEAM_BASERUN_SB)] = mean(moneyball$TEAM_BASERUN_SB, na.rm = TRUE)
#moneyball$TEAM_BASERUN_CS[is.na(moneyball$TEAM_BASERUN_CS)] = mean(moneyball$TEAM_BASERUN_CS, na.rm = TRUE)
#moneyball$TEAM_FIELDING_DP[is.na(moneyball$TEAM_FIELDING_DP)] = mean(moneyball$TEAM_FIELDING_DP, na.rm = TRUE)
#moneyball$TEAM_PITCHING_SO[is.na(moneyball$TEAM_PITCHING_SO)] = mean(moneyball$TEAM_PITCHING_SO, na.rm = TRUE)

#Straighten Relationships
moneyball$TEAM_BATTING_1B <- moneyball$TEAM_BATTING_H - moneyball$TEAM_BATTING_HR - moneyball$TEAM_BATTING_3B -
                             moneyball$TEAM_BATTING_2B
moneyball$log_TEAM_BATTING_1B <- log(moneyball$TEAM_BATTING_1B)
moneyball$log_TEAM_BATTING_3B <- log(moneyball$TEAM_BATTING_3B)
moneyball$log_TEAM_BASERUN_SB <- log(moneyball$TEAM_BASERUN_SB)
moneyball$log_TEAM_BASERUN_CS <- log(moneyball$TEAM_BASERUN_CS)
moneyball$TEAM_BATTING_SO[is.na(moneyball$TEAM_BATTING_SO)] = mean(moneyball$TEAM_BATTING_SO, na.rm = TRUE)
moneyball$TEAM_FIELDING_E[(moneyball$TEAM_FIELDING_E > 500)] = 500
moneyball$sqrt_TEAM_PITCHING_HR <- sqrt(moneyball$TEAM_PITCHING_HR)
moneyball$SB_PCT <- moneyball$TEAM_BASERUN_SB/(1.0*moneyball$TEAM_BASERUN_SB+moneyball$TEAM_BASERUN_CS)
moneyball$SB_PCT[is.na(moneyball$SB_PCT)] = mean(moneyball$SB_PCT, na.rm = TRUE)

#Check that na's are gone. 
summary(moneyball)

#***Note at this point you may wish to also check to ensure outliers are imputed but not deleted***



#################### Part 3: Model Creation ############################################

#Function for Mean Square Error Calculation
mse <- function(sm) 
  mean(sm$residuals^2)

# Stepwise Approach
rm(stepwisemodel)
stepwisemodel <- lm(formula = TARGET_WINS ~ 
                      TEAM_BATTING_H +
                      TEAM_BATTING_HR +
                      TEAM_BATTING_HBP +
                      TEAM_PITCHING_H +
                      TEAM_PITCHING_HR +
                      TEAM_PITCHING_BB +
                      (TEAM_FIELDING_DP * TEAM_BATTING_3B) +
                      (TEAM_BATTING_2B * TEAM_BATTING_BB), data = moneyball)
stepwise <- stepAIC(stepwisemodel, direction = "both")
summary(stepwise)

# All subsets regression
rm(subsets)
subsets <- regsubsets(TARGET_WINS ~ 
                        TEAM_BATTING_H +
                        TEAM_BATTING_HR +
                        TEAM_BATTING_HBP +
                        TEAM_PITCHING_H +
                        TEAM_PITCHING_HR +
                        TEAM_PITCHING_BB +
                        (TEAM_FIELDING_DP * TEAM_BATTING_3B) +
                        (TEAM_BATTING_2B * TEAM_BATTING_BB),  data = moneyball, nbest = 1, method = "exhaustive", nvmax=14, really.big=T)
plot(subsets, scale="adjr2")
summary(subsets)
summary(subsets)$rsq

subset <- lm(TARGET_WINS ~ 
               TEAM_BATTING_H +
               TEAM_BATTING_HR +
               TEAM_BATTING_HBP +
               TEAM_PITCHING_H +
               TEAM_PITCHING_HR +
               TEAM_PITCHING_BB +
               (TEAM_FIELDING_DP * TEAM_BATTING_3B) +
               (TEAM_BATTING_2B * TEAM_BATTING_BB), data = moneyball)
summary(subset)

# Model 3
rm(model3)
model3 <- lm(TARGET_WINS ~ 
               TEAM_BATTING_H +
               TEAM_BATTING_HR +
               TEAM_BATTING_HBP +
               TEAM_PITCHING_H +
               TEAM_PITCHING_HR +
               TEAM_PITCHING_BB +
               (TEAM_FIELDING_DP * TEAM_BATTING_3B) +
               (TEAM_BATTING_2B * TEAM_BATTING_BB), data = moneyball)
options(scipen = 999)
summary(model3)

######## Performance #######
AIC(stepwise)
AIC(subset)
AIC(model3)
mse(stepwise)
mse(subset)
mse(model3)

#####
#
#####
# 5:40 in video
#################### Test Data ##########################
moneyball_test=read.csv("buad5122-m2-moneyball-test.csv",header=T)

# Fixing na's 
# I switched the means from moneyball_test to moneyball in order to use the training data to replace NAs in the test data
moneyball_test$TEAM_BATTING_1B <- moneyball_test$TEAM_BATTING_H - moneyball_test$TEAM_BATTING_HR -
moneyball_test$TEAM_BATTING_3B -moneyball_test$TEAM_BATTING_2B
moneyball_test$TEAM_BATTING_SO[is.na(moneyball_test$TEAM_BATTING_SO)] = mean(moneyball$TEAM_BATTING_SO, na.rm = TRUE)
moneyball_test$TEAM_BATTING_HBP[is.na(moneyball_test$TEAM_BATTING_HBP)] = mean(moneyball$TEAM_BATTING_HBP, na.rm = TRUE)
moneyball_test$TEAM_BASERUN_SB[is.na(moneyball_test$TEAM_BASERUN_SB)] = mean(moneyball$TEAM_BASERUN_SB, na.rm = TRUE)
moneyball_test$TEAM_BASERUN_CS[is.na(moneyball_test$TEAM_BASERUN_CS)] = mean(moneyball$TEAM_BASERUN_CS, na.rm = TRUE)
moneyball_test$TEAM_FIELDING_DP[is.na(moneyball_test$TEAM_FIELDING_DP)] = mean(moneyball$TEAM_FIELDING_DP, na.rm = TRUE)
moneyball_test$TEAM_PITCHING_SO[is.na(moneyball_test$TEAM_PITCHING_SO)] = mean(moneyball$TEAM_PITCHING_SO, na.rm = TRUE)
moneyball_test$TEAM_BASERUN_CS[moneyball_test$TEAM_BASERUN_CS < 1] = 1
moneyball_test$SB_PCT <- moneyball_test$TEAM_BASERUN_SB/(1.0*moneyball_test$TEAM_BASERUN_SB+moneyball_test$TEAM_BASERUN_CS)
moneyball_test$SB_PCT[is.na(moneyball_test$SB_PCT)] = mean(moneyball$SB_PCT)
moneyball_test$log_TEAM_BASERUN_CS <- log(moneyball_test$TEAM_BASERUN_CS)

# verify test data is fixed
str(moneyball_test)
summary(moneyball_test)

# clean outliers in test data
moneyball_test$TEAM_BASERUN_SB[moneyball_test$TEAM_BASERUN_SB > (quantile(moneyball_test$TEAM_BASERUN_SB, .75)*2)] = 
  mean(moneyball$TEAM_BASERUN_SB, na.rm = TRUE)
moneyball_test$TEAM_BASERUN_CS[moneyball_test$TEAM_BASERUN_CS > (quantile(moneyball_test$TEAM_BASERUN_CS, .75)*2)] = 
  mean(moneyball$TEAM_BASERUN_CS, na.rm = TRUE)
moneyball_test$TEAM_PITCHING_H[moneyball_test$TEAM_PITCHING_H > (quantile(moneyball_test$TEAM_PITCHING_H, .75)*2)] = 
  mean(moneyball$TEAM_PITCHING_H, na.rm = TRUE)
moneyball_test$TEAM_PITCHING_HR[moneyball_test$TEAM_PITCHING_HR > (quantile(moneyball_test$TEAM_PITCHING_HR, .75)*2)] = 
  mean(moneyball$TEAM_PITCHING_HR, na.rm = TRUE)
moneyball_test$TEAM_PITCHING_BB[moneyball_test$TEAM_PITCHING_BB > (quantile(moneyball_test$TEAM_PITCHING_BB, .75)*2)] = 
  mean(moneyball$TEAM_PITCHING_BB, na.rm = TRUE)
moneyball_test$TEAM_PITCHING_SO[moneyball_test$TEAM_PITCHING_SO > (quantile(moneyball_test$TEAM_PITCHING_SO, .75)*2)] = 
  mean(moneyball$TEAM_PITCHING_SO, na.rm = TRUE)
moneyball_test$TEAM_FIELDING_E[moneyball_test$TEAM_FIELDING_E > (quantile(moneyball_test$TEAM_FIELDING_E, .75)*2)] = 
  mean(moneyball$TEAM_FIELDING_E, na.rm = TRUE)

# verify test data is fixed
str(moneyball_test)
summary(moneyball_test)

#############################################
#    I used the coefficients from Model 3   #
#############################################
# Stand Alone Scoring
moneyball_test$P_TARGET_WINS <- -43.35043181 + 
  0.04263554 * moneyball_test$TEAM_BATTING_H +
  0.04515319 * moneyball_test$TEAM_BATTING_HR + 
  0.04020754 * moneyball_test$TEAM_BATTING_HBP +
  0.00708141 * moneyball_test$TEAM_PITCHING_H +
  0.01219022 * moneyball_test$TEAM_PITCHING_HR +
  -0.02877505 * moneyball_test$TEAM_PITCHING_BB + 
  -0.03521032 * moneyball_test$TEAM_FIELDING_DP +
  0.32141467 * moneyball_test$TEAM_BATTING_3B + 
  0.12646239 * moneyball_test$TEAM_BATTING_2B + 
  0.13192536 * moneyball_test$TEAM_BATTING_BB +
  -0.00180073 * (moneyball_test$TEAM_FIELDING_DP * moneyball_test$TEAM_BATTING_3B) + 
  -0.00030300 * (moneyball_test$TEAM_BATTING_2B * moneyball_test$TEAM_BATTING_BB)

#subset of data set for the deliverable "Scored data file"
prediction <- moneyball_test[c("INDEX","P_TARGET_WINS")]

#####
#Note, this next function will output a CSV file in your work environment called write.csv.
#####

#Prediction File 
write.csv(prediction, file = "write-M2-Assignment-result.csv")