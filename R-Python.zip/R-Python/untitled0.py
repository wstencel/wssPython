# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 19:01:57 2019

@author: WS0140
"""

f = lambda x:x**2
y = f(2)
print(y)

g = lambda x:x[0]
z = g([0,1,2])
print(z)

h = lambda x,y:max(x,y)**2
x = h(2,3)
print(x)



